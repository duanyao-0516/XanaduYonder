/**
 * @Author: 49.Jz
 * @Date:   2026-08-24 11:35:26
 * @Last Modified by:   49.Jz
 * @Last Modified time: 2026-08-24 11:38:10
 */
/** @format */

(function (V, e0) {
  typeof exports == "object" && typeof module < "u"
    ? e0(exports)
    : typeof define == "function" && define.amd
      ? define(["exports"], e0)
      : ((V = typeof globalThis < "u" ? globalThis : V || self), e0((V.viverse = {})));
})(this, function (V) {
  "use strict";
  var Ds = Object.defineProperty;
  var As = (V, e0, B0) => (e0 in V ? Ds(V, e0, {enumerable: !0, configurable: !0, writable: !0, value: B0}) : (V[e0] = B0));
  var H = (V, e0, B0) => As(V, typeof e0 != "symbol" ? e0 + "" : e0, B0);
  class e0 {
    constructor() {
      H(this, "name");
      H(this, "given_name");
      H(this, "family_name");
      H(this, "middle_name");
      H(this, "nickname");
      H(this, "preferred_username");
      H(this, "profile");
      H(this, "picture");
      H(this, "website");
      H(this, "email");
      H(this, "email_verified");
      H(this, "gender");
      H(this, "birthdate");
      H(this, "zoneinfo");
      H(this, "locale");
      H(this, "phone_number");
      H(this, "phone_number_verified");
      H(this, "address");
      H(this, "updated_at");
      H(this, "sub");
    }
  }
  const B0 = "email";
  var u0 = ((i) => ((i.AccessToken = "access_token"), (i.AuthKey = "auth_key"), i))(u0 || {});
  class f0 extends Error {
    constructor(t, e) {
      (super(e), (this.error = t), (this.error_description = e), Object.setPrototypeOf(this, f0.prototype));
    }
    static fromPayload({error: t, error_description: e}) {
      return new f0(t, e);
    }
  }
  class Mt extends f0 {
    constructor() {
      (super("timeout", "Timeout"), Object.setPrototypeOf(this, Mt.prototype));
    }
  }
  class $t extends Mt {
    constructor(t) {
      (super(), (this.popup = t), Object.setPrototypeOf(this, $t.prototype));
    }
  }
  class jt extends f0 {
    constructor(t) {
      (super("cancelled", "Popup closed"), (this.popup = t), Object.setPrototypeOf(this, jt.prototype));
    }
  }
  class Wt extends f0 {
    constructor() {
      (super("missing_refresh_token", "Missing Refresh Token"), Object.setPrototypeOf(this, Wt.prototype));
    }
  }
  const Lr = 180,
    Nr = 3,
    ue = 1e4,
    Kr = (i) => {
      const t = i.split("."),
        [e, r, n] = t;
      if (t.length !== 3 || !e || !r || !n) throw new Error("Access token could not be decoded");
      const s = JSON.parse(pe(r)),
        a = {__raw: i};
      return (
        Object.keys(s).forEach((o) => (a[o] = s[o])),
        {encoded: {header: e, payload: r, signature: n}, header: JSON.parse(pe(e)), claims: a}
      );
    },
    le = (i) => {
      var t;
      try {
        const e = Kr(i);
        return typeof ((t = e.header) == null ? void 0 : t.alg) == "string" && (e.header.typ ? e.header.typ === "JWT" : !0);
      } catch {
        return !1;
      }
    },
    qr = (i) => {
      i.indexOf("#") > -1 && (i = i.substring(0, i.indexOf("#")));
      const t = new URLSearchParams(i);
      return {state: t.get("state"), code: t.get("code") || void 0};
    },
    zr = () => {
      if (typeof window > "u") return;
      const i = window.location.search.substring(1),
        t = new URLSearchParams(i);
      (t.delete("code"), t.delete("state"), t.delete("api_url"));
      const e = `${window.location.origin}${window.location.pathname}${t.size > 0 ? `?${t.toString()}` : ""}`;
      window.history.replaceState({}, document.title, e);
    },
    W0 = () => window.crypto,
    de = () => {
      const i = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_~.";
      let t = "";
      return (Array.from(W0().getRandomValues(new Uint8Array(43))).forEach((r) => (t += i[r % i.length])), t);
    },
    ve = (i) => btoa(i),
    Gt = (i) => atob(i),
    Vr = (i) =>
      Object.keys(i)
        .filter((t) => typeof i[t] < "u")
        .reduce((t, e) => ({...t, [e]: i[e]}), {}),
    m0 = ({...i}) => new URLSearchParams(Vr({...i})).toString(),
    Mr = async (i) => await W0().subtle.digest({name: "SHA-256"}, new TextEncoder().encode(i)),
    $r = (i) => {
      const t = {"+": "-", "/": "_", "=": ""};
      return i.replace(/[+/=]/g, (e) => t[e]);
    },
    jr = (i) =>
      decodeURIComponent(
        atob(i)
          .split("")
          .map((t) => "%" + ("00" + t.charCodeAt(0).toString(16)).slice(-2))
          .join(""),
      ),
    pe = (i) => jr(i.replace(/_/g, "/").replace(/-/g, "+")),
    Wr = (i) => {
      const t = new Uint8Array(i);
      return $r(window.btoa(String.fromCharCode(...Array.from(t))));
    },
    Gr = () => {
      if (!W0()) throw new Error("For security reasons, `window.crypto` is required.");
      if (typeof W0().subtle > "u") throw new Error("window.crypto.subtle must run on a secure origin.");
    },
    Zr = (i) => (/^https?:\/\//.test(i) ? i : `https://${i}`),
    Xr = (i) => Array.from(new Set(i)),
    Yr = (...i) => Xr(i.filter(Boolean).join(" ").trim().split(/\s+/)).join(" "),
    Qr = (i, t, e, r, n, s) => ({
      client_id: i.clientId,
      state: t,
      scope: e,
      response_type: "code",
      redirection_url: r,
      authorities: n,
      code_challenge: s,
      code_challenge_method: "S256",
    });
  function I0(i) {
    return new Promise((t, e) => {
      const r = document.createElement("script");
      ((r.type = "text/javascript"),
        (r.async = !0),
        (r.src = i),
        (r.onload = () => t()),
        (r.onerror = () => e(new Error(`Script load error for ${i}`))),
        document.body.appendChild(r));
    });
  }
  function P0(i, t, e, r = 0) {
    return (
      (r += 1),
      new Promise((n, s) => {
        i[t] === e
          ? n(e)
          : r >= 300
            ? s()
            : setTimeout(async () => {
                await P0(i, t, e, r)
                  .then((a) => n(a))
                  .catch(() => s());
              }, 100);
      })
    );
  }
  const O0 = (i) =>
      i && le(i)
        ? {token: i, tokenType: u0.AccessToken}
        : i && !le(i)
          ? {token: i, tokenType: u0.AuthKey}
          : {token: "", tokenType: u0.AccessToken},
    G0 = (i) => {
      if (i.token) {
        if (i.tokenType === u0.AccessToken) return {token: i.token};
        if (i.tokenType === u0.AuthKey) return {authKey: i.token};
      }
    },
    Jr = (i) => {
      const r = window.screenX + (window.innerWidth - 414) / 2,
        n = window.screenY + (window.innerHeight - 700) / 2;
      return window.open(
        i,
        "viverse:authorize:popup",
        `left=${r},top=${n},width=414,height=700,resizable,scrollbars=yes,status=1`,
      );
    },
    ti = (i) =>
      new Promise((t, e) => {
        let r;
        const n = setInterval(() => {
            i.popup &&
              i.popup.closed &&
              (clearInterval(n), clearTimeout(s), window.removeEventListener("message", r, !1), e(new jt(i.popup)));
          }, 1e3),
          s = setTimeout(
            () => {
              (clearInterval(n), e(new $t(i.popup)), window.removeEventListener("message", r, !1));
            },
            (i.timeoutInSeconds || Lr) * 1e3,
          );
        ((r = function (a) {
          if (!(!a.data || a.data.type !== "authorization_response") && !(a.origin !== i.origin || a.source !== i.source)) {
            if (
              (clearTimeout(s),
              clearInterval(n),
              window.removeEventListener("message", r, !1),
              i.popup.close(),
              a.data.response.error)
            )
              return e(f0.fromPayload(a.data.response));
            t(a.data.response);
          }
        }),
          window.addEventListener("message", r));
      }),
    ei = (i) => {
      const t = document.cookie.split("; ");
      for (const e of t) {
        const [r, n] = e.split("=");
        if (r === i) return n;
      }
      return null;
    };
  var H0 = function () {
    return (
      (H0 =
        Object.assign ||
        function (i) {
          for (var t, e = 1, r = arguments.length; e < r; e++) {
            t = arguments[e];
            for (var n in t) Object.prototype.hasOwnProperty.call(t, n) && (i[n] = t[n]);
          }
          return i;
        }),
      H0.apply(this, arguments)
    );
  };
  function U0(i, t) {
    if (!t) return "";
    var e = "; " + i;
    return t === !0 ? e : e + "=" + t;
  }
  function ri(i) {
    if (typeof i.expires == "number") {
      var t = new Date();
      (t.setMilliseconds(t.getMilliseconds() + i.expires * 864e5), (i.expires = t));
    }
    return (
      U0("Expires", i.expires ? i.expires.toUTCString() : "") +
      U0("Domain", i.domain) +
      U0("Path", i.path) +
      U0("Secure", i.secure) +
      U0("SameSite", i.sameSite)
    );
  }
  function ii(i, t, e) {
    return (
      encodeURIComponent(i)
        .replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent)
        .replace(/\(/g, "%28")
        .replace(/\)/g, "%29") +
      "=" +
      encodeURIComponent(t).replace(/%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g, decodeURIComponent) +
      ri(e)
    );
  }
  function ni(i) {
    for (var t = {}, e = i ? i.split("; ") : [], r = 0, n = e; r < n.length; r++) {
      var s = n[r],
        a = s.split("="),
        o = a.slice(1).join("=");
      o[0] === '"' && (o = o.slice(1, -1));
      try {
        var x = decodeURIComponent(a[0]);
        t[x] = o.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent);
      } catch {}
    }
    return t;
  }
  function si() {
    return ni(document.cookie);
  }
  function oi(i) {
    return si()[i];
  }
  function ge(i, t, e) {
    document.cookie = ii(i, t, H0({path: "/"}, e));
  }
  function ai(i, t) {
    ge(i, "", H0(H0({}, t), {expires: -1}));
  }
  const ci = {
      get(i) {
        const t = oi(i);
        if (!(typeof t > "u")) return JSON.parse(t);
      },
      save(i, t, e) {
        let r = {};
        (window.location.protocol === "https:" && (r = {secure: !0, sameSite: "lax"}),
          e != null && e.daysUntilExpire && (r.expires = e.daysUntilExpire),
          e != null && e.cookieDomain && (r.domain = e.cookieDomain),
          ge(i, JSON.stringify(t), r));
      },
      remove(i, t) {
        let e = {};
        (t != null && t.cookieDomain && (e.domain = t.cookieDomain), ai(i, e));
      },
    },
    xi = {
      get(i) {
        if (typeof sessionStorage > "u") return;
        const t = sessionStorage.getItem(i);
        if (t != null) return JSON.parse(t);
      },
      save(i, t) {
        sessionStorage.setItem(i, JSON.stringify(t));
      },
      remove(i) {
        sessionStorage.removeItem(i);
      },
    },
    fi = "viverse-client/tx";
  class hi {
    constructor(t, e, r) {
      H(this, "storageKey");
      ((this.storage = t), (this.clientId = e), (this.cookieDomain = r), (this.storageKey = `${fi}/${this.clientId}`));
    }
    create(t) {
      this.storage.save(this.storageKey, t, {daysUntilExpire: 1, cookieDomain: this.cookieDomain});
    }
    get() {
      return this.storage.get(this.storageKey);
    }
    remove() {
      this.storage.remove(this.storageKey, {cookieDomain: this.cookieDomain});
    }
  }
  const Zt = "@viverse";
  class l0 {
    constructor(t, e = Zt, r) {
      H(this, "clientId");
      H(this, "scope");
      ((this.prefix = e), (this.suffix = r), (this.clientId = t.clientId), (this.scope = t.scope));
    }
    toKey() {
      return [this.prefix, this.clientId, this.scope, this.suffix].filter(Boolean).join("::");
    }
    static fromKey(t) {
      const [e, r, n] = t.split("::");
      return new l0({clientId: r, scope: n}, e);
    }
    static fromCacheEntry(t) {
      const {scope: e, client_id: r} = t;
      return new l0({scope: e, clientId: r});
    }
  }
  const ui = 0;
  class li {
    constructor(t, e, r) {
      H(this, "nowProvider");
      ((this.cache = t), (this.keyManifest = e), (this.nowProvider = r || (() => Date.now())));
    }
    async get(t, e = ui) {
      var a;
      let r = await this.cache.get(t.toKey());
      if (!r) {
        const o = await this.getCacheKeys();
        if (!o) return;
        const x = this.matchExistingCacheKey(t, o);
        x && (r = await this.cache.get(x));
      }
      if (!r) return;
      const n = await this.nowProvider(),
        s = Math.floor(n / 1e3);
      if (r.expiresAt - e < s) {
        if (r.body.refresh_token)
          return ((r.body = {refresh_token: r.body.refresh_token}), await this.cache.set(t.toKey(), r), r.body);
        (await this.cache.remove(t.toKey()), await ((a = this.keyManifest) == null ? void 0 : a.remove(t.toKey())));
        return;
      }
      return r.body;
    }
    async set(t) {
      var n;
      const e = new l0({clientId: t.client_id, scope: t.scope}),
        r = await this.wrapCacheEntry(t);
      (await this.cache.set(e.toKey(), r), await ((n = this.keyManifest) == null ? void 0 : n.add(e.toKey())));
    }
    async clear(t) {
      var r;
      const e = await this.getCacheKeys();
      e &&
        (await e
          .filter((n) => (t ? n.includes(t) : !0))
          .reduce(async (n, s) => {
            (await n, await this.cache.remove(s));
          }, Promise.resolve()),
        await ((r = this.keyManifest) == null ? void 0 : r.clear()));
    }
    async wrapCacheEntry(t) {
      const e = await this.nowProvider(),
        r = Math.floor(e / 1e3) + t.expires_in;
      return {body: t, expiresAt: r};
    }
    async getCacheKeys() {
      var t;
      if (this.keyManifest) return (t = await this.keyManifest.get()) == null ? void 0 : t.keys;
      if (this.cache.allKeys) return this.cache.allKeys();
    }
    matchExistingCacheKey(t, e) {
      return e.filter((r) => {
        var x;
        const n = l0.fromKey(r),
          s = new Set(n.scope && n.scope.split(" ")),
          a = ((x = t.scope) == null ? void 0 : x.split(" ")) || [],
          o = n.scope && a.reduce((c, f) => c && s.has(f), !0);
        return n.prefix === Zt && n.clientId === t.clientId && o;
      })[0];
    }
  }
  class di {
    constructor(t, e) {
      H(this, "manifestKey");
      ((this.cache = t), (this.clientId = e), (this.manifestKey = this.createManifestKeyFrom(this.clientId)));
    }
    async add(t) {
      var r;
      const e = new Set(((r = await this.cache.get(this.manifestKey)) == null ? void 0 : r.keys) || []);
      (e.add(t), await this.cache.set(this.manifestKey, {keys: [...e]}));
    }
    async remove(t) {
      const e = await this.cache.get(this.manifestKey);
      if (e) {
        const r = new Set(e.keys);
        return (
          r.delete(t),
          r.size > 0 ? await this.cache.set(this.manifestKey, {keys: [...r]}) : await this.cache.remove(this.manifestKey)
        );
      }
    }
    get() {
      return this.cache.get(this.manifestKey);
    }
    clear() {
      return this.cache.remove(this.manifestKey);
    }
    createManifestKeyFrom(t) {
      return `${Zt}::${t}`;
    }
  }
  class vi {
    constructor() {
      H(
        this,
        "enclosedCache",
        (function () {
          let t = {};
          return {
            set(e, r) {
              t[e] = r;
            },
            get(e) {
              const r = t[e];
              if (r) return r;
            },
            remove(e) {
              delete t[e];
            },
            allKeys() {
              return Object.keys(t);
            },
          };
        })(),
      );
    }
  }
  const pi = () => new AbortController(),
    gi = async (i, t) => {
      const e = await fetch(i, t);
      let r;
      try {
        const n = await e.text();
        n === "" ? (r = {}) : (r = JSON.parse(n));
      } catch (n) {
        (console.error("Error parsing JSON:", n), (r = {}));
      }
      return {ok: e.ok, json: r};
    },
    yi = async (i, t, e) => {
      const r = pi();
      t.signal = r.signal;
      let n;
      return Promise.race([
        gi(i, t),
        new Promise((s, a) => {
          n = setTimeout(() => {
            (r.abort(), a(new Error("Timeout when executing 'fetch'")));
          }, e);
        }),
      ]).finally(() => {
        clearTimeout(n);
      });
    },
    Ei = async (i, t, e = ue) => yi(i, t, e);
  async function r0(i, t, e) {
    let r = null,
      n;
    for (let c = 0; c < Nr; c++)
      try {
        ((n = await Ei(i, e, t)), (r = null));
        break;
      } catch (f) {
        r = f;
      }
    if (r) throw r;
    const {
      json: {error: s, error_description: a, ...o},
      ok: x,
    } = n;
    if (!x) {
      const c = a || `HTTP error. Unable to fetch ${i}`;
      throw s === "missing_refresh_token" ? new Wt() : new f0(s || "request_error", c);
    }
    return o;
  }
  async function Bi({baseUrl: i, timeout: t, scope: e, ...r}) {
    const n = m0(r);
    return await r0(`${i}/SS/api/oauth/v1/vendor/token/authorization-code`, t, {
      method: "POST",
      body: n,
      headers: {"Content-Type": "application/x-www-form-urlencoded"},
    });
  }
  async function Di({baseUrl: i, timeout: t, scope: e, ...r}) {
    const n = m0(r);
    return await r0(`${i}/SS/api/oauth/v1/vendor/token/refresh-token`, t, {
      method: "POST",
      body: n,
      headers: {"Content-Type": "application/x-www-form-urlencoded"},
    });
  }
  class Xt {
    constructor(t) {
      H(this, "transactionManager");
      H(this, "cacheManager");
      H(this, "cookieStorage");
      H(this, "nowProvider", () => Date.now());
      H(this, "httpTimeoutMs");
      H(this, "domainUrl");
      H(this, "scope");
      H(this, "authorities");
      H(this, "tokenCookieName");
      H(this, "options");
      H(this, "_cacheSetupDone", !1);
      ((this.options = {...t, authorizationParams: {...t.authorizationParams}}), typeof window < "u" && Gr());
      let e = new vi().enclosedCache;
      ((this.httpTimeoutMs = t.httpTimeoutInMS ?? ue),
        (this.domainUrl = Zr(this.options.domain)),
        (this.scope = Yr(this.options.authorizationParams.scope || B0)),
        (this.tokenCookieName = `.viverse.${this.options.clientId}.token`),
        (this.cookieStorage = ci),
        (this.transactionManager = new hi(xi, this.options.clientId, this.options.domain)),
        (this.cacheManager = new li(e, e.allKeys ? void 0 : new di(e, this.options.clientId), this.nowProvider)),
        (this.authorities =
          this.options.authorizationParams.authorities ?? "htc.com metamask.com walletconnect.com google.com steam.com"),
        this._initializeCache());
    }
    async _initializeCache() {
      if (!(await this._getSGTokenFromParent())) {
        const e = this.cookieStorage.get(this.tokenCookieName);
        try {
          e && (await this.cacheManager.set(e));
        } catch (r) {
          console.error("Failed to set token in cache:", r);
        }
      }
      this._cacheSetupDone = !0;
    }
    _url(t) {
      return `${this.domainUrl}${t}`;
    }
    _authorizeUrl(t) {
      return this._url(`/SS/Services/OAuth/Authorize?${m0(t)}`);
    }
    async _prepareAuthorizeUrl(t) {
      let e;
      if (t.ux === "popup") {
        const x = {
          state: t.state,
          initView: "vrs-sign-in",
          redirectUrl: t.redirectionUrl,
          flow: "infinity",
          clientId: this.options.clientId,
          authorities: this.authorities,
        };
        e = JSON.stringify(x);
      } else {
        const x = t.state ? {state: t.state, initView: "vrs-sign-in"} : {initView: "vrs-sign-in"};
        e = JSON.stringify(x);
      }
      const r = de(),
        n = await Mr(r),
        s = Wr(n),
        a = Qr(
          this.options,
          e,
          this.scope,
          t.redirectionUrl || `${window.location.origin}${window.location.pathname}`,
          this.authorities,
          s,
        ),
        o = this._authorizeUrl(a);
      return {state: e, scope: a.scope, redirection_url: a.redirection_url, code_verifier: r, url: o};
    }
    async _saveEntryInCache(t) {
      (await this.cacheManager.set(t),
        this.cookieStorage.save(this.tokenCookieName, t, {
          daysUntilExpire: t.expires_in / 86400,
          cookieDomain: this.options.cookieDomain,
        }));
    }
    async _saveEntryInMemoryOnly(t) {
      const e = {...t, created_at: Date.now()};
      await this.cacheManager.set(e);
    }
    async _requestToken(t) {
      const e = await Bi({baseUrl: this.domainUrl, client_id: this.options.clientId, timeout: this.httpTimeoutMs, ...t});
      return (await this._saveEntryInCache({...e, scope: t.scope, client_id: this.options.clientId}), e);
    }
    async _requestTokenViaRefreshToken(t) {
      const e = await Di({baseUrl: this.domainUrl, client_id: this.options.clientId, timeout: this.httpTimeoutMs, ...t});
      return (await this._saveEntryInCache({...e, scope: t.scopes, client_id: this.options.clientId}), e);
    }
    async _getSGTokenFromParent() {
      if (typeof window > "u" || !window.location.search.includes("auth_resp=")) return !1;
      const t = new URLSearchParams(window.location.search),
        e = t.get("auth_resp"),
        r = t.get("state");
      if (!e) return (console.error("Unable to get auth response info"), !1);
      let n;
      try {
        n = JSON.parse(Gt(e));
        const {access_token: s, client_id: a, account_id: o, expires_in: x, scope: c, refresh_token: f} = n;
        if (s && a && o && x && c && f) {
          if (a !== this.options.clientId) throw new Error("Invalid app id");
        } else throw new Error("Invalid token: missing required fields");
        const g = {
          client_id: a,
          access_token: s,
          account_id: o,
          expires_in: x,
          scope: "email",
          refresh_token: f,
          state: r ? Gt(r) : "",
        };
        (await this._saveEntryInMemoryOnly(g), t.delete("auth_resp"), t.delete("state"));
        const h = `${window.location.origin}${window.location.pathname}${t.size > 0 ? `?${t.toString()}` : ""}`;
        window.history.replaceState({}, document.title, h);
      } catch (s) {
        return (console.error("Failed to process auth response:", s), !1);
      }
      return !0;
    }
    async loginWithRedirect(t = {}) {
      const {url: e, ...r} = await this._prepareAuthorizeUrl(t);
      (this.transactionManager.create({...r}),
        t.openUrl ? await t.openUrl(e) : window.top ? window.top.location.assign(e) : window.location.assign(e));
    }
    async handleRedirectCallback(t = window.location.href) {
      const e = t.split("?").slice(1);
      if (e.length === 0) throw new Error("There are no query params available for parsing.");
      const {state: r, code: n} = qr(e.join("")),
        s = this.transactionManager.get();
      if (!s) throw new f0("missing_transaction", "Invalid state");
      if ((this.transactionManager.remove(), zr(), !s.code_verifier || (s.state && s.state !== r)))
        throw new f0("state_mismatch", "Invalid state");
      const a = await this._requestToken({
        scope: s.scope,
        code_verifier: s.code_verifier,
        grant_type: "authorization_code",
        code: n,
      });
      return {
        state: decodeURIComponent(r),
        access_token: a.access_token,
        account_id: a.account_id,
        expires_in: a.expires_in,
      };
    }
    async loginWithPopup(t = {}) {
      const e = await this._getEntryFromCache({scope: this.scope, clientId: this.options.clientId}),
        r = ei(t.htcAccessTokenName ? t.htcAccessTokenName : "_htc_access_token_production");
      if (r) {
        console.log("Already logged in on the main site");
        let n;
        try {
          n = JSON.parse(Gt(r));
        } catch {
          throw new Error("Failed to parse accessToken");
        }
        return (
          await this._saveEntryInCache({
            access_token: n.access_token,
            scope: this.scope,
            client_id: this.options.clientId,
            account_id: n.account_id,
            expires_in: n.expires_in,
          }),
          {access_token: n.access_token, account_id: n.account_id, expires_in: n.expires_in}
        );
      } else {
        if (e != null && e.access_token)
          return (
            console.log("Already logged in "),
            {access_token: e.access_token, account_id: e.account_id, expires_in: e.expires_in}
          );
        {
          const n = t.viverseDomain || "https://www.viverse.com";
          let s = `${n}/viverse-sso?client_id=${this.options.clientId}&origin=${window.location.origin}`;
          t.authorities && (s += `&authorities=${t.authorities}`);
          const a = t.popup || Jr(s);
          if (!a) throw new Error("Failed to open popup");
          try {
            const o = await ti({origin: n, source: a, popup: a, timeoutInSeconds: t.timeoutInSeconds});
            return (
              await this._saveEntryInCache({...o, scope: this.scope, client_id: this.options.clientId}),
              {access_token: o.access_token, account_id: o.account_id, expires_in: o.expires_in}
            );
          } catch (o) {
            throw (console.error("LoginWithPopup failed:", o), o);
          }
        }
      }
    }
    async getToken(t = {}) {
      const e = await this._getEntryFromCache({scope: this.scope, clientId: this.options.clientId});
      if (e != null && e.access_token) return t.detailedResponse ? e : e.access_token;
      const r = await this.cacheManager.get(new l0({scope: this.scope, clientId: this.options.clientId}));
      if (r != null && r.refresh_token) return await this.getTokenViaRefreshToken(t);
    }
    async getTokenViaRefreshToken(t = {}) {
      await this._waitForCacheSetup();
      const e = await this.cacheManager.get(new l0({scope: this.scope, clientId: this.options.clientId}));
      if (!(e != null && e.refresh_token)) throw new Error("No refresh token available, please log in again.");
      const {
        access_token: r,
        account_id: n,
        expires_in: s,
      } = await this._requestTokenViaRefreshToken({
        grant_type: "refresh_token",
        refresh_token: e.refresh_token,
        scopes: e.scope || this.scope,
      });
      return t.detailedResponse ? {access_token: r, account_id: n, expires_in: s} : r;
    }
    _buildLogoutUrl(t) {
      return this._url(`/logout?${m0({client_id: this.options.clientId, redirect_url: t.redirectionUrl})}`);
    }
    async logout(t) {
      const {openUrl: e, ...r} = t;
      (await this.cacheManager.clear(this.options.clientId),
        this.cookieStorage.remove(this.tokenCookieName, {cookieDomain: this.options.cookieDomain}));
      const n = this._buildLogoutUrl(r);
      e ? await e(n) : window.location.assign(n);
    }
    async checkAuth(t = {}) {
      const e = t.allowedOrigin || "viverse.com",
        r = await this._getEntryFromCache({scope: this.scope, clientId: this.options.clientId});
      if (r != null && r.access_token) {
        if (r.refresh_token && r.created_at) {
          const {expires_in: n, created_at: s} = r,
            a = Date.now(),
            o = s + n * 1e3 - a,
            x = r.state;
          if (o <= 18e4)
            try {
              const c = await this._requestTokenViaRefreshToken({
                grant_type: "refresh_token",
                refresh_token: r.refresh_token,
                scopes: r.scope || this.scope,
              });
              if (c) {
                const f = {
                  client_id: this.options.clientId,
                  access_token: c.access_token,
                  account_id: c.account_id,
                  expires_in: c.expires_in,
                  scope: c.scope,
                  refresh_token: c.refresh_token,
                };
                (await this._saveEntryInMemoryOnly(f), console.log("Token refreshed successfully."));
                const {access_token: g, account_id: h, expires_in: l} = c;
                return {access_token: g, account_id: h, expires_in: l, state: x};
              }
            } catch (c) {
              console.error("Failed to refresh token:", c);
              return;
            }
        }
        return (
          console.log("Already logged in"),
          {access_token: r.access_token, account_id: r.account_id, expires_in: r.expires_in, state: r.state}
        );
      }
      return new Promise((n) => {
        const s = setTimeout(() => {
            (console.error("Timeout waiting for parent message"), n(void 0));
          }, t.timeout || 6e4),
          a = async (o) => {
            var c, f;
            const x = (c = o == null ? void 0 : o.data) == null ? void 0 : c.methods;
            if (x) {
              if (Array.isArray(e)) {
                if (!e.some((g) => o.origin.endsWith(g))) {
                  console.error("origin not allowed:", o.origin);
                  return;
                }
              } else if (!o.origin.endsWith(e)) {
                console.error("origin not allowed:", o.origin);
                return;
              }
              if (x === "VIVERSE_SDK/checkAuth:ack") {
                (clearTimeout(s), window.removeEventListener("message", a));
                const g = (f = o == null ? void 0 : o.data) == null ? void 0 : f.payload;
                if (g && g.auth_resp !== null)
                  try {
                    const h = g.auth_resp,
                      l = {
                        client_id: this.options.clientId,
                        access_token: h.access_token,
                        account_id: h.account_id,
                        expires_in: h.expires_in,
                        scope: this.scope,
                        refresh_token: h.refresh_token,
                      };
                    (await this._saveEntryInMemoryOnly(l),
                      n({access_token: h.access_token, account_id: h.account_id, expires_in: h.expires_in}));
                  } catch (h) {
                    (console.error("Failed to save token:", h), n({}));
                  }
                else (console.warn("Guest mode, no logged in"), n(void 0));
              }
            }
          };
        window.addEventListener("message", a);
        try {
          if (typeof window > "u" || !window.parent || window === window.parent) {
            (clearTimeout(s),
              window.removeEventListener("message", a),
              console.error("Not in an iframe or window.parent is unavailable."));
            return;
          }
          window.parent.postMessage({methods: "VIVERSE_SDK/checkAuth", payload: {appId: this.options.clientId}}, "*");
        } catch (o) {
          (console.error("Failed to send postMessage:", o),
            clearTimeout(s),
            window.removeEventListener("message", a),
            n(void 0));
        }
      });
    }
    loginWithWorlds(t = {}) {
      const e = t.state ? ve(t.state) : ve(de());
      try {
        if (typeof window > "u" || !window.parent || window === window.parent) {
          console.error("Not in an iframe or window.parent is unavailable.");
          return;
        }
        window.parent.postMessage({methods: "VIVERSE_SDK/login", payload: {state: e, appId: this.options.clientId}}, "*");
      } catch (r) {
        throw (console.error("postMessage error:", r), r);
      }
    }
    async logoutWithWorlds() {
      await this.cacheManager.clear(this.options.clientId);
      try {
        if (typeof window > "u" || !window.parent || window === window.parent) {
          console.error("window.parent is not available or not in an iframe.");
          return;
        }
        window.parent.postMessage({methods: "VIVERSE_SDK/logout", payload: {}}, "*");
      } catch (t) {
        throw (console.error("postMessage error:", t), t);
      }
    }
    async _getEntryFromCache({scope: t, clientId: e}) {
      await this._waitForCacheSetup();
      const r = await this.cacheManager.get(new l0({scope: t, clientId: e}), 60);
      if (r) {
        const {access_token: n, account_id: s, expires_in: a, refresh_token: o, scope: x} = r,
          c = {access_token: n, account_id: s, expires_in: a, refresh_token: o, scope: x};
        return "created_at" in r || "state" in r ? {...c, created_at: r.created_at, state: r.state} : c;
      }
    }
    async _waitForCacheSetup() {
      this._cacheSetupDone ||
        (await new Promise((t) => {
          const e = setInterval(() => {
            this._cacheSetupDone && (clearInterval(e), t(!0));
          }, 100);
        }));
    }
  }
  async function Ai({baseUrl: i, timeout: t, token: e}) {
    return await r0(`${i}api/meetingareaselector/v2/newgenavatar/sdk/me`, t, {
      method: "GET",
      headers: {"Content-Type": "application/json", AccessToken: e},
    });
  }
  async function ye({baseUrl: i, timeout: t, token: e}) {
    return await r0(`${i}api/meetingareaselector/v1/newgenavatar/getavatarlist`, t, {
      method: "GET",
      headers: {"Content-Type": "application/json", AccessToken: e},
    });
  }
  async function Ci({baseUrl: i, timeout: t}) {
    return await r0(`${i}items/publicAvatar`, t, {method: "GET", headers: {"Content-Type": "application/json"}});
  }
  async function mi({baseUrl: i, timeout: t, avatarID: e}) {
    return await r0(`${i}items/publicAvatar/${e}`, t, {method: "GET", headers: {"Content-Type": "application/json"}});
  }
  class Yt {
    constructor(t) {
      H(this, "avatarSDKUrl", "https://avatar.viverse.com/static-misc/avatar-js-sdk/1.1.1/Avatar-SDK.js");
      H(this, "baseURL");
      H(this, "token");
      H(this, "anonymousAvatarSDK");
      H(this, "scriptLoading", !1);
      ((this.baseURL = t.baseURL), (this.token = t.token || null), this._initializeAvatar());
    }
    async _initializeAvatar() {
      (globalThis.newViveAvatarSdk || ((this.scriptLoading = !0), await I0(this.avatarSDKUrl), (this.scriptLoading = !1)),
        (this.anonymousAvatarSDK = globalThis.newViveAvatarSdk(
          {workerMinimum: 1, workerMaximum: Math.max(1, window.navigator.hardwareConcurrency - 1)},
          this.avatarSDKUrl,
        )));
    }
    async getProfile() {
      if (!this.token) throw Error("This API is only available to logged-in users.");
      const [t, e] = await Promise.all([this._getMe(this.token), this.getActiveAvatar()]);
      return {name: (t == null ? void 0 : t.Name) || "", activeAvatar: e};
    }
    async _getMe(t) {
      try {
        const {data: e} = await Ai({baseUrl: this.baseURL, token: t});
        return e;
      } catch (e) {
        return (console.error("Get me error:", e), null);
      }
    }
    async getAvatarList() {
      if (!this.token) throw Error("This API is only available to logged-in users.");
      return await ye({baseUrl: this.baseURL, token: this.token})
        .then(({data: e}) => e.Avatars ?? [])
        .then((e) => e.map(this._formatPrivateAvatar))
        .catch((e) => (console.error("Get avatar list error:", e), []));
    }
    async getActiveAvatar() {
      if (!this.token) throw Error("This API is only available to logged-in users.");
      return await ye({baseUrl: this.baseURL, token: this.token})
        .then(({data: e}) => {
          if (!e.CurrentAvatarId || !e.Avatars) return null;
          const r = e.Avatars.find((n) => n.id === e.CurrentAvatarId);
          return r ? this._formatPrivateAvatar(r) : null;
        })
        .catch((e) => (console.error("Get avatar list error:", e), null));
    }
    async getPublicAvatarList() {
      try {
        const {data: t} = await Ci({baseUrl: this.baseURL});
        return t.map((e) => this._formatPublicAvatar(this._parsePublicAvatarUrl(e)));
      } catch (t) {
        return (console.error("Get public avatar list error:", t), []);
      }
    }
    async getPublicAvatarByID(t) {
      try {
        const {data: e} = await mi({baseUrl: this.baseURL, avatarID: t});
        return this._formatPublicAvatar(this._parsePublicAvatarUrl(e));
      } catch (e) {
        return (console.error("Get public avatar error:", e), null);
      }
    }
    _formatPrivateAvatar(t) {
      return {
        id: t.id || "",
        isPrivate: !0,
        vrmUrl: t.VrmBinaryDataUrl || "",
        headIconUrl: t.HeadIconDataUrl || "",
        snapshot: t.SnapshotDataUrl || "",
        createTime: t.CreateTime * 1e3 || 0,
        updateTime: t.UpdateTime * 1e3 || 0,
      };
    }
    _formatPublicAvatar(t) {
      return {
        id: t.id || 0,
        isPrivate: !1,
        vrmUrl: t.model,
        headIconUrl: t.head_icon,
        snapshot: t.snapshot,
        createTime: new Date(t.date_created).getTime(),
        updateTime: t.date_updated ? new Date(t.date_updated).getTime() : new Date(t.date_created).getTime(),
      };
    }
    _parsePublicAvatarUrl(t) {
      return {
        ...t,
        head_icon: `${this.baseURL}assets/${t.head_icon}`,
        model: `${this.baseURL}assets/${t.model}`,
        snapshot: `${this.baseURL}assets/${t.snapshot}`,
      };
    }
    async getAvatarFileWithSDK(t) {
      return typeof (await P0(this, "scriptLoading", !1)) > "u"
        ? (console.error("avatar SDK script loading error"), null)
        : (this.anonymousAvatarSDK || (await this._initializeAvatar()),
          await this.anonymousAvatarSDK
            .viaWorker({action: "downloadAndDecrypt", params: {modelUrl: t}})
            .then((n) => n.arrayBuffer)
            .catch((n) => (console.error("Get avatar file via worker error: ", n), null)));
    }
  }
  async function Ee({baseUrl: i, timeout: t, token: e, authKey: r, appID: n, getLeaderboardParams: s}) {
    const a = {};
    return (
      e ? (a.AccessToken = e) : r && (a.AuthKey = r),
      await r0(`${i}api/vrleaderboard/v1/apps/${n}/metas/ranking?${s}`, t, {
        method: "GET",
        headers: {"Content-Type": "application/json", ...a},
      })
    );
  }
  async function Be({baseUrl: i, timeout: t, appID: e, getGuestLeaderboardParams: r}) {
    return await r0(`${i}api/vrleaderboard/v1/apps/${e}/metas/guest_ranking?${r}`, t, {
      method: "GET",
      headers: {"Content-Type": "application/json"},
    });
  }
  async function De({baseUrl: i, token: t, authKey: e, appID: r, publicKey: n, timeout: s}) {
    const a = {};
    return (
      t ? (a.AccessToken = t) : e && (a.AuthKey = e),
      await r0(`${i}api/ironhide/v1/token?app_id=${r}&skip_ua=true`, s, {
        method: "GET",
        headers: {"x-htc-public-key-format": "x509", "Content-Type": "application/json", "x-htc-public-key": n, ...a},
      })
    );
  }
  async function Ae({baseUrl: i, token: t, authKey: e, appID: r, sessionToken: n, scores: s, timeout: a}) {
    const o = {};
    return (
      t ? (o.AccessToken = t) : e && (o.AuthKey = e),
      await r0(`${i}api/vrleaderboard/v1/apps/${r}`, a, {
        method: "POST",
        headers: {"Content-Type": "application/json", ...o, Token: n},
        body: JSON.stringify(s),
      })
    );
  }
  async function wi({communityBaseURL: i, timeout: t, communityConfig: e}) {
    return await r0(`${i}api/community-service/v1/users/get`, t, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(e),
    });
  }
  async function Ce({baseUrl: i, timeout: t, token: e, authKey: r, appID: n}) {
    const s = {};
    return (
      e ? (s.AccessToken = e) : r && (s.AuthKey = r),
      await r0(`${i}api/optimusprime/v1/achievement/${n}`, t, {
        method: "GET",
        headers: {"Content-Type": "application/json", ...s},
      })
    );
  }
  async function me({baseUrl: i, token: t, authKey: e, appID: r, sessionToken: n, data: s, timeout: a}) {
    const o = {};
    return (
      t ? (o.AccessToken = t) : e && (o.AuthKey = e),
      await r0(`${i}api/optimusprime/v1/achievement/${r}`, a, {
        method: "POST",
        headers: {"Content-Type": "application/json", ...o, "x-htc-op-token": n},
        body: JSON.stringify(s),
      })
    );
  }
  var bi = "0123456789abcdefghijklmnopqrstuvwxyz";
  function h0(i) {
    return bi.charAt(i);
  }
  function _i(i, t) {
    return i & t;
  }
  function Z0(i, t) {
    return i | t;
  }
  function we(i, t) {
    return i ^ t;
  }
  function be(i, t) {
    return i & ~t;
  }
  function Fi(i) {
    if (i == 0) return -1;
    var t = 0;
    return (
      (i & 65535) == 0 && ((i >>= 16), (t += 16)),
      (i & 255) == 0 && ((i >>= 8), (t += 8)),
      (i & 15) == 0 && ((i >>= 4), (t += 4)),
      (i & 3) == 0 && ((i >>= 2), (t += 2)),
      (i & 1) == 0 && ++t,
      t
    );
  }
  function Si(i) {
    for (var t = 0; i != 0; ) ((i &= i - 1), ++t);
    return t;
  }
  var w0 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
    _e = "=";
  function X0(i) {
    var t,
      e,
      r = "";
    for (t = 0; t + 3 <= i.length; t += 3)
      ((e = parseInt(i.substring(t, t + 3), 16)), (r += w0.charAt(e >> 6) + w0.charAt(e & 63)));
    for (
      t + 1 == i.length
        ? ((e = parseInt(i.substring(t, t + 1), 16)), (r += w0.charAt(e << 2)))
        : t + 2 == i.length &&
          ((e = parseInt(i.substring(t, t + 2), 16)), (r += w0.charAt(e >> 2) + w0.charAt((e & 3) << 4)));
      (r.length & 3) > 0;
    )
      r += _e;
    return r;
  }
  function Fe(i) {
    var t = "",
      e,
      r = 0,
      n = 0;
    for (e = 0; e < i.length && i.charAt(e) != _e; ++e) {
      var s = w0.indexOf(i.charAt(e));
      s < 0 ||
        (r == 0
          ? ((t += h0(s >> 2)), (n = s & 3), (r = 1))
          : r == 1
            ? ((t += h0((n << 2) | (s >> 4))), (n = s & 15), (r = 2))
            : r == 2
              ? ((t += h0(n)), (t += h0(s >> 2)), (n = s & 3), (r = 3))
              : ((t += h0((n << 2) | (s >> 4))), (t += h0(s & 15)), (r = 0)));
    }
    return (r == 1 && (t += h0(n << 2)), t);
  }
  var b0,
    Ti = {
      decode: function (i) {
        var t;
        if (b0 === void 0) {
          var e = "0123456789ABCDEF",
            r = ` \f
\r	 \u2028\u2029`;
          for (b0 = {}, t = 0; t < 16; ++t) b0[e.charAt(t)] = t;
          for (e = e.toLowerCase(), t = 10; t < 16; ++t) b0[e.charAt(t)] = t;
          for (t = 0; t < r.length; ++t) b0[r.charAt(t)] = -1;
        }
        var n = [],
          s = 0,
          a = 0;
        for (t = 0; t < i.length; ++t) {
          var o = i.charAt(t);
          if (o == "=") break;
          if (((o = b0[o]), o != -1)) {
            if (o === void 0) throw new Error("Illegal character at offset " + t);
            ((s |= o), ++a >= 2 ? ((n[n.length] = s), (s = 0), (a = 0)) : (s <<= 4));
          }
        }
        if (a) throw new Error("Hex encoding incomplete: 4 bits missing");
        return n;
      },
    },
    D0,
    Qt = {
      decode: function (i) {
        var t;
        if (D0 === void 0) {
          var e = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
            r = `= \f
\r	 \u2028\u2029`;
          for (D0 = Object.create(null), t = 0; t < 64; ++t) D0[e.charAt(t)] = t;
          for (D0["-"] = 62, D0._ = 63, t = 0; t < r.length; ++t) D0[r.charAt(t)] = -1;
        }
        var n = [],
          s = 0,
          a = 0;
        for (t = 0; t < i.length; ++t) {
          var o = i.charAt(t);
          if (o == "=") break;
          if (((o = D0[o]), o != -1)) {
            if (o === void 0) throw new Error("Illegal character at offset " + t);
            ((s |= o),
              ++a >= 4
                ? ((n[n.length] = s >> 16), (n[n.length] = (s >> 8) & 255), (n[n.length] = s & 255), (s = 0), (a = 0))
                : (s <<= 6));
          }
        }
        switch (a) {
          case 1:
            throw new Error("Base64 encoding incomplete: at least 2 bits missing");
          case 2:
            n[n.length] = s >> 10;
            break;
          case 3:
            ((n[n.length] = s >> 16), (n[n.length] = (s >> 8) & 255));
            break;
        }
        return n;
      },
      re: /-----BEGIN [^-]+-----([A-Za-z0-9+\/=\s]+)-----END [^-]+-----|begin-base64[^\n]+\n([A-Za-z0-9+\/=\s]+)====/,
      unarmor: function (i) {
        var t = Qt.re.exec(i);
        if (t)
          if (t[1]) i = t[1];
          else if (t[2]) i = t[2];
          else throw new Error("RegExp out of sync");
        return Qt.decode(i);
      },
    },
    _0 = 1e13,
    L0 = (function () {
      function i(t) {
        this.buf = [+t || 0];
      }
      return (
        (i.prototype.mulAdd = function (t, e) {
          var r = this.buf,
            n = r.length,
            s,
            a;
          for (s = 0; s < n; ++s) ((a = r[s] * t + e), a < _0 ? (e = 0) : ((e = 0 | (a / _0)), (a -= e * _0)), (r[s] = a));
          e > 0 && (r[s] = e);
        }),
        (i.prototype.sub = function (t) {
          var e = this.buf,
            r = e.length,
            n,
            s;
          for (n = 0; n < r; ++n) ((s = e[n] - t), s < 0 ? ((s += _0), (t = 1)) : (t = 0), (e[n] = s));
          for (; e[e.length - 1] === 0; ) e.pop();
        }),
        (i.prototype.toString = function (t) {
          if ((t || 10) != 10) throw new Error("only base 10 is supported");
          for (var e = this.buf, r = e[e.length - 1].toString(), n = e.length - 2; n >= 0; --n)
            r += (_0 + e[n]).toString().substring(1);
          return r;
        }),
        (i.prototype.valueOf = function () {
          for (var t = this.buf, e = 0, r = t.length - 1; r >= 0; --r) e = e * _0 + t[r];
          return e;
        }),
        (i.prototype.simplify = function () {
          var t = this.buf;
          return t.length == 1 ? t[0] : this;
        }),
        i
      );
    })(),
    Se = "…",
    ki =
      /^(\d\d)(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])([01]\d|2[0-3])(?:([0-5]\d)(?:([0-5]\d)(?:[.,](\d{1,3}))?)?)?(Z|[-+](?:[0]\d|1[0-2])([0-5]\d)?)?$/,
    Ri =
      /^(\d\d\d\d)(0[1-9]|1[0-2])(0[1-9]|[12]\d|3[01])([01]\d|2[0-3])(?:([0-5]\d)(?:([0-5]\d)(?:[.,](\d{1,3}))?)?)?(Z|[-+](?:[0]\d|1[0-2])([0-5]\d)?)?$/;
  function F0(i, t) {
    return (i.length > t && (i = i.substring(0, t) + Se), i);
  }
  var Jt = (function () {
      function i(t, e) {
        ((this.hexDigits = "0123456789ABCDEF"),
          t instanceof i ? ((this.enc = t.enc), (this.pos = t.pos)) : ((this.enc = t), (this.pos = e)));
      }
      return (
        (i.prototype.get = function (t) {
          if ((t === void 0 && (t = this.pos++), t >= this.enc.length))
            throw new Error("Requesting byte offset ".concat(t, " on a stream of length ").concat(this.enc.length));
          return typeof this.enc == "string" ? this.enc.charCodeAt(t) : this.enc[t];
        }),
        (i.prototype.hexByte = function (t) {
          return this.hexDigits.charAt((t >> 4) & 15) + this.hexDigits.charAt(t & 15);
        }),
        (i.prototype.hexDump = function (t, e, r) {
          for (var n = "", s = t; s < e; ++s)
            if (((n += this.hexByte(this.get(s))), r !== !0))
              switch (s & 15) {
                case 7:
                  n += "  ";
                  break;
                case 15:
                  n += `
`;
                  break;
                default:
                  n += " ";
              }
          return n;
        }),
        (i.prototype.isASCII = function (t, e) {
          for (var r = t; r < e; ++r) {
            var n = this.get(r);
            if (n < 32 || n > 176) return !1;
          }
          return !0;
        }),
        (i.prototype.parseStringISO = function (t, e) {
          for (var r = "", n = t; n < e; ++n) r += String.fromCharCode(this.get(n));
          return r;
        }),
        (i.prototype.parseStringUTF = function (t, e) {
          for (var r = "", n = t; n < e; ) {
            var s = this.get(n++);
            s < 128
              ? (r += String.fromCharCode(s))
              : s > 191 && s < 224
                ? (r += String.fromCharCode(((s & 31) << 6) | (this.get(n++) & 63)))
                : (r += String.fromCharCode(((s & 15) << 12) | ((this.get(n++) & 63) << 6) | (this.get(n++) & 63)));
          }
          return r;
        }),
        (i.prototype.parseStringBMP = function (t, e) {
          for (var r = "", n, s, a = t; a < e; )
            ((n = this.get(a++)), (s = this.get(a++)), (r += String.fromCharCode((n << 8) | s)));
          return r;
        }),
        (i.prototype.parseTime = function (t, e, r) {
          var n = this.parseStringISO(t, e),
            s = (r ? ki : Ri).exec(n);
          return s
            ? (r && ((s[1] = +s[1]), (s[1] += +s[1] < 70 ? 2e3 : 1900)),
              (n = s[1] + "-" + s[2] + "-" + s[3] + " " + s[4]),
              s[5] && ((n += ":" + s[5]), s[6] && ((n += ":" + s[6]), s[7] && (n += "." + s[7]))),
              s[8] && ((n += " UTC"), s[8] != "Z" && ((n += s[8]), s[9] && (n += ":" + s[9]))),
              n)
            : "Unrecognized time: " + n;
        }),
        (i.prototype.parseInteger = function (t, e) {
          for (var r = this.get(t), n = r > 127, s = n ? 255 : 0, a, o = ""; r == s && ++t < e; ) r = this.get(t);
          if (((a = e - t), a === 0)) return n ? -1 : 0;
          if (a > 4) {
            for (o = r, a <<= 3; ((+o ^ s) & 128) == 0; ) ((o = +o << 1), --a);
            o =
              "(" +
              a +
              ` bit)
`;
          }
          n && (r = r - 256);
          for (var x = new L0(r), c = t + 1; c < e; ++c) x.mulAdd(256, this.get(c));
          return o + x.toString();
        }),
        (i.prototype.parseBitString = function (t, e, r) {
          for (
            var n = this.get(t),
              s = ((e - t - 1) << 3) - n,
              a =
                "(" +
                s +
                ` bit)
`,
              o = "",
              x = t + 1;
            x < e;
            ++x
          ) {
            for (var c = this.get(x), f = x == e - 1 ? n : 0, g = 7; g >= f; --g) o += (c >> g) & 1 ? "1" : "0";
            if (o.length > r) return a + F0(o, r);
          }
          return a + o;
        }),
        (i.prototype.parseOctetString = function (t, e, r) {
          if (this.isASCII(t, e)) return F0(this.parseStringISO(t, e), r);
          var n = e - t,
            s =
              "(" +
              n +
              ` byte)
`;
          ((r /= 2), n > r && (e = t + r));
          for (var a = t; a < e; ++a) s += this.hexByte(this.get(a));
          return (n > r && (s += Se), s);
        }),
        (i.prototype.parseOID = function (t, e, r) {
          for (var n = "", s = new L0(), a = 0, o = t; o < e; ++o) {
            var x = this.get(o);
            if ((s.mulAdd(128, x & 127), (a += 7), !(x & 128))) {
              if (n === "")
                if (((s = s.simplify()), s instanceof L0)) (s.sub(80), (n = "2." + s.toString()));
                else {
                  var c = s < 80 ? (s < 40 ? 0 : 1) : 2;
                  n = c + "." + (s - c * 40);
                }
              else n += "." + s.toString();
              if (n.length > r) return F0(n, r);
              ((s = new L0()), (a = 0));
            }
          }
          return (a > 0 && (n += ".incomplete"), n);
        }),
        i
      );
    })(),
    Ii = (function () {
      function i(t, e, r, n, s) {
        if (!(n instanceof Te)) throw new Error("Invalid tag value.");
        ((this.stream = t), (this.header = e), (this.length = r), (this.tag = n), (this.sub = s));
      }
      return (
        (i.prototype.typeName = function () {
          switch (this.tag.tagClass) {
            case 0:
              switch (this.tag.tagNumber) {
                case 0:
                  return "EOC";
                case 1:
                  return "BOOLEAN";
                case 2:
                  return "INTEGER";
                case 3:
                  return "BIT_STRING";
                case 4:
                  return "OCTET_STRING";
                case 5:
                  return "NULL";
                case 6:
                  return "OBJECT_IDENTIFIER";
                case 7:
                  return "ObjectDescriptor";
                case 8:
                  return "EXTERNAL";
                case 9:
                  return "REAL";
                case 10:
                  return "ENUMERATED";
                case 11:
                  return "EMBEDDED_PDV";
                case 12:
                  return "UTF8String";
                case 16:
                  return "SEQUENCE";
                case 17:
                  return "SET";
                case 18:
                  return "NumericString";
                case 19:
                  return "PrintableString";
                case 20:
                  return "TeletexString";
                case 21:
                  return "VideotexString";
                case 22:
                  return "IA5String";
                case 23:
                  return "UTCTime";
                case 24:
                  return "GeneralizedTime";
                case 25:
                  return "GraphicString";
                case 26:
                  return "VisibleString";
                case 27:
                  return "GeneralString";
                case 28:
                  return "UniversalString";
                case 30:
                  return "BMPString";
              }
              return "Universal_" + this.tag.tagNumber.toString();
            case 1:
              return "Application_" + this.tag.tagNumber.toString();
            case 2:
              return "[" + this.tag.tagNumber.toString() + "]";
            case 3:
              return "Private_" + this.tag.tagNumber.toString();
          }
        }),
        (i.prototype.content = function (t) {
          if (this.tag === void 0) return null;
          t === void 0 && (t = 1 / 0);
          var e = this.posContent(),
            r = Math.abs(this.length);
          if (!this.tag.isUniversal())
            return this.sub !== null ? "(" + this.sub.length + " elem)" : this.stream.parseOctetString(e, e + r, t);
          switch (this.tag.tagNumber) {
            case 1:
              return this.stream.get(e) === 0 ? "false" : "true";
            case 2:
              return this.stream.parseInteger(e, e + r);
            case 3:
              return this.sub ? "(" + this.sub.length + " elem)" : this.stream.parseBitString(e, e + r, t);
            case 4:
              return this.sub ? "(" + this.sub.length + " elem)" : this.stream.parseOctetString(e, e + r, t);
            case 6:
              return this.stream.parseOID(e, e + r, t);
            case 16:
            case 17:
              return this.sub !== null ? "(" + this.sub.length + " elem)" : "(no elem)";
            case 12:
              return F0(this.stream.parseStringUTF(e, e + r), t);
            case 18:
            case 19:
            case 20:
            case 21:
            case 22:
            case 26:
              return F0(this.stream.parseStringISO(e, e + r), t);
            case 30:
              return F0(this.stream.parseStringBMP(e, e + r), t);
            case 23:
            case 24:
              return this.stream.parseTime(e, e + r, this.tag.tagNumber == 23);
          }
          return null;
        }),
        (i.prototype.toString = function () {
          return (
            this.typeName() +
            "@" +
            this.stream.pos +
            "[header:" +
            this.header +
            ",length:" +
            this.length +
            ",sub:" +
            (this.sub === null ? "null" : this.sub.length) +
            "]"
          );
        }),
        (i.prototype.toPrettyString = function (t) {
          t === void 0 && (t = "");
          var e = t + this.typeName() + " @" + this.stream.pos;
          if (
            (this.length >= 0 && (e += "+"),
            (e += this.length),
            this.tag.tagConstructed
              ? (e += " (constructed)")
              : this.tag.isUniversal() &&
                (this.tag.tagNumber == 3 || this.tag.tagNumber == 4) &&
                this.sub !== null &&
                (e += " (encapsulates)"),
            (e += `
`),
            this.sub !== null)
          ) {
            t += "  ";
            for (var r = 0, n = this.sub.length; r < n; ++r) e += this.sub[r].toPrettyString(t);
          }
          return e;
        }),
        (i.prototype.posStart = function () {
          return this.stream.pos;
        }),
        (i.prototype.posContent = function () {
          return this.stream.pos + this.header;
        }),
        (i.prototype.posEnd = function () {
          return this.stream.pos + this.header + Math.abs(this.length);
        }),
        (i.prototype.toHexString = function () {
          return this.stream.hexDump(this.posStart(), this.posEnd(), !0);
        }),
        (i.decodeLength = function (t) {
          var e = t.get(),
            r = e & 127;
          if (r == e) return r;
          if (r > 6) throw new Error("Length over 48 bits not supported at position " + (t.pos - 1));
          if (r === 0) return null;
          e = 0;
          for (var n = 0; n < r; ++n) e = e * 256 + t.get();
          return e;
        }),
        (i.prototype.getHexStringValue = function () {
          var t = this.toHexString(),
            e = this.header * 2,
            r = this.length * 2;
          return t.substr(e, r);
        }),
        (i.decode = function (t) {
          var e;
          t instanceof Jt ? (e = t) : (e = new Jt(t, 0));
          var r = new Jt(e),
            n = new Te(e),
            s = i.decodeLength(e),
            a = e.pos,
            o = a - r.pos,
            x = null,
            c = function () {
              var g = [];
              if (s !== null) {
                for (var h = a + s; e.pos < h; ) g[g.length] = i.decode(e);
                if (e.pos != h) throw new Error("Content size is not correct for container starting at offset " + a);
              } else
                try {
                  for (;;) {
                    var l = i.decode(e);
                    if (l.tag.isEOC()) break;
                    g[g.length] = l;
                  }
                  s = a - e.pos;
                } catch (d) {
                  throw new Error("Exception while decoding undefined length content: " + d);
                }
              return g;
            };
          if (n.tagConstructed) x = c();
          else if (n.isUniversal() && (n.tagNumber == 3 || n.tagNumber == 4))
            try {
              if (n.tagNumber == 3 && e.get() != 0) throw new Error("BIT STRINGs with unused bits cannot encapsulate.");
              x = c();
              for (var f = 0; f < x.length; ++f)
                if (x[f].tag.isEOC()) throw new Error("EOC is not supposed to be actual content.");
            } catch {
              x = null;
            }
          if (x === null) {
            if (s === null) throw new Error("We can't skip over an invalid tag with undefined length at offset " + a);
            e.pos = a + Math.abs(s);
          }
          return new i(r, o, s, n, x);
        }),
        i
      );
    })(),
    Te = (function () {
      function i(t) {
        var e = t.get();
        if (
          ((this.tagClass = e >> 6),
          (this.tagConstructed = (e & 32) !== 0),
          (this.tagNumber = e & 31),
          this.tagNumber == 31)
        ) {
          var r = new L0();
          do ((e = t.get()), r.mulAdd(128, e & 127));
          while (e & 128);
          this.tagNumber = r.simplify();
        }
      }
      return (
        (i.prototype.isUniversal = function () {
          return this.tagClass === 0;
        }),
        (i.prototype.isEOC = function () {
          return this.tagClass === 0 && this.tagNumber === 0;
        }),
        i
      );
    })(),
    d0,
    Pi = 0xdeadbeefcafe,
    ke = (Pi & 16777215) == 15715070,
    J = [
      2, 3, 5, 7, 11, 13, 17, 19, 23, 29, 31, 37, 41, 43, 47, 53, 59, 61, 67, 71, 73, 79, 83, 89, 97, 101, 103, 107, 109,
      113, 127, 131, 137, 139, 149, 151, 157, 163, 167, 173, 179, 181, 191, 193, 197, 199, 211, 223, 227, 229, 233, 239,
      241, 251, 257, 263, 269, 271, 277, 281, 283, 293, 307, 311, 313, 317, 331, 337, 347, 349, 353, 359, 367, 373, 379,
      383, 389, 397, 401, 409, 419, 421, 431, 433, 439, 443, 449, 457, 461, 463, 467, 479, 487, 491, 499, 503, 509, 521,
      523, 541, 547, 557, 563, 569, 571, 577, 587, 593, 599, 601, 607, 613, 617, 619, 631, 641, 643, 647, 653, 659, 661,
      673, 677, 683, 691, 701, 709, 719, 727, 733, 739, 743, 751, 757, 761, 769, 773, 787, 797, 809, 811, 821, 823, 827,
      829, 839, 853, 857, 859, 863, 877, 881, 883, 887, 907, 911, 919, 929, 937, 941, 947, 953, 967, 971, 977, 983, 991,
      997,
    ],
    Oi = (1 << 26) / J[J.length - 1],
    L = (function () {
      function i(t, e, r) {
        t != null &&
          (typeof t == "number"
            ? this.fromNumber(t, e, r)
            : e == null && typeof t != "string"
              ? this.fromString(t, 256)
              : this.fromString(t, e));
      }
      return (
        (i.prototype.toString = function (t) {
          if (this.s < 0) return "-" + this.negate().toString(t);
          var e;
          if (t == 16) e = 4;
          else if (t == 8) e = 3;
          else if (t == 2) e = 1;
          else if (t == 32) e = 5;
          else if (t == 4) e = 2;
          else return this.toRadix(t);
          var r = (1 << e) - 1,
            n,
            s = !1,
            a = "",
            o = this.t,
            x = this.DB - ((o * this.DB) % e);
          if (o-- > 0)
            for (x < this.DB && (n = this[o] >> x) > 0 && ((s = !0), (a = h0(n))); o >= 0; )
              (x < e
                ? ((n = (this[o] & ((1 << x) - 1)) << (e - x)), (n |= this[--o] >> (x += this.DB - e)))
                : ((n = (this[o] >> (x -= e)) & r), x <= 0 && ((x += this.DB), --o)),
                n > 0 && (s = !0),
                s && (a += h0(n)));
          return s ? a : "0";
        }),
        (i.prototype.negate = function () {
          var t = q();
          return (i.ZERO.subTo(this, t), t);
        }),
        (i.prototype.abs = function () {
          return this.s < 0 ? this.negate() : this;
        }),
        (i.prototype.compareTo = function (t) {
          var e = this.s - t.s;
          if (e != 0) return e;
          var r = this.t;
          if (((e = r - t.t), e != 0)) return this.s < 0 ? -e : e;
          for (; --r >= 0; ) if ((e = this[r] - t[r]) != 0) return e;
          return 0;
        }),
        (i.prototype.bitLength = function () {
          return this.t <= 0 ? 0 : this.DB * (this.t - 1) + Q0(this[this.t - 1] ^ (this.s & this.DM));
        }),
        (i.prototype.mod = function (t) {
          var e = q();
          return (this.abs().divRemTo(t, null, e), this.s < 0 && e.compareTo(i.ZERO) > 0 && t.subTo(e, e), e);
        }),
        (i.prototype.modPowInt = function (t, e) {
          var r;
          return (t < 256 || e.isEven() ? (r = new Re(e)) : (r = new Ie(e)), this.exp(t, r));
        }),
        (i.prototype.clone = function () {
          var t = q();
          return (this.copyTo(t), t);
        }),
        (i.prototype.intValue = function () {
          if (this.s < 0) {
            if (this.t == 1) return this[0] - this.DV;
            if (this.t == 0) return -1;
          } else {
            if (this.t == 1) return this[0];
            if (this.t == 0) return 0;
          }
          return ((this[1] & ((1 << (32 - this.DB)) - 1)) << this.DB) | this[0];
        }),
        (i.prototype.byteValue = function () {
          return this.t == 0 ? this.s : (this[0] << 24) >> 24;
        }),
        (i.prototype.shortValue = function () {
          return this.t == 0 ? this.s : (this[0] << 16) >> 16;
        }),
        (i.prototype.signum = function () {
          return this.s < 0 ? -1 : this.t <= 0 || (this.t == 1 && this[0] <= 0) ? 0 : 1;
        }),
        (i.prototype.toByteArray = function () {
          var t = this.t,
            e = [];
          e[0] = this.s;
          var r = this.DB - ((t * this.DB) % 8),
            n,
            s = 0;
          if (t-- > 0)
            for (
              r < this.DB && (n = this[t] >> r) != (this.s & this.DM) >> r && (e[s++] = n | (this.s << (this.DB - r)));
              t >= 0;
            )
              (r < 8
                ? ((n = (this[t] & ((1 << r) - 1)) << (8 - r)), (n |= this[--t] >> (r += this.DB - 8)))
                : ((n = (this[t] >> (r -= 8)) & 255), r <= 0 && ((r += this.DB), --t)),
                (n & 128) != 0 && (n |= -256),
                s == 0 && (this.s & 128) != (n & 128) && ++s,
                (s > 0 || n != this.s) && (e[s++] = n));
          return e;
        }),
        (i.prototype.equals = function (t) {
          return this.compareTo(t) == 0;
        }),
        (i.prototype.min = function (t) {
          return this.compareTo(t) < 0 ? this : t;
        }),
        (i.prototype.max = function (t) {
          return this.compareTo(t) > 0 ? this : t;
        }),
        (i.prototype.and = function (t) {
          var e = q();
          return (this.bitwiseTo(t, _i, e), e);
        }),
        (i.prototype.or = function (t) {
          var e = q();
          return (this.bitwiseTo(t, Z0, e), e);
        }),
        (i.prototype.xor = function (t) {
          var e = q();
          return (this.bitwiseTo(t, we, e), e);
        }),
        (i.prototype.andNot = function (t) {
          var e = q();
          return (this.bitwiseTo(t, be, e), e);
        }),
        (i.prototype.not = function () {
          for (var t = q(), e = 0; e < this.t; ++e) t[e] = this.DM & ~this[e];
          return ((t.t = this.t), (t.s = ~this.s), t);
        }),
        (i.prototype.shiftLeft = function (t) {
          var e = q();
          return (t < 0 ? this.rShiftTo(-t, e) : this.lShiftTo(t, e), e);
        }),
        (i.prototype.shiftRight = function (t) {
          var e = q();
          return (t < 0 ? this.lShiftTo(-t, e) : this.rShiftTo(t, e), e);
        }),
        (i.prototype.getLowestSetBit = function () {
          for (var t = 0; t < this.t; ++t) if (this[t] != 0) return t * this.DB + Fi(this[t]);
          return this.s < 0 ? this.t * this.DB : -1;
        }),
        (i.prototype.bitCount = function () {
          for (var t = 0, e = this.s & this.DM, r = 0; r < this.t; ++r) t += Si(this[r] ^ e);
          return t;
        }),
        (i.prototype.testBit = function (t) {
          var e = Math.floor(t / this.DB);
          return e >= this.t ? this.s != 0 : (this[e] & (1 << (t % this.DB))) != 0;
        }),
        (i.prototype.setBit = function (t) {
          return this.changeBit(t, Z0);
        }),
        (i.prototype.clearBit = function (t) {
          return this.changeBit(t, be);
        }),
        (i.prototype.flipBit = function (t) {
          return this.changeBit(t, we);
        }),
        (i.prototype.add = function (t) {
          var e = q();
          return (this.addTo(t, e), e);
        }),
        (i.prototype.subtract = function (t) {
          var e = q();
          return (this.subTo(t, e), e);
        }),
        (i.prototype.multiply = function (t) {
          var e = q();
          return (this.multiplyTo(t, e), e);
        }),
        (i.prototype.divide = function (t) {
          var e = q();
          return (this.divRemTo(t, e, null), e);
        }),
        (i.prototype.remainder = function (t) {
          var e = q();
          return (this.divRemTo(t, null, e), e);
        }),
        (i.prototype.divideAndRemainder = function (t) {
          var e = q(),
            r = q();
          return (this.divRemTo(t, e, r), [e, r]);
        }),
        (i.prototype.modPow = function (t, e) {
          var r = t.bitLength(),
            n,
            s = v0(1),
            a;
          if (r <= 0) return s;
          (r < 18 ? (n = 1) : r < 48 ? (n = 3) : r < 144 ? (n = 4) : r < 768 ? (n = 5) : (n = 6),
            r < 8 ? (a = new Re(e)) : e.isEven() ? (a = new Ui(e)) : (a = new Ie(e)));
          var o = [],
            x = 3,
            c = n - 1,
            f = (1 << n) - 1;
          if (((o[1] = a.convert(this)), n > 1)) {
            var g = q();
            for (a.sqrTo(o[1], g); x <= f; ) ((o[x] = q()), a.mulTo(g, o[x - 2], o[x]), (x += 2));
          }
          var h = t.t - 1,
            l,
            d = !0,
            y = q(),
            p;
          for (r = Q0(t[h]) - 1; h >= 0; ) {
            for (
              r >= c
                ? (l = (t[h] >> (r - c)) & f)
                : ((l = (t[h] & ((1 << (r + 1)) - 1)) << (c - r)), h > 0 && (l |= t[h - 1] >> (this.DB + r - c))),
                x = n;
              (l & 1) == 0;
            )
              ((l >>= 1), --x);
            if (((r -= x) < 0 && ((r += this.DB), --h), d)) (o[l].copyTo(s), (d = !1));
            else {
              for (; x > 1; ) (a.sqrTo(s, y), a.sqrTo(y, s), (x -= 2));
              (x > 0 ? a.sqrTo(s, y) : ((p = s), (s = y), (y = p)), a.mulTo(y, o[l], s));
            }
            for (; h >= 0 && (t[h] & (1 << r)) == 0; )
              (a.sqrTo(s, y), (p = s), (s = y), (y = p), --r < 0 && ((r = this.DB - 1), --h));
          }
          return a.revert(s);
        }),
        (i.prototype.modInverse = function (t) {
          var e = t.isEven();
          if ((this.isEven() && e) || t.signum() == 0) return i.ZERO;
          for (var r = t.clone(), n = this.clone(), s = v0(1), a = v0(0), o = v0(0), x = v0(1); r.signum() != 0; ) {
            for (; r.isEven(); )
              (r.rShiftTo(1, r),
                e
                  ? ((!s.isEven() || !a.isEven()) && (s.addTo(this, s), a.subTo(t, a)), s.rShiftTo(1, s))
                  : a.isEven() || a.subTo(t, a),
                a.rShiftTo(1, a));
            for (; n.isEven(); )
              (n.rShiftTo(1, n),
                e
                  ? ((!o.isEven() || !x.isEven()) && (o.addTo(this, o), x.subTo(t, x)), o.rShiftTo(1, o))
                  : x.isEven() || x.subTo(t, x),
                x.rShiftTo(1, x));
            r.compareTo(n) >= 0
              ? (r.subTo(n, r), e && s.subTo(o, s), a.subTo(x, a))
              : (n.subTo(r, n), e && o.subTo(s, o), x.subTo(a, x));
          }
          if (n.compareTo(i.ONE) != 0) return i.ZERO;
          if (x.compareTo(t) >= 0) return x.subtract(t);
          if (x.signum() < 0) x.addTo(t, x);
          else return x;
          return x.signum() < 0 ? x.add(t) : x;
        }),
        (i.prototype.pow = function (t) {
          return this.exp(t, new Hi());
        }),
        (i.prototype.gcd = function (t) {
          var e = this.s < 0 ? this.negate() : this.clone(),
            r = t.s < 0 ? t.negate() : t.clone();
          if (e.compareTo(r) < 0) {
            var n = e;
            ((e = r), (r = n));
          }
          var s = e.getLowestSetBit(),
            a = r.getLowestSetBit();
          if (a < 0) return e;
          for (s < a && (a = s), a > 0 && (e.rShiftTo(a, e), r.rShiftTo(a, r)); e.signum() > 0; )
            ((s = e.getLowestSetBit()) > 0 && e.rShiftTo(s, e),
              (s = r.getLowestSetBit()) > 0 && r.rShiftTo(s, r),
              e.compareTo(r) >= 0 ? (e.subTo(r, e), e.rShiftTo(1, e)) : (r.subTo(e, r), r.rShiftTo(1, r)));
          return (a > 0 && r.lShiftTo(a, r), r);
        }),
        (i.prototype.isProbablePrime = function (t) {
          var e,
            r = this.abs();
          if (r.t == 1 && r[0] <= J[J.length - 1]) {
            for (e = 0; e < J.length; ++e) if (r[0] == J[e]) return !0;
            return !1;
          }
          if (r.isEven()) return !1;
          for (e = 1; e < J.length; ) {
            for (var n = J[e], s = e + 1; s < J.length && n < Oi; ) n *= J[s++];
            for (n = r.modInt(n); e < s; ) if (n % J[e++] == 0) return !1;
          }
          return r.millerRabin(t);
        }),
        (i.prototype.copyTo = function (t) {
          for (var e = this.t - 1; e >= 0; --e) t[e] = this[e];
          ((t.t = this.t), (t.s = this.s));
        }),
        (i.prototype.fromInt = function (t) {
          ((this.t = 1),
            (this.s = t < 0 ? -1 : 0),
            t > 0 ? (this[0] = t) : t < -1 ? (this[0] = t + this.DV) : (this.t = 0));
        }),
        (i.prototype.fromString = function (t, e) {
          var r;
          if (e == 16) r = 4;
          else if (e == 8) r = 3;
          else if (e == 256) r = 8;
          else if (e == 2) r = 1;
          else if (e == 32) r = 5;
          else if (e == 4) r = 2;
          else {
            this.fromRadix(t, e);
            return;
          }
          ((this.t = 0), (this.s = 0));
          for (var n = t.length, s = !1, a = 0; --n >= 0; ) {
            var o = r == 8 ? +t[n] & 255 : Oe(t, n);
            if (o < 0) {
              t.charAt(n) == "-" && (s = !0);
              continue;
            }
            ((s = !1),
              a == 0
                ? (this[this.t++] = o)
                : a + r > this.DB
                  ? ((this[this.t - 1] |= (o & ((1 << (this.DB - a)) - 1)) << a), (this[this.t++] = o >> (this.DB - a)))
                  : (this[this.t - 1] |= o << a),
              (a += r),
              a >= this.DB && (a -= this.DB));
          }
          (r == 8 && (+t[0] & 128) != 0 && ((this.s = -1), a > 0 && (this[this.t - 1] |= ((1 << (this.DB - a)) - 1) << a)),
            this.clamp(),
            s && i.ZERO.subTo(this, this));
        }),
        (i.prototype.clamp = function () {
          for (var t = this.s & this.DM; this.t > 0 && this[this.t - 1] == t; ) --this.t;
        }),
        (i.prototype.dlShiftTo = function (t, e) {
          var r;
          for (r = this.t - 1; r >= 0; --r) e[r + t] = this[r];
          for (r = t - 1; r >= 0; --r) e[r] = 0;
          ((e.t = this.t + t), (e.s = this.s));
        }),
        (i.prototype.drShiftTo = function (t, e) {
          for (var r = t; r < this.t; ++r) e[r - t] = this[r];
          ((e.t = Math.max(this.t - t, 0)), (e.s = this.s));
        }),
        (i.prototype.lShiftTo = function (t, e) {
          for (
            var r = t % this.DB,
              n = this.DB - r,
              s = (1 << n) - 1,
              a = Math.floor(t / this.DB),
              o = (this.s << r) & this.DM,
              x = this.t - 1;
            x >= 0;
            --x
          )
            ((e[x + a + 1] = (this[x] >> n) | o), (o = (this[x] & s) << r));
          for (var x = a - 1; x >= 0; --x) e[x] = 0;
          ((e[a] = o), (e.t = this.t + a + 1), (e.s = this.s), e.clamp());
        }),
        (i.prototype.rShiftTo = function (t, e) {
          e.s = this.s;
          var r = Math.floor(t / this.DB);
          if (r >= this.t) {
            e.t = 0;
            return;
          }
          var n = t % this.DB,
            s = this.DB - n,
            a = (1 << n) - 1;
          e[0] = this[r] >> n;
          for (var o = r + 1; o < this.t; ++o) ((e[o - r - 1] |= (this[o] & a) << s), (e[o - r] = this[o] >> n));
          (n > 0 && (e[this.t - r - 1] |= (this.s & a) << s), (e.t = this.t - r), e.clamp());
        }),
        (i.prototype.subTo = function (t, e) {
          for (var r = 0, n = 0, s = Math.min(t.t, this.t); r < s; )
            ((n += this[r] - t[r]), (e[r++] = n & this.DM), (n >>= this.DB));
          if (t.t < this.t) {
            for (n -= t.s; r < this.t; ) ((n += this[r]), (e[r++] = n & this.DM), (n >>= this.DB));
            n += this.s;
          } else {
            for (n += this.s; r < t.t; ) ((n -= t[r]), (e[r++] = n & this.DM), (n >>= this.DB));
            n -= t.s;
          }
          ((e.s = n < 0 ? -1 : 0), n < -1 ? (e[r++] = this.DV + n) : n > 0 && (e[r++] = n), (e.t = r), e.clamp());
        }),
        (i.prototype.multiplyTo = function (t, e) {
          var r = this.abs(),
            n = t.abs(),
            s = r.t;
          for (e.t = s + n.t; --s >= 0; ) e[s] = 0;
          for (s = 0; s < n.t; ++s) e[s + r.t] = r.am(0, n[s], e, s, 0, r.t);
          ((e.s = 0), e.clamp(), this.s != t.s && i.ZERO.subTo(e, e));
        }),
        (i.prototype.squareTo = function (t) {
          for (var e = this.abs(), r = (t.t = 2 * e.t); --r >= 0; ) t[r] = 0;
          for (r = 0; r < e.t - 1; ++r) {
            var n = e.am(r, e[r], t, 2 * r, 0, 1);
            (t[r + e.t] += e.am(r + 1, 2 * e[r], t, 2 * r + 1, n, e.t - r - 1)) >= e.DV &&
              ((t[r + e.t] -= e.DV), (t[r + e.t + 1] = 1));
          }
          (t.t > 0 && (t[t.t - 1] += e.am(r, e[r], t, 2 * r, 0, 1)), (t.s = 0), t.clamp());
        }),
        (i.prototype.divRemTo = function (t, e, r) {
          var n = t.abs();
          if (!(n.t <= 0)) {
            var s = this.abs();
            if (s.t < n.t) {
              (e != null && e.fromInt(0), r != null && this.copyTo(r));
              return;
            }
            r == null && (r = q());
            var a = q(),
              o = this.s,
              x = t.s,
              c = this.DB - Q0(n[n.t - 1]);
            c > 0 ? (n.lShiftTo(c, a), s.lShiftTo(c, r)) : (n.copyTo(a), s.copyTo(r));
            var f = a.t,
              g = a[f - 1];
            if (g != 0) {
              var h = g * (1 << this.F1) + (f > 1 ? a[f - 2] >> this.F2 : 0),
                l = this.FV / h,
                d = (1 << this.F1) / h,
                y = 1 << this.F2,
                p = r.t,
                A = p - f,
                u = e ?? q();
              for (
                a.dlShiftTo(A, u),
                  r.compareTo(u) >= 0 && ((r[r.t++] = 1), r.subTo(u, r)),
                  i.ONE.dlShiftTo(f, u),
                  u.subTo(a, a);
                a.t < f;
              )
                a[a.t++] = 0;
              for (; --A >= 0; ) {
                var v = r[--p] == g ? this.DM : Math.floor(r[p] * l + (r[p - 1] + y) * d);
                if ((r[p] += a.am(0, v, r, A, 0, f)) < v)
                  for (a.dlShiftTo(A, u), r.subTo(u, r); r[p] < --v; ) r.subTo(u, r);
              }
              (e != null && (r.drShiftTo(f, e), o != x && i.ZERO.subTo(e, e)),
                (r.t = f),
                r.clamp(),
                c > 0 && r.rShiftTo(c, r),
                o < 0 && i.ZERO.subTo(r, r));
            }
          }
        }),
        (i.prototype.invDigit = function () {
          if (this.t < 1) return 0;
          var t = this[0];
          if ((t & 1) == 0) return 0;
          var e = t & 3;
          return (
            (e = (e * (2 - (t & 15) * e)) & 15),
            (e = (e * (2 - (t & 255) * e)) & 255),
            (e = (e * (2 - (((t & 65535) * e) & 65535))) & 65535),
            (e = (e * (2 - ((t * e) % this.DV))) % this.DV),
            e > 0 ? this.DV - e : -e
          );
        }),
        (i.prototype.isEven = function () {
          return (this.t > 0 ? this[0] & 1 : this.s) == 0;
        }),
        (i.prototype.exp = function (t, e) {
          if (t > 4294967295 || t < 1) return i.ONE;
          var r = q(),
            n = q(),
            s = e.convert(this),
            a = Q0(t) - 1;
          for (s.copyTo(r); --a >= 0; )
            if ((e.sqrTo(r, n), (t & (1 << a)) > 0)) e.mulTo(n, s, r);
            else {
              var o = r;
              ((r = n), (n = o));
            }
          return e.revert(r);
        }),
        (i.prototype.chunkSize = function (t) {
          return Math.floor((Math.LN2 * this.DB) / Math.log(t));
        }),
        (i.prototype.toRadix = function (t) {
          if ((t == null && (t = 10), this.signum() == 0 || t < 2 || t > 36)) return "0";
          var e = this.chunkSize(t),
            r = Math.pow(t, e),
            n = v0(r),
            s = q(),
            a = q(),
            o = "";
          for (this.divRemTo(n, s, a); s.signum() > 0; )
            ((o = (r + a.intValue()).toString(t).substr(1) + o), s.divRemTo(n, s, a));
          return a.intValue().toString(t) + o;
        }),
        (i.prototype.fromRadix = function (t, e) {
          (this.fromInt(0), e == null && (e = 10));
          for (var r = this.chunkSize(e), n = Math.pow(e, r), s = !1, a = 0, o = 0, x = 0; x < t.length; ++x) {
            var c = Oe(t, x);
            if (c < 0) {
              t.charAt(x) == "-" && this.signum() == 0 && (s = !0);
              continue;
            }
            ((o = e * o + c), ++a >= r && (this.dMultiply(n), this.dAddOffset(o, 0), (a = 0), (o = 0)));
          }
          (a > 0 && (this.dMultiply(Math.pow(e, a)), this.dAddOffset(o, 0)), s && i.ZERO.subTo(this, this));
        }),
        (i.prototype.fromNumber = function (t, e, r) {
          if (typeof e == "number")
            if (t < 2) this.fromInt(1);
            else
              for (
                this.fromNumber(t, r),
                  this.testBit(t - 1) || this.bitwiseTo(i.ONE.shiftLeft(t - 1), Z0, this),
                  this.isEven() && this.dAddOffset(1, 0);
                !this.isProbablePrime(e);
              )
                (this.dAddOffset(2, 0), this.bitLength() > t && this.subTo(i.ONE.shiftLeft(t - 1), this));
          else {
            var n = [],
              s = t & 7;
            ((n.length = (t >> 3) + 1),
              e.nextBytes(n),
              s > 0 ? (n[0] &= (1 << s) - 1) : (n[0] = 0),
              this.fromString(n, 256));
          }
        }),
        (i.prototype.bitwiseTo = function (t, e, r) {
          var n,
            s,
            a = Math.min(t.t, this.t);
          for (n = 0; n < a; ++n) r[n] = e(this[n], t[n]);
          if (t.t < this.t) {
            for (s = t.s & this.DM, n = a; n < this.t; ++n) r[n] = e(this[n], s);
            r.t = this.t;
          } else {
            for (s = this.s & this.DM, n = a; n < t.t; ++n) r[n] = e(s, t[n]);
            r.t = t.t;
          }
          ((r.s = e(this.s, t.s)), r.clamp());
        }),
        (i.prototype.changeBit = function (t, e) {
          var r = i.ONE.shiftLeft(t);
          return (this.bitwiseTo(r, e, r), r);
        }),
        (i.prototype.addTo = function (t, e) {
          for (var r = 0, n = 0, s = Math.min(t.t, this.t); r < s; )
            ((n += this[r] + t[r]), (e[r++] = n & this.DM), (n >>= this.DB));
          if (t.t < this.t) {
            for (n += t.s; r < this.t; ) ((n += this[r]), (e[r++] = n & this.DM), (n >>= this.DB));
            n += this.s;
          } else {
            for (n += this.s; r < t.t; ) ((n += t[r]), (e[r++] = n & this.DM), (n >>= this.DB));
            n += t.s;
          }
          ((e.s = n < 0 ? -1 : 0), n > 0 ? (e[r++] = n) : n < -1 && (e[r++] = this.DV + n), (e.t = r), e.clamp());
        }),
        (i.prototype.dMultiply = function (t) {
          ((this[this.t] = this.am(0, t - 1, this, 0, 0, this.t)), ++this.t, this.clamp());
        }),
        (i.prototype.dAddOffset = function (t, e) {
          if (t != 0) {
            for (; this.t <= e; ) this[this.t++] = 0;
            for (this[e] += t; this[e] >= this.DV; )
              ((this[e] -= this.DV), ++e >= this.t && (this[this.t++] = 0), ++this[e]);
          }
        }),
        (i.prototype.multiplyLowerTo = function (t, e, r) {
          var n = Math.min(this.t + t.t, e);
          for (r.s = 0, r.t = n; n > 0; ) r[--n] = 0;
          for (var s = r.t - this.t; n < s; ++n) r[n + this.t] = this.am(0, t[n], r, n, 0, this.t);
          for (var s = Math.min(t.t, e); n < s; ++n) this.am(0, t[n], r, n, 0, e - n);
          r.clamp();
        }),
        (i.prototype.multiplyUpperTo = function (t, e, r) {
          --e;
          var n = (r.t = this.t + t.t - e);
          for (r.s = 0; --n >= 0; ) r[n] = 0;
          for (n = Math.max(e - this.t, 0); n < t.t; ++n) r[this.t + n - e] = this.am(e - n, t[n], r, 0, 0, this.t + n - e);
          (r.clamp(), r.drShiftTo(1, r));
        }),
        (i.prototype.modInt = function (t) {
          if (t <= 0) return 0;
          var e = this.DV % t,
            r = this.s < 0 ? t - 1 : 0;
          if (this.t > 0)
            if (e == 0) r = this[0] % t;
            else for (var n = this.t - 1; n >= 0; --n) r = (e * r + this[n]) % t;
          return r;
        }),
        (i.prototype.millerRabin = function (t) {
          var e = this.subtract(i.ONE),
            r = e.getLowestSetBit();
          if (r <= 0) return !1;
          var n = e.shiftRight(r);
          ((t = (t + 1) >> 1), t > J.length && (t = J.length));
          for (var s = q(), a = 0; a < t; ++a) {
            s.fromInt(J[Math.floor(Math.random() * J.length)]);
            var o = s.modPow(n, this);
            if (o.compareTo(i.ONE) != 0 && o.compareTo(e) != 0) {
              for (var x = 1; x++ < r && o.compareTo(e) != 0; )
                if (((o = o.modPowInt(2, this)), o.compareTo(i.ONE) == 0)) return !1;
              if (o.compareTo(e) != 0) return !1;
            }
          }
          return !0;
        }),
        (i.prototype.square = function () {
          var t = q();
          return (this.squareTo(t), t);
        }),
        (i.prototype.gcda = function (t, e) {
          var r = this.s < 0 ? this.negate() : this.clone(),
            n = t.s < 0 ? t.negate() : t.clone();
          if (r.compareTo(n) < 0) {
            var s = r;
            ((r = n), (n = s));
          }
          var a = r.getLowestSetBit(),
            o = n.getLowestSetBit();
          if (o < 0) {
            e(r);
            return;
          }
          (a < o && (o = a), o > 0 && (r.rShiftTo(o, r), n.rShiftTo(o, n)));
          var x = function () {
            ((a = r.getLowestSetBit()) > 0 && r.rShiftTo(a, r),
              (a = n.getLowestSetBit()) > 0 && n.rShiftTo(a, n),
              r.compareTo(n) >= 0 ? (r.subTo(n, r), r.rShiftTo(1, r)) : (n.subTo(r, n), n.rShiftTo(1, n)),
              r.signum() > 0
                ? setTimeout(x, 0)
                : (o > 0 && n.lShiftTo(o, n),
                  setTimeout(function () {
                    e(n);
                  }, 0)));
          };
          setTimeout(x, 10);
        }),
        (i.prototype.fromNumberAsync = function (t, e, r, n) {
          if (typeof e == "number")
            if (t < 2) this.fromInt(1);
            else {
              (this.fromNumber(t, r),
                this.testBit(t - 1) || this.bitwiseTo(i.ONE.shiftLeft(t - 1), Z0, this),
                this.isEven() && this.dAddOffset(1, 0));
              var s = this,
                a = function () {
                  (s.dAddOffset(2, 0),
                    s.bitLength() > t && s.subTo(i.ONE.shiftLeft(t - 1), s),
                    s.isProbablePrime(e)
                      ? setTimeout(function () {
                          n();
                        }, 0)
                      : setTimeout(a, 0));
                };
              setTimeout(a, 0);
            }
          else {
            var o = [],
              x = t & 7;
            ((o.length = (t >> 3) + 1),
              e.nextBytes(o),
              x > 0 ? (o[0] &= (1 << x) - 1) : (o[0] = 0),
              this.fromString(o, 256));
          }
        }),
        i
      );
    })(),
    Hi = (function () {
      function i() {}
      return (
        (i.prototype.convert = function (t) {
          return t;
        }),
        (i.prototype.revert = function (t) {
          return t;
        }),
        (i.prototype.mulTo = function (t, e, r) {
          t.multiplyTo(e, r);
        }),
        (i.prototype.sqrTo = function (t, e) {
          t.squareTo(e);
        }),
        i
      );
    })(),
    Re = (function () {
      function i(t) {
        this.m = t;
      }
      return (
        (i.prototype.convert = function (t) {
          return t.s < 0 || t.compareTo(this.m) >= 0 ? t.mod(this.m) : t;
        }),
        (i.prototype.revert = function (t) {
          return t;
        }),
        (i.prototype.reduce = function (t) {
          t.divRemTo(this.m, null, t);
        }),
        (i.prototype.mulTo = function (t, e, r) {
          (t.multiplyTo(e, r), this.reduce(r));
        }),
        (i.prototype.sqrTo = function (t, e) {
          (t.squareTo(e), this.reduce(e));
        }),
        i
      );
    })(),
    Ie = (function () {
      function i(t) {
        ((this.m = t),
          (this.mp = t.invDigit()),
          (this.mpl = this.mp & 32767),
          (this.mph = this.mp >> 15),
          (this.um = (1 << (t.DB - 15)) - 1),
          (this.mt2 = 2 * t.t));
      }
      return (
        (i.prototype.convert = function (t) {
          var e = q();
          return (
            t.abs().dlShiftTo(this.m.t, e),
            e.divRemTo(this.m, null, e),
            t.s < 0 && e.compareTo(L.ZERO) > 0 && this.m.subTo(e, e),
            e
          );
        }),
        (i.prototype.revert = function (t) {
          var e = q();
          return (t.copyTo(e), this.reduce(e), e);
        }),
        (i.prototype.reduce = function (t) {
          for (; t.t <= this.mt2; ) t[t.t++] = 0;
          for (var e = 0; e < this.m.t; ++e) {
            var r = t[e] & 32767,
              n = (r * this.mpl + (((r * this.mph + (t[e] >> 15) * this.mpl) & this.um) << 15)) & t.DM;
            for (r = e + this.m.t, t[r] += this.m.am(0, n, t, e, 0, this.m.t); t[r] >= t.DV; ) ((t[r] -= t.DV), t[++r]++);
          }
          (t.clamp(), t.drShiftTo(this.m.t, t), t.compareTo(this.m) >= 0 && t.subTo(this.m, t));
        }),
        (i.prototype.mulTo = function (t, e, r) {
          (t.multiplyTo(e, r), this.reduce(r));
        }),
        (i.prototype.sqrTo = function (t, e) {
          (t.squareTo(e), this.reduce(e));
        }),
        i
      );
    })(),
    Ui = (function () {
      function i(t) {
        ((this.m = t), (this.r2 = q()), (this.q3 = q()), L.ONE.dlShiftTo(2 * t.t, this.r2), (this.mu = this.r2.divide(t)));
      }
      return (
        (i.prototype.convert = function (t) {
          if (t.s < 0 || t.t > 2 * this.m.t) return t.mod(this.m);
          if (t.compareTo(this.m) < 0) return t;
          var e = q();
          return (t.copyTo(e), this.reduce(e), e);
        }),
        (i.prototype.revert = function (t) {
          return t;
        }),
        (i.prototype.reduce = function (t) {
          for (
            t.drShiftTo(this.m.t - 1, this.r2),
              t.t > this.m.t + 1 && ((t.t = this.m.t + 1), t.clamp()),
              this.mu.multiplyUpperTo(this.r2, this.m.t + 1, this.q3),
              this.m.multiplyLowerTo(this.q3, this.m.t + 1, this.r2);
            t.compareTo(this.r2) < 0;
          )
            t.dAddOffset(1, this.m.t + 1);
          for (t.subTo(this.r2, t); t.compareTo(this.m) >= 0; ) t.subTo(this.m, t);
        }),
        (i.prototype.mulTo = function (t, e, r) {
          (t.multiplyTo(e, r), this.reduce(r));
        }),
        (i.prototype.sqrTo = function (t, e) {
          (t.squareTo(e), this.reduce(e));
        }),
        i
      );
    })();
  function q() {
    return new L(null);
  }
  function X(i, t) {
    return new L(i, t);
  }
  var Pe = typeof navigator < "u";
  (Pe && ke && navigator.appName == "Microsoft Internet Explorer"
    ? ((L.prototype.am = function (t, e, r, n, s, a) {
        for (var o = e & 32767, x = e >> 15; --a >= 0; ) {
          var c = this[t] & 32767,
            f = this[t++] >> 15,
            g = x * c + f * o;
          ((c = o * c + ((g & 32767) << 15) + r[n] + (s & 1073741823)),
            (s = (c >>> 30) + (g >>> 15) + x * f + (s >>> 30)),
            (r[n++] = c & 1073741823));
        }
        return s;
      }),
      (d0 = 30))
    : Pe && ke && navigator.appName != "Netscape"
      ? ((L.prototype.am = function (t, e, r, n, s, a) {
          for (; --a >= 0; ) {
            var o = e * this[t++] + r[n] + s;
            ((s = Math.floor(o / 67108864)), (r[n++] = o & 67108863));
          }
          return s;
        }),
        (d0 = 26))
      : ((L.prototype.am = function (t, e, r, n, s, a) {
          for (var o = e & 16383, x = e >> 14; --a >= 0; ) {
            var c = this[t] & 16383,
              f = this[t++] >> 14,
              g = x * c + f * o;
            ((c = o * c + ((g & 16383) << 14) + r[n] + s), (s = (c >> 28) + (g >> 14) + x * f), (r[n++] = c & 268435455));
          }
          return s;
        }),
        (d0 = 28)),
    (L.prototype.DB = d0),
    (L.prototype.DM = (1 << d0) - 1),
    (L.prototype.DV = 1 << d0));
  var te = 52;
  ((L.prototype.FV = Math.pow(2, te)), (L.prototype.F1 = te - d0), (L.prototype.F2 = 2 * d0 - te));
  var Y0 = [],
    S0,
    s0;
  for (S0 = 48, s0 = 0; s0 <= 9; ++s0) Y0[S0++] = s0;
  for (S0 = 97, s0 = 10; s0 < 36; ++s0) Y0[S0++] = s0;
  for (S0 = 65, s0 = 10; s0 < 36; ++s0) Y0[S0++] = s0;
  function Oe(i, t) {
    var e = Y0[i.charCodeAt(t)];
    return e ?? -1;
  }
  function v0(i) {
    var t = q();
    return (t.fromInt(i), t);
  }
  function Q0(i) {
    var t = 1,
      e;
    return (
      (e = i >>> 16) != 0 && ((i = e), (t += 16)),
      (e = i >> 8) != 0 && ((i = e), (t += 8)),
      (e = i >> 4) != 0 && ((i = e), (t += 4)),
      (e = i >> 2) != 0 && ((i = e), (t += 2)),
      (e = i >> 1) != 0 && ((i = e), (t += 1)),
      t
    );
  }
  ((L.ZERO = v0(0)), (L.ONE = v0(1)));
  var Li = (function () {
    function i() {
      ((this.i = 0), (this.j = 0), (this.S = []));
    }
    return (
      (i.prototype.init = function (t) {
        var e, r, n;
        for (e = 0; e < 256; ++e) this.S[e] = e;
        for (r = 0, e = 0; e < 256; ++e)
          ((r = (r + this.S[e] + t[e % t.length]) & 255), (n = this.S[e]), (this.S[e] = this.S[r]), (this.S[r] = n));
        ((this.i = 0), (this.j = 0));
      }),
      (i.prototype.next = function () {
        var t;
        return (
          (this.i = (this.i + 1) & 255),
          (this.j = (this.j + this.S[this.i]) & 255),
          (t = this.S[this.i]),
          (this.S[this.i] = this.S[this.j]),
          (this.S[this.j] = t),
          this.S[(t + this.S[this.i]) & 255]
        );
      }),
      i
    );
  })();
  function Ni() {
    return new Li();
  }
  var He = 256,
    J0,
    p0 = null,
    a0;
  if (p0 == null) {
    ((p0 = []), (a0 = 0));
    var tt = void 0;
    if (typeof window < "u" && window.crypto && window.crypto.getRandomValues) {
      var ee = new Uint32Array(256);
      for (window.crypto.getRandomValues(ee), tt = 0; tt < ee.length; ++tt) p0[a0++] = ee[tt] & 255;
    }
    var et = 0,
      rt = function (i) {
        if (((et = et || 0), et >= 256 || a0 >= He)) {
          window.removeEventListener
            ? window.removeEventListener("mousemove", rt, !1)
            : window.detachEvent && window.detachEvent("onmousemove", rt);
          return;
        }
        try {
          var t = i.x + i.y;
          ((p0[a0++] = t & 255), (et += 1));
        } catch {}
      };
    typeof window < "u" &&
      (window.addEventListener
        ? window.addEventListener("mousemove", rt, !1)
        : window.attachEvent && window.attachEvent("onmousemove", rt));
  }
  function Ki() {
    if (J0 == null) {
      for (J0 = Ni(); a0 < He; ) {
        var i = Math.floor(65536 * Math.random());
        p0[a0++] = i & 255;
      }
      for (J0.init(p0), a0 = 0; a0 < p0.length; ++a0) p0[a0] = 0;
      a0 = 0;
    }
    return J0.next();
  }
  var re = (function () {
    function i() {}
    return (
      (i.prototype.nextBytes = function (t) {
        for (var e = 0; e < t.length; ++e) t[e] = Ki();
      }),
      i
    );
  })();
  function qi(i, t) {
    if (t < i.length + 22) return (console.error("Message too long for RSA"), null);
    for (var e = t - i.length - 6, r = "", n = 0; n < e; n += 2) r += "ff";
    var s = "0001" + r + "00" + i;
    return X(s, 16);
  }
  function zi(i, t) {
    if (t < i.length + 11) return (console.error("Message too long for RSA"), null);
    for (var e = [], r = i.length - 1; r >= 0 && t > 0; ) {
      var n = i.charCodeAt(r--);
      n < 128
        ? (e[--t] = n)
        : n > 127 && n < 2048
          ? ((e[--t] = (n & 63) | 128), (e[--t] = (n >> 6) | 192))
          : ((e[--t] = (n & 63) | 128), (e[--t] = ((n >> 6) & 63) | 128), (e[--t] = (n >> 12) | 224));
    }
    e[--t] = 0;
    for (var s = new re(), a = []; t > 2; ) {
      for (a[0] = 0; a[0] == 0; ) s.nextBytes(a);
      e[--t] = a[0];
    }
    return ((e[--t] = 2), (e[--t] = 0), new L(e));
  }
  var Vi = (function () {
    function i() {
      ((this.n = null),
        (this.e = 0),
        (this.d = null),
        (this.p = null),
        (this.q = null),
        (this.dmp1 = null),
        (this.dmq1 = null),
        (this.coeff = null));
    }
    return (
      (i.prototype.doPublic = function (t) {
        return t.modPowInt(this.e, this.n);
      }),
      (i.prototype.doPrivate = function (t) {
        if (this.p == null || this.q == null) return t.modPow(this.d, this.n);
        for (
          var e = t.mod(this.p).modPow(this.dmp1, this.p), r = t.mod(this.q).modPow(this.dmq1, this.q);
          e.compareTo(r) < 0;
        )
          e = e.add(this.p);
        return e.subtract(r).multiply(this.coeff).mod(this.p).multiply(this.q).add(r);
      }),
      (i.prototype.setPublic = function (t, e) {
        t != null && e != null && t.length > 0 && e.length > 0
          ? ((this.n = X(t, 16)), (this.e = parseInt(e, 16)))
          : console.error("Invalid RSA public key");
      }),
      (i.prototype.encrypt = function (t) {
        var e = (this.n.bitLength() + 7) >> 3,
          r = zi(t, e);
        if (r == null) return null;
        var n = this.doPublic(r);
        if (n == null) return null;
        for (var s = n.toString(16), a = s.length, o = 0; o < e * 2 - a; o++) s = "0" + s;
        return s;
      }),
      (i.prototype.setPrivate = function (t, e, r) {
        t != null && e != null && t.length > 0 && e.length > 0
          ? ((this.n = X(t, 16)), (this.e = parseInt(e, 16)), (this.d = X(r, 16)))
          : console.error("Invalid RSA private key");
      }),
      (i.prototype.setPrivateEx = function (t, e, r, n, s, a, o, x) {
        t != null && e != null && t.length > 0 && e.length > 0
          ? ((this.n = X(t, 16)),
            (this.e = parseInt(e, 16)),
            (this.d = X(r, 16)),
            (this.p = X(n, 16)),
            (this.q = X(s, 16)),
            (this.dmp1 = X(a, 16)),
            (this.dmq1 = X(o, 16)),
            (this.coeff = X(x, 16)))
          : console.error("Invalid RSA private key");
      }),
      (i.prototype.generate = function (t, e) {
        var r = new re(),
          n = t >> 1;
        this.e = parseInt(e, 16);
        for (var s = new L(e, 16); ; ) {
          for (
            ;
            (this.p = new L(t - n, 1, r)),
              !(this.p.subtract(L.ONE).gcd(s).compareTo(L.ONE) == 0 && this.p.isProbablePrime(10));
          );
          for (
            ;
            (this.q = new L(n, 1, r)), !(this.q.subtract(L.ONE).gcd(s).compareTo(L.ONE) == 0 && this.q.isProbablePrime(10));
          );
          if (this.p.compareTo(this.q) <= 0) {
            var a = this.p;
            ((this.p = this.q), (this.q = a));
          }
          var o = this.p.subtract(L.ONE),
            x = this.q.subtract(L.ONE),
            c = o.multiply(x);
          if (c.gcd(s).compareTo(L.ONE) == 0) {
            ((this.n = this.p.multiply(this.q)),
              (this.d = s.modInverse(c)),
              (this.dmp1 = this.d.mod(o)),
              (this.dmq1 = this.d.mod(x)),
              (this.coeff = this.q.modInverse(this.p)));
            break;
          }
        }
      }),
      (i.prototype.decrypt = function (t) {
        var e = X(t, 16),
          r = this.doPrivate(e);
        return r == null ? null : Mi(r, (this.n.bitLength() + 7) >> 3);
      }),
      (i.prototype.generateAsync = function (t, e, r) {
        var n = new re(),
          s = t >> 1;
        this.e = parseInt(e, 16);
        var a = new L(e, 16),
          o = this,
          x = function () {
            var c = function () {
                if (o.p.compareTo(o.q) <= 0) {
                  var h = o.p;
                  ((o.p = o.q), (o.q = h));
                }
                var l = o.p.subtract(L.ONE),
                  d = o.q.subtract(L.ONE),
                  y = l.multiply(d);
                y.gcd(a).compareTo(L.ONE) == 0
                  ? ((o.n = o.p.multiply(o.q)),
                    (o.d = a.modInverse(y)),
                    (o.dmp1 = o.d.mod(l)),
                    (o.dmq1 = o.d.mod(d)),
                    (o.coeff = o.q.modInverse(o.p)),
                    setTimeout(function () {
                      r();
                    }, 0))
                  : setTimeout(x, 0);
              },
              f = function () {
                ((o.q = q()),
                  o.q.fromNumberAsync(s, 1, n, function () {
                    o.q.subtract(L.ONE).gcda(a, function (h) {
                      h.compareTo(L.ONE) == 0 && o.q.isProbablePrime(10) ? setTimeout(c, 0) : setTimeout(f, 0);
                    });
                  }));
              },
              g = function () {
                ((o.p = q()),
                  o.p.fromNumberAsync(t - s, 1, n, function () {
                    o.p.subtract(L.ONE).gcda(a, function (h) {
                      h.compareTo(L.ONE) == 0 && o.p.isProbablePrime(10) ? setTimeout(f, 0) : setTimeout(g, 0);
                    });
                  }));
              };
            setTimeout(g, 0);
          };
        setTimeout(x, 0);
      }),
      (i.prototype.sign = function (t, e, r) {
        var n = $i(r),
          s = n + e(t).toString(),
          a = qi(s, this.n.bitLength() / 4);
        if (a == null) return null;
        var o = this.doPrivate(a);
        if (o == null) return null;
        var x = o.toString(16);
        return (x.length & 1) == 0 ? x : "0" + x;
      }),
      (i.prototype.verify = function (t, e, r) {
        var n = X(e, 16),
          s = this.doPublic(n);
        if (s == null) return null;
        var a = s.toString(16).replace(/^1f+00/, ""),
          o = ji(a);
        return o == r(t).toString();
      }),
      i
    );
  })();
  function Mi(i, t) {
    for (var e = i.toByteArray(), r = 0; r < e.length && e[r] == 0; ) ++r;
    if (e.length - r != t - 1 || e[r] != 2) return null;
    for (++r; e[r] != 0; ) if (++r >= e.length) return null;
    for (var n = ""; ++r < e.length; ) {
      var s = e[r] & 255;
      s < 128
        ? (n += String.fromCharCode(s))
        : s > 191 && s < 224
          ? ((n += String.fromCharCode(((s & 31) << 6) | (e[r + 1] & 63))), ++r)
          : ((n += String.fromCharCode(((s & 15) << 12) | ((e[r + 1] & 63) << 6) | (e[r + 2] & 63))), (r += 2));
    }
    return n;
  }
  var it = {
    md2: "3020300c06082a864886f70d020205000410",
    md5: "3020300c06082a864886f70d020505000410",
    sha1: "3021300906052b0e03021a05000414",
    sha224: "302d300d06096086480165030402040500041c",
    sha256: "3031300d060960864801650304020105000420",
    sha384: "3041300d060960864801650304020205000430",
    sha512: "3051300d060960864801650304020305000440",
    ripemd160: "3021300906052b2403020105000414",
  };
  function $i(i) {
    return it[i] || "";
  }
  function ji(i) {
    for (var t in it)
      if (it.hasOwnProperty(t)) {
        var e = it[t],
          r = e.length;
        if (i.substr(0, r) == e) return i.substr(r);
      }
    return i;
  }
  /*!
Copyright (c) 2011, Yahoo! Inc. All rights reserved.
Code licensed under the BSD License:
http://developer.yahoo.com/yui/license.html
version: 2.9.0
*/ var Y = {};
  Y.lang = {
    extend: function (i, t, e) {
      if (!t || !i) throw new Error("YAHOO.lang.extend failed, please check that all dependencies are included.");
      var r = function () {};
      if (
        ((r.prototype = t.prototype),
        (i.prototype = new r()),
        (i.prototype.constructor = i),
        (i.superclass = t.prototype),
        t.prototype.constructor == Object.prototype.constructor && (t.prototype.constructor = t),
        e)
      ) {
        var n;
        for (n in e) i.prototype[n] = e[n];
        var s = function () {},
          a = ["toString", "valueOf"];
        try {
          /MSIE/.test(navigator.userAgent) &&
            (s = function (o, x) {
              for (n = 0; n < a.length; n = n + 1) {
                var c = a[n],
                  f = x[c];
                typeof f == "function" && f != Object.prototype[c] && (o[c] = f);
              }
            });
        } catch {}
        s(i.prototype, e);
      }
    },
  };
  /**
   * @fileOverview
   * @name asn1-1.0.js
   * @author Kenji Urushima kenji.urushima@gmail.com
   * @version asn1 1.0.13 (2017-Jun-02)
   * @since jsrsasign 2.1
   * @license <a href="https://kjur.github.io/jsrsasign/license/">MIT License</a>
   */ var _ = {};
  ((typeof _.asn1 > "u" || !_.asn1) && (_.asn1 = {}),
    (_.asn1.ASN1Util = new (function () {
      ((this.integerToByteHex = function (i) {
        var t = i.toString(16);
        return (t.length % 2 == 1 && (t = "0" + t), t);
      }),
        (this.bigIntToMinTwosComplementsHex = function (i) {
          var t = i.toString(16);
          if (t.substr(0, 1) != "-") t.length % 2 == 1 ? (t = "0" + t) : t.match(/^[0-7]/) || (t = "00" + t);
          else {
            var e = t.substr(1),
              r = e.length;
            r % 2 == 1 ? (r += 1) : t.match(/^[0-7]/) || (r += 2);
            for (var n = "", s = 0; s < r; s++) n += "f";
            var a = new L(n, 16),
              o = a.xor(i).add(L.ONE);
            t = o.toString(16).replace(/^-/, "");
          }
          return t;
        }),
        (this.getPEMStringFromHex = function (i, t) {
          return hextopem(i, t);
        }),
        (this.newObject = function (i) {
          var t = _,
            e = t.asn1,
            r = e.DERBoolean,
            n = e.DERInteger,
            s = e.DERBitString,
            a = e.DEROctetString,
            o = e.DERNull,
            x = e.DERObjectIdentifier,
            c = e.DEREnumerated,
            f = e.DERUTF8String,
            g = e.DERNumericString,
            h = e.DERPrintableString,
            l = e.DERTeletexString,
            d = e.DERIA5String,
            y = e.DERUTCTime,
            p = e.DERGeneralizedTime,
            A = e.DERSequence,
            u = e.DERSet,
            v = e.DERTaggedObject,
            E = e.ASN1Util.newObject,
            m = Object.keys(i);
          if (m.length != 1) throw "key of param shall be only one.";
          var B = m[0];
          if (
            ":bool:int:bitstr:octstr:null:oid:enum:utf8str:numstr:prnstr:telstr:ia5str:utctime:gentime:seq:set:tag:".indexOf(
              ":" + B + ":",
            ) == -1
          )
            throw "undefined key: " + B;
          if (B == "bool") return new r(i[B]);
          if (B == "int") return new n(i[B]);
          if (B == "bitstr") return new s(i[B]);
          if (B == "octstr") return new a(i[B]);
          if (B == "null") return new o(i[B]);
          if (B == "oid") return new x(i[B]);
          if (B == "enum") return new c(i[B]);
          if (B == "utf8str") return new f(i[B]);
          if (B == "numstr") return new g(i[B]);
          if (B == "prnstr") return new h(i[B]);
          if (B == "telstr") return new l(i[B]);
          if (B == "ia5str") return new d(i[B]);
          if (B == "utctime") return new y(i[B]);
          if (B == "gentime") return new p(i[B]);
          if (B == "seq") {
            for (var w = i[B], b = [], I = 0; I < w.length; I++) {
              var D = E(w[I]);
              b.push(D);
            }
            return new A({array: b});
          }
          if (B == "set") {
            for (var w = i[B], b = [], I = 0; I < w.length; I++) {
              var D = E(w[I]);
              b.push(D);
            }
            return new u({array: b});
          }
          if (B == "tag") {
            var C = i[B];
            if (Object.prototype.toString.call(C) === "[object Array]" && C.length == 3) {
              var T = E(C[2]);
              return new v({tag: C[0], explicit: C[1], obj: T});
            } else {
              var S = {};
              if (
                (C.explicit !== void 0 && (S.explicit = C.explicit), C.tag !== void 0 && (S.tag = C.tag), C.obj === void 0)
              )
                throw "obj shall be specified for 'tag'.";
              return ((S.obj = E(C.obj)), new v(S));
            }
          }
        }),
        (this.jsonToASN1HEX = function (i) {
          var t = this.newObject(i);
          return t.getEncodedHex();
        }));
    })()),
    (_.asn1.ASN1Util.oidHexToInt = function (i) {
      for (
        var n = "", t = parseInt(i.substr(0, 2), 16), e = Math.floor(t / 40), r = t % 40, n = e + "." + r, s = "", a = 2;
        a < i.length;
        a += 2
      ) {
        var o = parseInt(i.substr(a, 2), 16),
          x = ("00000000" + o.toString(2)).slice(-8);
        if (((s = s + x.substr(1, 7)), x.substr(0, 1) == "0")) {
          var c = new L(s, 2);
          ((n = n + "." + c.toString(10)), (s = ""));
        }
      }
      return n;
    }),
    (_.asn1.ASN1Util.oidIntToHex = function (i) {
      var t = function (o) {
          var x = o.toString(16);
          return (x.length == 1 && (x = "0" + x), x);
        },
        e = function (o) {
          var x = "",
            c = new L(o, 10),
            f = c.toString(2),
            g = 7 - (f.length % 7);
          g == 7 && (g = 0);
          for (var h = "", l = 0; l < g; l++) h += "0";
          f = h + f;
          for (var l = 0; l < f.length - 1; l += 7) {
            var d = f.substr(l, 7);
            (l != f.length - 7 && (d = "1" + d), (x += t(parseInt(d, 2))));
          }
          return x;
        };
      if (!i.match(/^[0-9.]+$/)) throw "malformed oid string: " + i;
      var r = "",
        n = i.split("."),
        s = parseInt(n[0]) * 40 + parseInt(n[1]);
      ((r += t(s)), n.splice(0, 2));
      for (var a = 0; a < n.length; a++) r += e(n[a]);
      return r;
    }),
    (_.asn1.ASN1Object = function () {
      var i = "";
      ((this.getLengthHexFromValue = function () {
        if (typeof this.hV > "u" || this.hV == null) throw "this.hV is null or undefined.";
        if (this.hV.length % 2 == 1) throw "value hex must be even length: n=" + i.length + ",v=" + this.hV;
        var t = this.hV.length / 2,
          e = t.toString(16);
        if ((e.length % 2 == 1 && (e = "0" + e), t < 128)) return e;
        var r = e.length / 2;
        if (r > 15) throw "ASN.1 length too long to represent by 8x: n = " + t.toString(16);
        var n = 128 + r;
        return n.toString(16) + e;
      }),
        (this.getEncodedHex = function () {
          return (
            (this.hTLV == null || this.isModified) &&
              ((this.hV = this.getFreshValueHex()),
              (this.hL = this.getLengthHexFromValue()),
              (this.hTLV = this.hT + this.hL + this.hV),
              (this.isModified = !1)),
            this.hTLV
          );
        }),
        (this.getValueHex = function () {
          return (this.getEncodedHex(), this.hV);
        }),
        (this.getFreshValueHex = function () {
          return "";
        }));
    }),
    (_.asn1.DERAbstractString = function (i) {
      (_.asn1.DERAbstractString.superclass.constructor.call(this),
        (this.getString = function () {
          return this.s;
        }),
        (this.setString = function (t) {
          ((this.hTLV = null), (this.isModified = !0), (this.s = t), (this.hV = stohex(this.s)));
        }),
        (this.setStringHex = function (t) {
          ((this.hTLV = null), (this.isModified = !0), (this.s = null), (this.hV = t));
        }),
        (this.getFreshValueHex = function () {
          return this.hV;
        }),
        typeof i < "u" &&
          (typeof i == "string"
            ? this.setString(i)
            : typeof i.str < "u"
              ? this.setString(i.str)
              : typeof i.hex < "u" && this.setStringHex(i.hex)));
    }),
    Y.lang.extend(_.asn1.DERAbstractString, _.asn1.ASN1Object),
    (_.asn1.DERAbstractTime = function (i) {
      (_.asn1.DERAbstractTime.superclass.constructor.call(this),
        (this.localDateToUTC = function (t) {
          utc = t.getTime() + t.getTimezoneOffset() * 6e4;
          var e = new Date(utc);
          return e;
        }),
        (this.formatDate = function (t, e, r) {
          var n = this.zeroPadding,
            s = this.localDateToUTC(t),
            a = String(s.getFullYear());
          e == "utc" && (a = a.substr(2, 2));
          var o = n(String(s.getMonth() + 1), 2),
            x = n(String(s.getDate()), 2),
            c = n(String(s.getHours()), 2),
            f = n(String(s.getMinutes()), 2),
            g = n(String(s.getSeconds()), 2),
            h = a + o + x + c + f + g;
          if (r === !0) {
            var l = s.getMilliseconds();
            if (l != 0) {
              var d = n(String(l), 3);
              ((d = d.replace(/[0]+$/, "")), (h = h + "." + d));
            }
          }
          return h + "Z";
        }),
        (this.zeroPadding = function (t, e) {
          return t.length >= e ? t : new Array(e - t.length + 1).join("0") + t;
        }),
        (this.getString = function () {
          return this.s;
        }),
        (this.setString = function (t) {
          ((this.hTLV = null), (this.isModified = !0), (this.s = t), (this.hV = stohex(t)));
        }),
        (this.setByDateValue = function (t, e, r, n, s, a) {
          var o = new Date(Date.UTC(t, e - 1, r, n, s, a, 0));
          this.setByDate(o);
        }),
        (this.getFreshValueHex = function () {
          return this.hV;
        }));
    }),
    Y.lang.extend(_.asn1.DERAbstractTime, _.asn1.ASN1Object),
    (_.asn1.DERAbstractStructured = function (i) {
      (_.asn1.DERAbstractString.superclass.constructor.call(this),
        (this.setByASN1ObjectArray = function (t) {
          ((this.hTLV = null), (this.isModified = !0), (this.asn1Array = t));
        }),
        (this.appendASN1Object = function (t) {
          ((this.hTLV = null), (this.isModified = !0), this.asn1Array.push(t));
        }),
        (this.asn1Array = new Array()),
        typeof i < "u" && typeof i.array < "u" && (this.asn1Array = i.array));
    }),
    Y.lang.extend(_.asn1.DERAbstractStructured, _.asn1.ASN1Object),
    (_.asn1.DERBoolean = function () {
      (_.asn1.DERBoolean.superclass.constructor.call(this), (this.hT = "01"), (this.hTLV = "0101ff"));
    }),
    Y.lang.extend(_.asn1.DERBoolean, _.asn1.ASN1Object),
    (_.asn1.DERInteger = function (i) {
      (_.asn1.DERInteger.superclass.constructor.call(this),
        (this.hT = "02"),
        (this.setByBigInteger = function (t) {
          ((this.hTLV = null), (this.isModified = !0), (this.hV = _.asn1.ASN1Util.bigIntToMinTwosComplementsHex(t)));
        }),
        (this.setByInteger = function (t) {
          var e = new L(String(t), 10);
          this.setByBigInteger(e);
        }),
        (this.setValueHex = function (t) {
          this.hV = t;
        }),
        (this.getFreshValueHex = function () {
          return this.hV;
        }),
        typeof i < "u" &&
          (typeof i.bigint < "u"
            ? this.setByBigInteger(i.bigint)
            : typeof i.int < "u"
              ? this.setByInteger(i.int)
              : typeof i == "number"
                ? this.setByInteger(i)
                : typeof i.hex < "u" && this.setValueHex(i.hex)));
    }),
    Y.lang.extend(_.asn1.DERInteger, _.asn1.ASN1Object),
    (_.asn1.DERBitString = function (i) {
      if (i !== void 0 && typeof i.obj < "u") {
        var t = _.asn1.ASN1Util.newObject(i.obj);
        i.hex = "00" + t.getEncodedHex();
      }
      (_.asn1.DERBitString.superclass.constructor.call(this),
        (this.hT = "03"),
        (this.setHexValueIncludingUnusedBits = function (e) {
          ((this.hTLV = null), (this.isModified = !0), (this.hV = e));
        }),
        (this.setUnusedBitsAndHexValue = function (e, r) {
          if (e < 0 || 7 < e) throw "unused bits shall be from 0 to 7: u = " + e;
          var n = "0" + e;
          ((this.hTLV = null), (this.isModified = !0), (this.hV = n + r));
        }),
        (this.setByBinaryString = function (e) {
          e = e.replace(/0+$/, "");
          var r = 8 - (e.length % 8);
          r == 8 && (r = 0);
          for (var n = 0; n <= r; n++) e += "0";
          for (var s = "", n = 0; n < e.length - 1; n += 8) {
            var a = e.substr(n, 8),
              o = parseInt(a, 2).toString(16);
            (o.length == 1 && (o = "0" + o), (s += o));
          }
          ((this.hTLV = null), (this.isModified = !0), (this.hV = "0" + r + s));
        }),
        (this.setByBooleanArray = function (e) {
          for (var r = "", n = 0; n < e.length; n++) e[n] == !0 ? (r += "1") : (r += "0");
          this.setByBinaryString(r);
        }),
        (this.newFalseArray = function (e) {
          for (var r = new Array(e), n = 0; n < e; n++) r[n] = !1;
          return r;
        }),
        (this.getFreshValueHex = function () {
          return this.hV;
        }),
        typeof i < "u" &&
          (typeof i == "string" && i.toLowerCase().match(/^[0-9a-f]+$/)
            ? this.setHexValueIncludingUnusedBits(i)
            : typeof i.hex < "u"
              ? this.setHexValueIncludingUnusedBits(i.hex)
              : typeof i.bin < "u"
                ? this.setByBinaryString(i.bin)
                : typeof i.array < "u" && this.setByBooleanArray(i.array)));
    }),
    Y.lang.extend(_.asn1.DERBitString, _.asn1.ASN1Object),
    (_.asn1.DEROctetString = function (i) {
      if (i !== void 0 && typeof i.obj < "u") {
        var t = _.asn1.ASN1Util.newObject(i.obj);
        i.hex = t.getEncodedHex();
      }
      (_.asn1.DEROctetString.superclass.constructor.call(this, i), (this.hT = "04"));
    }),
    Y.lang.extend(_.asn1.DEROctetString, _.asn1.DERAbstractString),
    (_.asn1.DERNull = function () {
      (_.asn1.DERNull.superclass.constructor.call(this), (this.hT = "05"), (this.hTLV = "0500"));
    }),
    Y.lang.extend(_.asn1.DERNull, _.asn1.ASN1Object),
    (_.asn1.DERObjectIdentifier = function (i) {
      var t = function (r) {
          var n = r.toString(16);
          return (n.length == 1 && (n = "0" + n), n);
        },
        e = function (r) {
          var n = "",
            s = new L(r, 10),
            a = s.toString(2),
            o = 7 - (a.length % 7);
          o == 7 && (o = 0);
          for (var x = "", c = 0; c < o; c++) x += "0";
          a = x + a;
          for (var c = 0; c < a.length - 1; c += 7) {
            var f = a.substr(c, 7);
            (c != a.length - 7 && (f = "1" + f), (n += t(parseInt(f, 2))));
          }
          return n;
        };
      (_.asn1.DERObjectIdentifier.superclass.constructor.call(this),
        (this.hT = "06"),
        (this.setValueHex = function (r) {
          ((this.hTLV = null), (this.isModified = !0), (this.s = null), (this.hV = r));
        }),
        (this.setValueOidString = function (r) {
          if (!r.match(/^[0-9.]+$/)) throw "malformed oid string: " + r;
          var n = "",
            s = r.split("."),
            a = parseInt(s[0]) * 40 + parseInt(s[1]);
          ((n += t(a)), s.splice(0, 2));
          for (var o = 0; o < s.length; o++) n += e(s[o]);
          ((this.hTLV = null), (this.isModified = !0), (this.s = null), (this.hV = n));
        }),
        (this.setValueName = function (r) {
          var n = _.asn1.x509.OID.name2oid(r);
          if (n !== "") this.setValueOidString(n);
          else throw "DERObjectIdentifier oidName undefined: " + r;
        }),
        (this.getFreshValueHex = function () {
          return this.hV;
        }),
        i !== void 0 &&
          (typeof i == "string"
            ? i.match(/^[0-2].[0-9.]+$/)
              ? this.setValueOidString(i)
              : this.setValueName(i)
            : i.oid !== void 0
              ? this.setValueOidString(i.oid)
              : i.hex !== void 0
                ? this.setValueHex(i.hex)
                : i.name !== void 0 && this.setValueName(i.name)));
    }),
    Y.lang.extend(_.asn1.DERObjectIdentifier, _.asn1.ASN1Object),
    (_.asn1.DEREnumerated = function (i) {
      (_.asn1.DEREnumerated.superclass.constructor.call(this),
        (this.hT = "0a"),
        (this.setByBigInteger = function (t) {
          ((this.hTLV = null), (this.isModified = !0), (this.hV = _.asn1.ASN1Util.bigIntToMinTwosComplementsHex(t)));
        }),
        (this.setByInteger = function (t) {
          var e = new L(String(t), 10);
          this.setByBigInteger(e);
        }),
        (this.setValueHex = function (t) {
          this.hV = t;
        }),
        (this.getFreshValueHex = function () {
          return this.hV;
        }),
        typeof i < "u" &&
          (typeof i.int < "u"
            ? this.setByInteger(i.int)
            : typeof i == "number"
              ? this.setByInteger(i)
              : typeof i.hex < "u" && this.setValueHex(i.hex)));
    }),
    Y.lang.extend(_.asn1.DEREnumerated, _.asn1.ASN1Object),
    (_.asn1.DERUTF8String = function (i) {
      (_.asn1.DERUTF8String.superclass.constructor.call(this, i), (this.hT = "0c"));
    }),
    Y.lang.extend(_.asn1.DERUTF8String, _.asn1.DERAbstractString),
    (_.asn1.DERNumericString = function (i) {
      (_.asn1.DERNumericString.superclass.constructor.call(this, i), (this.hT = "12"));
    }),
    Y.lang.extend(_.asn1.DERNumericString, _.asn1.DERAbstractString),
    (_.asn1.DERPrintableString = function (i) {
      (_.asn1.DERPrintableString.superclass.constructor.call(this, i), (this.hT = "13"));
    }),
    Y.lang.extend(_.asn1.DERPrintableString, _.asn1.DERAbstractString),
    (_.asn1.DERTeletexString = function (i) {
      (_.asn1.DERTeletexString.superclass.constructor.call(this, i), (this.hT = "14"));
    }),
    Y.lang.extend(_.asn1.DERTeletexString, _.asn1.DERAbstractString),
    (_.asn1.DERIA5String = function (i) {
      (_.asn1.DERIA5String.superclass.constructor.call(this, i), (this.hT = "16"));
    }),
    Y.lang.extend(_.asn1.DERIA5String, _.asn1.DERAbstractString),
    (_.asn1.DERUTCTime = function (i) {
      (_.asn1.DERUTCTime.superclass.constructor.call(this, i),
        (this.hT = "17"),
        (this.setByDate = function (t) {
          ((this.hTLV = null),
            (this.isModified = !0),
            (this.date = t),
            (this.s = this.formatDate(this.date, "utc")),
            (this.hV = stohex(this.s)));
        }),
        (this.getFreshValueHex = function () {
          return (
            typeof this.date > "u" &&
              typeof this.s > "u" &&
              ((this.date = new Date()), (this.s = this.formatDate(this.date, "utc")), (this.hV = stohex(this.s))),
            this.hV
          );
        }),
        i !== void 0 &&
          (i.str !== void 0
            ? this.setString(i.str)
            : typeof i == "string" && i.match(/^[0-9]{12}Z$/)
              ? this.setString(i)
              : i.hex !== void 0
                ? this.setStringHex(i.hex)
                : i.date !== void 0 && this.setByDate(i.date)));
    }),
    Y.lang.extend(_.asn1.DERUTCTime, _.asn1.DERAbstractTime),
    (_.asn1.DERGeneralizedTime = function (i) {
      (_.asn1.DERGeneralizedTime.superclass.constructor.call(this, i),
        (this.hT = "18"),
        (this.withMillis = !1),
        (this.setByDate = function (t) {
          ((this.hTLV = null),
            (this.isModified = !0),
            (this.date = t),
            (this.s = this.formatDate(this.date, "gen", this.withMillis)),
            (this.hV = stohex(this.s)));
        }),
        (this.getFreshValueHex = function () {
          return (
            this.date === void 0 &&
              this.s === void 0 &&
              ((this.date = new Date()),
              (this.s = this.formatDate(this.date, "gen", this.withMillis)),
              (this.hV = stohex(this.s))),
            this.hV
          );
        }),
        i !== void 0 &&
          (i.str !== void 0
            ? this.setString(i.str)
            : typeof i == "string" && i.match(/^[0-9]{14}Z$/)
              ? this.setString(i)
              : i.hex !== void 0
                ? this.setStringHex(i.hex)
                : i.date !== void 0 && this.setByDate(i.date),
          i.millis === !0 && (this.withMillis = !0)));
    }),
    Y.lang.extend(_.asn1.DERGeneralizedTime, _.asn1.DERAbstractTime),
    (_.asn1.DERSequence = function (i) {
      (_.asn1.DERSequence.superclass.constructor.call(this, i),
        (this.hT = "30"),
        (this.getFreshValueHex = function () {
          for (var t = "", e = 0; e < this.asn1Array.length; e++) {
            var r = this.asn1Array[e];
            t += r.getEncodedHex();
          }
          return ((this.hV = t), this.hV);
        }));
    }),
    Y.lang.extend(_.asn1.DERSequence, _.asn1.DERAbstractStructured),
    (_.asn1.DERSet = function (i) {
      (_.asn1.DERSet.superclass.constructor.call(this, i),
        (this.hT = "31"),
        (this.sortFlag = !0),
        (this.getFreshValueHex = function () {
          for (var t = new Array(), e = 0; e < this.asn1Array.length; e++) {
            var r = this.asn1Array[e];
            t.push(r.getEncodedHex());
          }
          return (this.sortFlag == !0 && t.sort(), (this.hV = t.join("")), this.hV);
        }),
        typeof i < "u" && typeof i.sortflag < "u" && i.sortflag == !1 && (this.sortFlag = !1));
    }),
    Y.lang.extend(_.asn1.DERSet, _.asn1.DERAbstractStructured),
    (_.asn1.DERTaggedObject = function (i) {
      (_.asn1.DERTaggedObject.superclass.constructor.call(this),
        (this.hT = "a0"),
        (this.hV = ""),
        (this.isExplicit = !0),
        (this.asn1Object = null),
        (this.setASN1Object = function (t, e, r) {
          ((this.hT = e),
            (this.isExplicit = t),
            (this.asn1Object = r),
            this.isExplicit
              ? ((this.hV = this.asn1Object.getEncodedHex()), (this.hTLV = null), (this.isModified = !0))
              : ((this.hV = null),
                (this.hTLV = r.getEncodedHex()),
                (this.hTLV = this.hTLV.replace(/^../, e)),
                (this.isModified = !1)));
        }),
        (this.getFreshValueHex = function () {
          return this.hV;
        }),
        typeof i < "u" &&
          (typeof i.tag < "u" && (this.hT = i.tag),
          typeof i.explicit < "u" && (this.isExplicit = i.explicit),
          typeof i.obj < "u" &&
            ((this.asn1Object = i.obj), this.setASN1Object(this.isExplicit, this.hT, this.asn1Object))));
    }),
    Y.lang.extend(_.asn1.DERTaggedObject, _.asn1.ASN1Object));
  var Wi = (function () {
      var i = function (t, e) {
        return (
          (i =
            Object.setPrototypeOf ||
            ({__proto__: []} instanceof Array &&
              function (r, n) {
                r.__proto__ = n;
              }) ||
            function (r, n) {
              for (var s in n) Object.prototype.hasOwnProperty.call(n, s) && (r[s] = n[s]);
            }),
          i(t, e)
        );
      };
      return function (t, e) {
        if (typeof e != "function" && e !== null)
          throw new TypeError("Class extends value " + String(e) + " is not a constructor or null");
        i(t, e);
        function r() {
          this.constructor = t;
        }
        t.prototype = e === null ? Object.create(e) : ((r.prototype = e.prototype), new r());
      };
    })(),
    Ue = (function (i) {
      Wi(t, i);
      function t(e) {
        var r = i.call(this) || this;
        return (
          e &&
            (typeof e == "string"
              ? r.parseKey(e)
              : (t.hasPrivateKeyProperty(e) || t.hasPublicKeyProperty(e)) && r.parsePropertiesFrom(e)),
          r
        );
      }
      return (
        (t.prototype.parseKey = function (e) {
          try {
            var r = 0,
              n = 0,
              s = /^\s*(?:[0-9A-Fa-f][0-9A-Fa-f]\s*)+$/,
              a = s.test(e) ? Ti.decode(e) : Qt.unarmor(e),
              o = Ii.decode(a);
            if ((o.sub.length === 3 && (o = o.sub[2].sub[0]), o.sub.length === 9)) {
              ((r = o.sub[1].getHexStringValue()),
                (this.n = X(r, 16)),
                (n = o.sub[2].getHexStringValue()),
                (this.e = parseInt(n, 16)));
              var x = o.sub[3].getHexStringValue();
              this.d = X(x, 16);
              var c = o.sub[4].getHexStringValue();
              this.p = X(c, 16);
              var f = o.sub[5].getHexStringValue();
              this.q = X(f, 16);
              var g = o.sub[6].getHexStringValue();
              this.dmp1 = X(g, 16);
              var h = o.sub[7].getHexStringValue();
              this.dmq1 = X(h, 16);
              var l = o.sub[8].getHexStringValue();
              this.coeff = X(l, 16);
            } else if (o.sub.length === 2)
              if (o.sub[0].sub) {
                var d = o.sub[1],
                  y = d.sub[0];
                ((r = y.sub[0].getHexStringValue()),
                  (this.n = X(r, 16)),
                  (n = y.sub[1].getHexStringValue()),
                  (this.e = parseInt(n, 16)));
              } else
                ((r = o.sub[0].getHexStringValue()),
                  (this.n = X(r, 16)),
                  (n = o.sub[1].getHexStringValue()),
                  (this.e = parseInt(n, 16)));
            else return !1;
            return !0;
          } catch {
            return !1;
          }
        }),
        (t.prototype.getPrivateBaseKey = function () {
          var e = {
              array: [
                new _.asn1.DERInteger({int: 0}),
                new _.asn1.DERInteger({bigint: this.n}),
                new _.asn1.DERInteger({int: this.e}),
                new _.asn1.DERInteger({bigint: this.d}),
                new _.asn1.DERInteger({bigint: this.p}),
                new _.asn1.DERInteger({bigint: this.q}),
                new _.asn1.DERInteger({bigint: this.dmp1}),
                new _.asn1.DERInteger({bigint: this.dmq1}),
                new _.asn1.DERInteger({bigint: this.coeff}),
              ],
            },
            r = new _.asn1.DERSequence(e);
          return r.getEncodedHex();
        }),
        (t.prototype.getPrivateBaseKeyB64 = function () {
          return X0(this.getPrivateBaseKey());
        }),
        (t.prototype.getPublicBaseKey = function () {
          var e = new _.asn1.DERSequence({
              array: [new _.asn1.DERObjectIdentifier({oid: "1.2.840.113549.1.1.1"}), new _.asn1.DERNull()],
            }),
            r = new _.asn1.DERSequence({
              array: [new _.asn1.DERInteger({bigint: this.n}), new _.asn1.DERInteger({int: this.e})],
            }),
            n = new _.asn1.DERBitString({hex: "00" + r.getEncodedHex()}),
            s = new _.asn1.DERSequence({array: [e, n]});
          return s.getEncodedHex();
        }),
        (t.prototype.getPublicBaseKeyB64 = function () {
          return X0(this.getPublicBaseKey());
        }),
        (t.wordwrap = function (e, r) {
          if (((r = r || 64), !e)) return e;
          var n =
            "(.{1," +
            r +
            `})( +|$
?)|(.{1,` +
            r +
            "})";
          return e.match(RegExp(n, "g")).join(`
`);
        }),
        (t.prototype.getPrivateKey = function () {
          var e = `-----BEGIN RSA PRIVATE KEY-----
`;
          return (
            (e +=
              t.wordwrap(this.getPrivateBaseKeyB64()) +
              `
`),
            (e += "-----END RSA PRIVATE KEY-----"),
            e
          );
        }),
        (t.prototype.getPublicKey = function () {
          var e = `-----BEGIN PUBLIC KEY-----
`;
          return (
            (e +=
              t.wordwrap(this.getPublicBaseKeyB64()) +
              `
`),
            (e += "-----END PUBLIC KEY-----"),
            e
          );
        }),
        (t.hasPublicKeyProperty = function (e) {
          return ((e = e || {}), e.hasOwnProperty("n") && e.hasOwnProperty("e"));
        }),
        (t.hasPrivateKeyProperty = function (e) {
          return (
            (e = e || {}),
            e.hasOwnProperty("n") &&
              e.hasOwnProperty("e") &&
              e.hasOwnProperty("d") &&
              e.hasOwnProperty("p") &&
              e.hasOwnProperty("q") &&
              e.hasOwnProperty("dmp1") &&
              e.hasOwnProperty("dmq1") &&
              e.hasOwnProperty("coeff")
          );
        }),
        (t.prototype.parsePropertiesFrom = function (e) {
          ((this.n = e.n),
            (this.e = e.e),
            e.hasOwnProperty("d") &&
              ((this.d = e.d),
              (this.p = e.p),
              (this.q = e.q),
              (this.dmp1 = e.dmp1),
              (this.dmq1 = e.dmq1),
              (this.coeff = e.coeff)));
        }),
        t
      );
    })(Vi),
    ie,
    Gi = typeof process < "u" ? ((ie = process.env) === null || ie === void 0 ? void 0 : ie.npm_package_version) : void 0,
    Le = (function () {
      function i(t) {
        (t === void 0 && (t = {}),
          (t = t || {}),
          (this.default_key_size = t.default_key_size ? parseInt(t.default_key_size, 10) : 1024),
          (this.default_public_exponent = t.default_public_exponent || "010001"),
          (this.log = t.log || !1),
          (this.key = null));
      }
      return (
        (i.prototype.setKey = function (t) {
          (this.log && this.key && console.warn("A key was already set, overriding existing."), (this.key = new Ue(t)));
        }),
        (i.prototype.setPrivateKey = function (t) {
          this.setKey(t);
        }),
        (i.prototype.setPublicKey = function (t) {
          this.setKey(t);
        }),
        (i.prototype.decrypt = function (t) {
          try {
            return this.getKey().decrypt(Fe(t));
          } catch {
            return !1;
          }
        }),
        (i.prototype.encrypt = function (t) {
          try {
            return X0(this.getKey().encrypt(t));
          } catch {
            return !1;
          }
        }),
        (i.prototype.sign = function (t, e, r) {
          try {
            return X0(this.getKey().sign(t, e, r));
          } catch {
            return !1;
          }
        }),
        (i.prototype.verify = function (t, e, r) {
          try {
            return this.getKey().verify(t, Fe(e), r);
          } catch {
            return !1;
          }
        }),
        (i.prototype.getKey = function (t) {
          if (!this.key) {
            if (((this.key = new Ue()), t && {}.toString.call(t) === "[object Function]")) {
              this.key.generateAsync(this.default_key_size, this.default_public_exponent, t);
              return;
            }
            this.key.generate(this.default_key_size, this.default_public_exponent);
          }
          return this.key;
        }),
        (i.prototype.getPrivateKey = function () {
          return this.getKey().getPrivateKey();
        }),
        (i.prototype.getPrivateKeyB64 = function () {
          return this.getKey().getPrivateBaseKeyB64();
        }),
        (i.prototype.getPublicKey = function () {
          return this.getKey().getPublicKey();
        }),
        (i.prototype.getPublicKeyB64 = function () {
          return this.getKey().getPublicBaseKeyB64();
        }),
        (i.version = Gi),
        i
      );
    })(),
    ne =
      typeof globalThis < "u"
        ? globalThis
        : typeof window < "u"
          ? window
          : typeof global < "u"
            ? global
            : typeof self < "u"
              ? self
              : {};
  function Zi(i) {
    if (Object.prototype.hasOwnProperty.call(i, "__esModule")) return i;
    var t = i.default;
    if (typeof t == "function") {
      var e = function r() {
        return this instanceof r ? Reflect.construct(t, arguments, this.constructor) : t.apply(this, arguments);
      };
      e.prototype = t.prototype;
    } else e = {};
    return (
      Object.defineProperty(e, "__esModule", {value: !0}),
      Object.keys(i).forEach(function (r) {
        var n = Object.getOwnPropertyDescriptor(i, r);
        Object.defineProperty(
          e,
          r,
          n.get
            ? n
            : {
                enumerable: !0,
                get: function () {
                  return i[r];
                },
              },
        );
      }),
      e
    );
  }
  var nt = {exports: {}};
  function Xi(i) {
    throw new Error(
      'Could not dynamically require "' +
        i +
        '". Please configure the dynamicRequireTargets or/and ignoreDynamicRequires option of @rollup/plugin-commonjs appropriately for this require call to work.',
    );
  }
  var st = {exports: {}};
  const Yi = Zi(
    Object.freeze(Object.defineProperty({__proto__: null, default: {}}, Symbol.toStringTag, {value: "Module"})),
  );
  var Qi = st.exports,
    Ne;
  function z() {
    return (
      Ne ||
        ((Ne = 1),
        (function (i, t) {
          (function (e, r) {
            i.exports = r();
          })(Qi, function () {
            var e =
              e ||
              (function (r, n) {
                var s;
                if (
                  (typeof window < "u" && window.crypto && (s = window.crypto),
                  typeof self < "u" && self.crypto && (s = self.crypto),
                  typeof globalThis < "u" && globalThis.crypto && (s = globalThis.crypto),
                  !s && typeof window < "u" && window.msCrypto && (s = window.msCrypto),
                  !s && typeof ne < "u" && ne.crypto && (s = ne.crypto),
                  !s && typeof Xi == "function")
                )
                  try {
                    s = Yi;
                  } catch {}
                var a = function () {
                    if (s) {
                      if (typeof s.getRandomValues == "function")
                        try {
                          return s.getRandomValues(new Uint32Array(1))[0];
                        } catch {}
                      if (typeof s.randomBytes == "function")
                        try {
                          return s.randomBytes(4).readInt32LE();
                        } catch {}
                    }
                    throw new Error("Native crypto module could not be used to get secure random number.");
                  },
                  o =
                    Object.create ||
                    (function () {
                      function u() {}
                      return function (v) {
                        var E;
                        return ((u.prototype = v), (E = new u()), (u.prototype = null), E);
                      };
                    })(),
                  x = {},
                  c = (x.lib = {}),
                  f = (c.Base = (function () {
                    return {
                      extend: function (u) {
                        var v = o(this);
                        return (
                          u && v.mixIn(u),
                          (!v.hasOwnProperty("init") || this.init === v.init) &&
                            (v.init = function () {
                              v.$super.init.apply(this, arguments);
                            }),
                          (v.init.prototype = v),
                          (v.$super = this),
                          v
                        );
                      },
                      create: function () {
                        var u = this.extend();
                        return (u.init.apply(u, arguments), u);
                      },
                      init: function () {},
                      mixIn: function (u) {
                        for (var v in u) u.hasOwnProperty(v) && (this[v] = u[v]);
                        u.hasOwnProperty("toString") && (this.toString = u.toString);
                      },
                      clone: function () {
                        return this.init.prototype.extend(this);
                      },
                    };
                  })()),
                  g = (c.WordArray = f.extend({
                    init: function (u, v) {
                      ((u = this.words = u || []), v != n ? (this.sigBytes = v) : (this.sigBytes = u.length * 4));
                    },
                    toString: function (u) {
                      return (u || l).stringify(this);
                    },
                    concat: function (u) {
                      var v = this.words,
                        E = u.words,
                        m = this.sigBytes,
                        B = u.sigBytes;
                      if ((this.clamp(), m % 4))
                        for (var w = 0; w < B; w++) {
                          var b = (E[w >>> 2] >>> (24 - (w % 4) * 8)) & 255;
                          v[(m + w) >>> 2] |= b << (24 - ((m + w) % 4) * 8);
                        }
                      else for (var I = 0; I < B; I += 4) v[(m + I) >>> 2] = E[I >>> 2];
                      return ((this.sigBytes += B), this);
                    },
                    clamp: function () {
                      var u = this.words,
                        v = this.sigBytes;
                      ((u[v >>> 2] &= 4294967295 << (32 - (v % 4) * 8)), (u.length = r.ceil(v / 4)));
                    },
                    clone: function () {
                      var u = f.clone.call(this);
                      return ((u.words = this.words.slice(0)), u);
                    },
                    random: function (u) {
                      for (var v = [], E = 0; E < u; E += 4) v.push(a());
                      return new g.init(v, u);
                    },
                  })),
                  h = (x.enc = {}),
                  l = (h.Hex = {
                    stringify: function (u) {
                      for (var v = u.words, E = u.sigBytes, m = [], B = 0; B < E; B++) {
                        var w = (v[B >>> 2] >>> (24 - (B % 4) * 8)) & 255;
                        (m.push((w >>> 4).toString(16)), m.push((w & 15).toString(16)));
                      }
                      return m.join("");
                    },
                    parse: function (u) {
                      for (var v = u.length, E = [], m = 0; m < v; m += 2)
                        E[m >>> 3] |= parseInt(u.substr(m, 2), 16) << (24 - (m % 8) * 4);
                      return new g.init(E, v / 2);
                    },
                  }),
                  d = (h.Latin1 = {
                    stringify: function (u) {
                      for (var v = u.words, E = u.sigBytes, m = [], B = 0; B < E; B++) {
                        var w = (v[B >>> 2] >>> (24 - (B % 4) * 8)) & 255;
                        m.push(String.fromCharCode(w));
                      }
                      return m.join("");
                    },
                    parse: function (u) {
                      for (var v = u.length, E = [], m = 0; m < v; m++)
                        E[m >>> 2] |= (u.charCodeAt(m) & 255) << (24 - (m % 4) * 8);
                      return new g.init(E, v);
                    },
                  }),
                  y = (h.Utf8 = {
                    stringify: function (u) {
                      try {
                        return decodeURIComponent(escape(d.stringify(u)));
                      } catch {
                        throw new Error("Malformed UTF-8 data");
                      }
                    },
                    parse: function (u) {
                      return d.parse(unescape(encodeURIComponent(u)));
                    },
                  }),
                  p = (c.BufferedBlockAlgorithm = f.extend({
                    reset: function () {
                      ((this._data = new g.init()), (this._nDataBytes = 0));
                    },
                    _append: function (u) {
                      (typeof u == "string" && (u = y.parse(u)), this._data.concat(u), (this._nDataBytes += u.sigBytes));
                    },
                    _process: function (u) {
                      var v,
                        E = this._data,
                        m = E.words,
                        B = E.sigBytes,
                        w = this.blockSize,
                        b = w * 4,
                        I = B / b;
                      u ? (I = r.ceil(I)) : (I = r.max((I | 0) - this._minBufferSize, 0));
                      var D = I * w,
                        C = r.min(D * 4, B);
                      if (D) {
                        for (var T = 0; T < D; T += w) this._doProcessBlock(m, T);
                        ((v = m.splice(0, D)), (E.sigBytes -= C));
                      }
                      return new g.init(v, C);
                    },
                    clone: function () {
                      var u = f.clone.call(this);
                      return ((u._data = this._data.clone()), u);
                    },
                    _minBufferSize: 0,
                  }));
                c.Hasher = p.extend({
                  cfg: f.extend(),
                  init: function (u) {
                    ((this.cfg = this.cfg.extend(u)), this.reset());
                  },
                  reset: function () {
                    (p.reset.call(this), this._doReset());
                  },
                  update: function (u) {
                    return (this._append(u), this._process(), this);
                  },
                  finalize: function (u) {
                    u && this._append(u);
                    var v = this._doFinalize();
                    return v;
                  },
                  blockSize: 16,
                  _createHelper: function (u) {
                    return function (v, E) {
                      return new u.init(E).finalize(v);
                    };
                  },
                  _createHmacHelper: function (u) {
                    return function (v, E) {
                      return new A.HMAC.init(u, E).finalize(v);
                    };
                  },
                });
                var A = (x.algo = {});
                return x;
              })(Math);
            return e;
          });
        })(st)),
      st.exports
    );
  }
  var ot = {exports: {}},
    Ji = ot.exports,
    Ke;
  function at() {
    return (
      Ke ||
        ((Ke = 1),
        (function (i, t) {
          (function (e, r) {
            i.exports = r(z());
          })(Ji, function (e) {
            return (
              (function (r) {
                var n = e,
                  s = n.lib,
                  a = s.Base,
                  o = s.WordArray,
                  x = (n.x64 = {});
                ((x.Word = a.extend({
                  init: function (c, f) {
                    ((this.high = c), (this.low = f));
                  },
                })),
                  (x.WordArray = a.extend({
                    init: function (c, f) {
                      ((c = this.words = c || []), f != r ? (this.sigBytes = f) : (this.sigBytes = c.length * 8));
                    },
                    toX32: function () {
                      for (var c = this.words, f = c.length, g = [], h = 0; h < f; h++) {
                        var l = c[h];
                        (g.push(l.high), g.push(l.low));
                      }
                      return o.create(g, this.sigBytes);
                    },
                    clone: function () {
                      for (var c = a.clone.call(this), f = (c.words = this.words.slice(0)), g = f.length, h = 0; h < g; h++)
                        f[h] = f[h].clone();
                      return c;
                    },
                  })));
              })(),
              e
            );
          });
        })(ot)),
      ot.exports
    );
  }
  var ct = {exports: {}},
    tn = ct.exports,
    qe;
  function en() {
    return (
      qe ||
        ((qe = 1),
        (function (i, t) {
          (function (e, r) {
            i.exports = r(z());
          })(tn, function (e) {
            return (
              (function () {
                if (typeof ArrayBuffer == "function") {
                  var r = e,
                    n = r.lib,
                    s = n.WordArray,
                    a = s.init,
                    o = (s.init = function (x) {
                      if (
                        (x instanceof ArrayBuffer && (x = new Uint8Array(x)),
                        (x instanceof Int8Array ||
                          (typeof Uint8ClampedArray < "u" && x instanceof Uint8ClampedArray) ||
                          x instanceof Int16Array ||
                          x instanceof Uint16Array ||
                          x instanceof Int32Array ||
                          x instanceof Uint32Array ||
                          x instanceof Float32Array ||
                          x instanceof Float64Array) &&
                          (x = new Uint8Array(x.buffer, x.byteOffset, x.byteLength)),
                        x instanceof Uint8Array)
                      ) {
                        for (var c = x.byteLength, f = [], g = 0; g < c; g++) f[g >>> 2] |= x[g] << (24 - (g % 4) * 8);
                        a.call(this, f, c);
                      } else a.apply(this, arguments);
                    });
                  o.prototype = s;
                }
              })(),
              e.lib.WordArray
            );
          });
        })(ct)),
      ct.exports
    );
  }
  var xt = {exports: {}},
    rn = xt.exports,
    ze;
  function nn() {
    return (
      ze ||
        ((ze = 1),
        (function (i, t) {
          (function (e, r) {
            i.exports = r(z());
          })(rn, function (e) {
            return (
              (function () {
                var r = e,
                  n = r.lib,
                  s = n.WordArray,
                  a = r.enc;
                ((a.Utf16 = a.Utf16BE =
                  {
                    stringify: function (x) {
                      for (var c = x.words, f = x.sigBytes, g = [], h = 0; h < f; h += 2) {
                        var l = (c[h >>> 2] >>> (16 - (h % 4) * 8)) & 65535;
                        g.push(String.fromCharCode(l));
                      }
                      return g.join("");
                    },
                    parse: function (x) {
                      for (var c = x.length, f = [], g = 0; g < c; g++)
                        f[g >>> 1] |= x.charCodeAt(g) << (16 - (g % 2) * 16);
                      return s.create(f, c * 2);
                    },
                  }),
                  (a.Utf16LE = {
                    stringify: function (x) {
                      for (var c = x.words, f = x.sigBytes, g = [], h = 0; h < f; h += 2) {
                        var l = o((c[h >>> 2] >>> (16 - (h % 4) * 8)) & 65535);
                        g.push(String.fromCharCode(l));
                      }
                      return g.join("");
                    },
                    parse: function (x) {
                      for (var c = x.length, f = [], g = 0; g < c; g++)
                        f[g >>> 1] |= o(x.charCodeAt(g) << (16 - (g % 2) * 16));
                      return s.create(f, c * 2);
                    },
                  }));
                function o(x) {
                  return ((x << 8) & 4278255360) | ((x >>> 8) & 16711935);
                }
              })(),
              e.enc.Utf16
            );
          });
        })(xt)),
      xt.exports
    );
  }
  var ft = {exports: {}},
    sn = ft.exports,
    Ve;
  function A0() {
    return (
      Ve ||
        ((Ve = 1),
        (function (i, t) {
          (function (e, r) {
            i.exports = r(z());
          })(sn, function (e) {
            return (
              (function () {
                var r = e,
                  n = r.lib,
                  s = n.WordArray,
                  a = r.enc;
                a.Base64 = {
                  stringify: function (x) {
                    var c = x.words,
                      f = x.sigBytes,
                      g = this._map;
                    x.clamp();
                    for (var h = [], l = 0; l < f; l += 3)
                      for (
                        var d = (c[l >>> 2] >>> (24 - (l % 4) * 8)) & 255,
                          y = (c[(l + 1) >>> 2] >>> (24 - ((l + 1) % 4) * 8)) & 255,
                          p = (c[(l + 2) >>> 2] >>> (24 - ((l + 2) % 4) * 8)) & 255,
                          A = (d << 16) | (y << 8) | p,
                          u = 0;
                        u < 4 && l + u * 0.75 < f;
                        u++
                      )
                        h.push(g.charAt((A >>> (6 * (3 - u))) & 63));
                    var v = g.charAt(64);
                    if (v) for (; h.length % 4; ) h.push(v);
                    return h.join("");
                  },
                  parse: function (x) {
                    var c = x.length,
                      f = this._map,
                      g = this._reverseMap;
                    if (!g) {
                      g = this._reverseMap = [];
                      for (var h = 0; h < f.length; h++) g[f.charCodeAt(h)] = h;
                    }
                    var l = f.charAt(64);
                    if (l) {
                      var d = x.indexOf(l);
                      d !== -1 && (c = d);
                    }
                    return o(x, c, g);
                  },
                  _map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
                };
                function o(x, c, f) {
                  for (var g = [], h = 0, l = 0; l < c; l++)
                    if (l % 4) {
                      var d = f[x.charCodeAt(l - 1)] << ((l % 4) * 2),
                        y = f[x.charCodeAt(l)] >>> (6 - (l % 4) * 2),
                        p = d | y;
                      ((g[h >>> 2] |= p << (24 - (h % 4) * 8)), h++);
                    }
                  return s.create(g, h);
                }
              })(),
              e.enc.Base64
            );
          });
        })(ft)),
      ft.exports
    );
  }
  var ht = {exports: {}},
    on = ht.exports,
    Me;
  function an() {
    return (
      Me ||
        ((Me = 1),
        (function (i, t) {
          (function (e, r) {
            i.exports = r(z());
          })(on, function (e) {
            return (
              (function () {
                var r = e,
                  n = r.lib,
                  s = n.WordArray,
                  a = r.enc;
                a.Base64url = {
                  stringify: function (x, c) {
                    c === void 0 && (c = !0);
                    var f = x.words,
                      g = x.sigBytes,
                      h = c ? this._safe_map : this._map;
                    x.clamp();
                    for (var l = [], d = 0; d < g; d += 3)
                      for (
                        var y = (f[d >>> 2] >>> (24 - (d % 4) * 8)) & 255,
                          p = (f[(d + 1) >>> 2] >>> (24 - ((d + 1) % 4) * 8)) & 255,
                          A = (f[(d + 2) >>> 2] >>> (24 - ((d + 2) % 4) * 8)) & 255,
                          u = (y << 16) | (p << 8) | A,
                          v = 0;
                        v < 4 && d + v * 0.75 < g;
                        v++
                      )
                        l.push(h.charAt((u >>> (6 * (3 - v))) & 63));
                    var E = h.charAt(64);
                    if (E) for (; l.length % 4; ) l.push(E);
                    return l.join("");
                  },
                  parse: function (x, c) {
                    c === void 0 && (c = !0);
                    var f = x.length,
                      g = c ? this._safe_map : this._map,
                      h = this._reverseMap;
                    if (!h) {
                      h = this._reverseMap = [];
                      for (var l = 0; l < g.length; l++) h[g.charCodeAt(l)] = l;
                    }
                    var d = g.charAt(64);
                    if (d) {
                      var y = x.indexOf(d);
                      y !== -1 && (f = y);
                    }
                    return o(x, f, h);
                  },
                  _map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
                  _safe_map: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_",
                };
                function o(x, c, f) {
                  for (var g = [], h = 0, l = 0; l < c; l++)
                    if (l % 4) {
                      var d = f[x.charCodeAt(l - 1)] << ((l % 4) * 2),
                        y = f[x.charCodeAt(l)] >>> (6 - (l % 4) * 2),
                        p = d | y;
                      ((g[h >>> 2] |= p << (24 - (h % 4) * 8)), h++);
                    }
                  return s.create(g, h);
                }
              })(),
              e.enc.Base64url
            );
          });
        })(ht)),
      ht.exports
    );
  }
  var ut = {exports: {}},
    cn = ut.exports,
    $e;
  function C0() {
    return (
      $e ||
        (($e = 1),
        (function (i, t) {
          (function (e, r) {
            i.exports = r(z());
          })(cn, function (e) {
            return (
              (function (r) {
                var n = e,
                  s = n.lib,
                  a = s.WordArray,
                  o = s.Hasher,
                  x = n.algo,
                  c = [];
                (function () {
                  for (var y = 0; y < 64; y++) c[y] = (r.abs(r.sin(y + 1)) * 4294967296) | 0;
                })();
                var f = (x.MD5 = o.extend({
                  _doReset: function () {
                    this._hash = new a.init([1732584193, 4023233417, 2562383102, 271733878]);
                  },
                  _doProcessBlock: function (y, p) {
                    for (var A = 0; A < 16; A++) {
                      var u = p + A,
                        v = y[u];
                      y[u] = (((v << 8) | (v >>> 24)) & 16711935) | (((v << 24) | (v >>> 8)) & 4278255360);
                    }
                    var E = this._hash.words,
                      m = y[p + 0],
                      B = y[p + 1],
                      w = y[p + 2],
                      b = y[p + 3],
                      I = y[p + 4],
                      D = y[p + 5],
                      C = y[p + 6],
                      T = y[p + 7],
                      S = y[p + 8],
                      O = y[p + 9],
                      U = y[p + 10],
                      N = y[p + 11],
                      G = y[p + 12],
                      M = y[p + 13],
                      j = y[p + 14],
                      $ = y[p + 15],
                      F = E[0],
                      R = E[1],
                      P = E[2],
                      k = E[3];
                    ((F = g(F, R, P, k, m, 7, c[0])),
                      (k = g(k, F, R, P, B, 12, c[1])),
                      (P = g(P, k, F, R, w, 17, c[2])),
                      (R = g(R, P, k, F, b, 22, c[3])),
                      (F = g(F, R, P, k, I, 7, c[4])),
                      (k = g(k, F, R, P, D, 12, c[5])),
                      (P = g(P, k, F, R, C, 17, c[6])),
                      (R = g(R, P, k, F, T, 22, c[7])),
                      (F = g(F, R, P, k, S, 7, c[8])),
                      (k = g(k, F, R, P, O, 12, c[9])),
                      (P = g(P, k, F, R, U, 17, c[10])),
                      (R = g(R, P, k, F, N, 22, c[11])),
                      (F = g(F, R, P, k, G, 7, c[12])),
                      (k = g(k, F, R, P, M, 12, c[13])),
                      (P = g(P, k, F, R, j, 17, c[14])),
                      (R = g(R, P, k, F, $, 22, c[15])),
                      (F = h(F, R, P, k, B, 5, c[16])),
                      (k = h(k, F, R, P, C, 9, c[17])),
                      (P = h(P, k, F, R, N, 14, c[18])),
                      (R = h(R, P, k, F, m, 20, c[19])),
                      (F = h(F, R, P, k, D, 5, c[20])),
                      (k = h(k, F, R, P, U, 9, c[21])),
                      (P = h(P, k, F, R, $, 14, c[22])),
                      (R = h(R, P, k, F, I, 20, c[23])),
                      (F = h(F, R, P, k, O, 5, c[24])),
                      (k = h(k, F, R, P, j, 9, c[25])),
                      (P = h(P, k, F, R, b, 14, c[26])),
                      (R = h(R, P, k, F, S, 20, c[27])),
                      (F = h(F, R, P, k, M, 5, c[28])),
                      (k = h(k, F, R, P, w, 9, c[29])),
                      (P = h(P, k, F, R, T, 14, c[30])),
                      (R = h(R, P, k, F, G, 20, c[31])),
                      (F = l(F, R, P, k, D, 4, c[32])),
                      (k = l(k, F, R, P, S, 11, c[33])),
                      (P = l(P, k, F, R, N, 16, c[34])),
                      (R = l(R, P, k, F, j, 23, c[35])),
                      (F = l(F, R, P, k, B, 4, c[36])),
                      (k = l(k, F, R, P, I, 11, c[37])),
                      (P = l(P, k, F, R, T, 16, c[38])),
                      (R = l(R, P, k, F, U, 23, c[39])),
                      (F = l(F, R, P, k, M, 4, c[40])),
                      (k = l(k, F, R, P, m, 11, c[41])),
                      (P = l(P, k, F, R, b, 16, c[42])),
                      (R = l(R, P, k, F, C, 23, c[43])),
                      (F = l(F, R, P, k, O, 4, c[44])),
                      (k = l(k, F, R, P, G, 11, c[45])),
                      (P = l(P, k, F, R, $, 16, c[46])),
                      (R = l(R, P, k, F, w, 23, c[47])),
                      (F = d(F, R, P, k, m, 6, c[48])),
                      (k = d(k, F, R, P, T, 10, c[49])),
                      (P = d(P, k, F, R, j, 15, c[50])),
                      (R = d(R, P, k, F, D, 21, c[51])),
                      (F = d(F, R, P, k, G, 6, c[52])),
                      (k = d(k, F, R, P, b, 10, c[53])),
                      (P = d(P, k, F, R, U, 15, c[54])),
                      (R = d(R, P, k, F, B, 21, c[55])),
                      (F = d(F, R, P, k, S, 6, c[56])),
                      (k = d(k, F, R, P, $, 10, c[57])),
                      (P = d(P, k, F, R, C, 15, c[58])),
                      (R = d(R, P, k, F, M, 21, c[59])),
                      (F = d(F, R, P, k, I, 6, c[60])),
                      (k = d(k, F, R, P, N, 10, c[61])),
                      (P = d(P, k, F, R, w, 15, c[62])),
                      (R = d(R, P, k, F, O, 21, c[63])),
                      (E[0] = (E[0] + F) | 0),
                      (E[1] = (E[1] + R) | 0),
                      (E[2] = (E[2] + P) | 0),
                      (E[3] = (E[3] + k) | 0));
                  },
                  _doFinalize: function () {
                    var y = this._data,
                      p = y.words,
                      A = this._nDataBytes * 8,
                      u = y.sigBytes * 8;
                    p[u >>> 5] |= 128 << (24 - (u % 32));
                    var v = r.floor(A / 4294967296),
                      E = A;
                    ((p[(((u + 64) >>> 9) << 4) + 15] =
                      (((v << 8) | (v >>> 24)) & 16711935) | (((v << 24) | (v >>> 8)) & 4278255360)),
                      (p[(((u + 64) >>> 9) << 4) + 14] =
                        (((E << 8) | (E >>> 24)) & 16711935) | (((E << 24) | (E >>> 8)) & 4278255360)),
                      (y.sigBytes = (p.length + 1) * 4),
                      this._process());
                    for (var m = this._hash, B = m.words, w = 0; w < 4; w++) {
                      var b = B[w];
                      B[w] = (((b << 8) | (b >>> 24)) & 16711935) | (((b << 24) | (b >>> 8)) & 4278255360);
                    }
                    return m;
                  },
                  clone: function () {
                    var y = o.clone.call(this);
                    return ((y._hash = this._hash.clone()), y);
                  },
                }));
                function g(y, p, A, u, v, E, m) {
                  var B = y + ((p & A) | (~p & u)) + v + m;
                  return ((B << E) | (B >>> (32 - E))) + p;
                }
                function h(y, p, A, u, v, E, m) {
                  var B = y + ((p & u) | (A & ~u)) + v + m;
                  return ((B << E) | (B >>> (32 - E))) + p;
                }
                function l(y, p, A, u, v, E, m) {
                  var B = y + (p ^ A ^ u) + v + m;
                  return ((B << E) | (B >>> (32 - E))) + p;
                }
                function d(y, p, A, u, v, E, m) {
                  var B = y + (A ^ (p | ~u)) + v + m;
                  return ((B << E) | (B >>> (32 - E))) + p;
                }
                ((n.MD5 = o._createHelper(f)), (n.HmacMD5 = o._createHmacHelper(f)));
              })(Math),
              e.MD5
            );
          });
        })(ut)),
      ut.exports
    );
  }
  var lt = {exports: {}},
    xn = lt.exports,
    je;
  function We() {
    return (
      je ||
        ((je = 1),
        (function (i, t) {
          (function (e, r) {
            i.exports = r(z());
          })(xn, function (e) {
            return (
              (function () {
                var r = e,
                  n = r.lib,
                  s = n.WordArray,
                  a = n.Hasher,
                  o = r.algo,
                  x = [],
                  c = (o.SHA1 = a.extend({
                    _doReset: function () {
                      this._hash = new s.init([1732584193, 4023233417, 2562383102, 271733878, 3285377520]);
                    },
                    _doProcessBlock: function (f, g) {
                      for (var h = this._hash.words, l = h[0], d = h[1], y = h[2], p = h[3], A = h[4], u = 0; u < 80; u++) {
                        if (u < 16) x[u] = f[g + u] | 0;
                        else {
                          var v = x[u - 3] ^ x[u - 8] ^ x[u - 14] ^ x[u - 16];
                          x[u] = (v << 1) | (v >>> 31);
                        }
                        var E = ((l << 5) | (l >>> 27)) + A + x[u];
                        (u < 20
                          ? (E += ((d & y) | (~d & p)) + 1518500249)
                          : u < 40
                            ? (E += (d ^ y ^ p) + 1859775393)
                            : u < 60
                              ? (E += ((d & y) | (d & p) | (y & p)) - 1894007588)
                              : (E += (d ^ y ^ p) - 899497514),
                          (A = p),
                          (p = y),
                          (y = (d << 30) | (d >>> 2)),
                          (d = l),
                          (l = E));
                      }
                      ((h[0] = (h[0] + l) | 0),
                        (h[1] = (h[1] + d) | 0),
                        (h[2] = (h[2] + y) | 0),
                        (h[3] = (h[3] + p) | 0),
                        (h[4] = (h[4] + A) | 0));
                    },
                    _doFinalize: function () {
                      var f = this._data,
                        g = f.words,
                        h = this._nDataBytes * 8,
                        l = f.sigBytes * 8;
                      return (
                        (g[l >>> 5] |= 128 << (24 - (l % 32))),
                        (g[(((l + 64) >>> 9) << 4) + 14] = Math.floor(h / 4294967296)),
                        (g[(((l + 64) >>> 9) << 4) + 15] = h),
                        (f.sigBytes = g.length * 4),
                        this._process(),
                        this._hash
                      );
                    },
                    clone: function () {
                      var f = a.clone.call(this);
                      return ((f._hash = this._hash.clone()), f);
                    },
                  }));
                ((r.SHA1 = a._createHelper(c)), (r.HmacSHA1 = a._createHmacHelper(c)));
              })(),
              e.SHA1
            );
          });
        })(lt)),
      lt.exports
    );
  }
  var dt = {exports: {}},
    fn = dt.exports,
    Ge;
  function se() {
    return (
      Ge ||
        ((Ge = 1),
        (function (i, t) {
          (function (e, r) {
            i.exports = r(z());
          })(fn, function (e) {
            return (
              (function (r) {
                var n = e,
                  s = n.lib,
                  a = s.WordArray,
                  o = s.Hasher,
                  x = n.algo,
                  c = [],
                  f = [];
                (function () {
                  function l(A) {
                    for (var u = r.sqrt(A), v = 2; v <= u; v++) if (!(A % v)) return !1;
                    return !0;
                  }
                  function d(A) {
                    return ((A - (A | 0)) * 4294967296) | 0;
                  }
                  for (var y = 2, p = 0; p < 64; )
                    (l(y) && (p < 8 && (c[p] = d(r.pow(y, 1 / 2))), (f[p] = d(r.pow(y, 1 / 3))), p++), y++);
                })();
                var g = [],
                  h = (x.SHA256 = o.extend({
                    _doReset: function () {
                      this._hash = new a.init(c.slice(0));
                    },
                    _doProcessBlock: function (l, d) {
                      for (
                        var y = this._hash.words,
                          p = y[0],
                          A = y[1],
                          u = y[2],
                          v = y[3],
                          E = y[4],
                          m = y[5],
                          B = y[6],
                          w = y[7],
                          b = 0;
                        b < 64;
                        b++
                      ) {
                        if (b < 16) g[b] = l[d + b] | 0;
                        else {
                          var I = g[b - 15],
                            D = ((I << 25) | (I >>> 7)) ^ ((I << 14) | (I >>> 18)) ^ (I >>> 3),
                            C = g[b - 2],
                            T = ((C << 15) | (C >>> 17)) ^ ((C << 13) | (C >>> 19)) ^ (C >>> 10);
                          g[b] = D + g[b - 7] + T + g[b - 16];
                        }
                        var S = (E & m) ^ (~E & B),
                          O = (p & A) ^ (p & u) ^ (A & u),
                          U = ((p << 30) | (p >>> 2)) ^ ((p << 19) | (p >>> 13)) ^ ((p << 10) | (p >>> 22)),
                          N = ((E << 26) | (E >>> 6)) ^ ((E << 21) | (E >>> 11)) ^ ((E << 7) | (E >>> 25)),
                          G = w + N + S + f[b] + g[b],
                          M = U + O;
                        ((w = B), (B = m), (m = E), (E = (v + G) | 0), (v = u), (u = A), (A = p), (p = (G + M) | 0));
                      }
                      ((y[0] = (y[0] + p) | 0),
                        (y[1] = (y[1] + A) | 0),
                        (y[2] = (y[2] + u) | 0),
                        (y[3] = (y[3] + v) | 0),
                        (y[4] = (y[4] + E) | 0),
                        (y[5] = (y[5] + m) | 0),
                        (y[6] = (y[6] + B) | 0),
                        (y[7] = (y[7] + w) | 0));
                    },
                    _doFinalize: function () {
                      var l = this._data,
                        d = l.words,
                        y = this._nDataBytes * 8,
                        p = l.sigBytes * 8;
                      return (
                        (d[p >>> 5] |= 128 << (24 - (p % 32))),
                        (d[(((p + 64) >>> 9) << 4) + 14] = r.floor(y / 4294967296)),
                        (d[(((p + 64) >>> 9) << 4) + 15] = y),
                        (l.sigBytes = d.length * 4),
                        this._process(),
                        this._hash
                      );
                    },
                    clone: function () {
                      var l = o.clone.call(this);
                      return ((l._hash = this._hash.clone()), l);
                    },
                  }));
                ((n.SHA256 = o._createHelper(h)), (n.HmacSHA256 = o._createHmacHelper(h)));
              })(Math),
              e.SHA256
            );
          });
        })(dt)),
      dt.exports
    );
  }
  var vt = {exports: {}},
    hn = vt.exports,
    Ze;
  function un() {
    return (
      Ze ||
        ((Ze = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), se());
          })(hn, function (e) {
            return (
              (function () {
                var r = e,
                  n = r.lib,
                  s = n.WordArray,
                  a = r.algo,
                  o = a.SHA256,
                  x = (a.SHA224 = o.extend({
                    _doReset: function () {
                      this._hash = new s.init([
                        3238371032, 914150663, 812702999, 4144912697, 4290775857, 1750603025, 1694076839, 3204075428,
                      ]);
                    },
                    _doFinalize: function () {
                      var c = o._doFinalize.call(this);
                      return ((c.sigBytes -= 4), c);
                    },
                  }));
                ((r.SHA224 = o._createHelper(x)), (r.HmacSHA224 = o._createHmacHelper(x)));
              })(),
              e.SHA224
            );
          });
        })(vt)),
      vt.exports
    );
  }
  var pt = {exports: {}},
    ln = pt.exports,
    Xe;
  function Ye() {
    return (
      Xe ||
        ((Xe = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), at());
          })(ln, function (e) {
            return (
              (function () {
                var r = e,
                  n = r.lib,
                  s = n.Hasher,
                  a = r.x64,
                  o = a.Word,
                  x = a.WordArray,
                  c = r.algo;
                function f() {
                  return o.create.apply(o, arguments);
                }
                var g = [
                    f(1116352408, 3609767458),
                    f(1899447441, 602891725),
                    f(3049323471, 3964484399),
                    f(3921009573, 2173295548),
                    f(961987163, 4081628472),
                    f(1508970993, 3053834265),
                    f(2453635748, 2937671579),
                    f(2870763221, 3664609560),
                    f(3624381080, 2734883394),
                    f(310598401, 1164996542),
                    f(607225278, 1323610764),
                    f(1426881987, 3590304994),
                    f(1925078388, 4068182383),
                    f(2162078206, 991336113),
                    f(2614888103, 633803317),
                    f(3248222580, 3479774868),
                    f(3835390401, 2666613458),
                    f(4022224774, 944711139),
                    f(264347078, 2341262773),
                    f(604807628, 2007800933),
                    f(770255983, 1495990901),
                    f(1249150122, 1856431235),
                    f(1555081692, 3175218132),
                    f(1996064986, 2198950837),
                    f(2554220882, 3999719339),
                    f(2821834349, 766784016),
                    f(2952996808, 2566594879),
                    f(3210313671, 3203337956),
                    f(3336571891, 1034457026),
                    f(3584528711, 2466948901),
                    f(113926993, 3758326383),
                    f(338241895, 168717936),
                    f(666307205, 1188179964),
                    f(773529912, 1546045734),
                    f(1294757372, 1522805485),
                    f(1396182291, 2643833823),
                    f(1695183700, 2343527390),
                    f(1986661051, 1014477480),
                    f(2177026350, 1206759142),
                    f(2456956037, 344077627),
                    f(2730485921, 1290863460),
                    f(2820302411, 3158454273),
                    f(3259730800, 3505952657),
                    f(3345764771, 106217008),
                    f(3516065817, 3606008344),
                    f(3600352804, 1432725776),
                    f(4094571909, 1467031594),
                    f(275423344, 851169720),
                    f(430227734, 3100823752),
                    f(506948616, 1363258195),
                    f(659060556, 3750685593),
                    f(883997877, 3785050280),
                    f(958139571, 3318307427),
                    f(1322822218, 3812723403),
                    f(1537002063, 2003034995),
                    f(1747873779, 3602036899),
                    f(1955562222, 1575990012),
                    f(2024104815, 1125592928),
                    f(2227730452, 2716904306),
                    f(2361852424, 442776044),
                    f(2428436474, 593698344),
                    f(2756734187, 3733110249),
                    f(3204031479, 2999351573),
                    f(3329325298, 3815920427),
                    f(3391569614, 3928383900),
                    f(3515267271, 566280711),
                    f(3940187606, 3454069534),
                    f(4118630271, 4000239992),
                    f(116418474, 1914138554),
                    f(174292421, 2731055270),
                    f(289380356, 3203993006),
                    f(460393269, 320620315),
                    f(685471733, 587496836),
                    f(852142971, 1086792851),
                    f(1017036298, 365543100),
                    f(1126000580, 2618297676),
                    f(1288033470, 3409855158),
                    f(1501505948, 4234509866),
                    f(1607167915, 987167468),
                    f(1816402316, 1246189591),
                  ],
                  h = [];
                (function () {
                  for (var d = 0; d < 80; d++) h[d] = f();
                })();
                var l = (c.SHA512 = s.extend({
                  _doReset: function () {
                    this._hash = new x.init([
                      new o.init(1779033703, 4089235720),
                      new o.init(3144134277, 2227873595),
                      new o.init(1013904242, 4271175723),
                      new o.init(2773480762, 1595750129),
                      new o.init(1359893119, 2917565137),
                      new o.init(2600822924, 725511199),
                      new o.init(528734635, 4215389547),
                      new o.init(1541459225, 327033209),
                    ]);
                  },
                  _doProcessBlock: function (d, y) {
                    for (
                      var p = this._hash.words,
                        A = p[0],
                        u = p[1],
                        v = p[2],
                        E = p[3],
                        m = p[4],
                        B = p[5],
                        w = p[6],
                        b = p[7],
                        I = A.high,
                        D = A.low,
                        C = u.high,
                        T = u.low,
                        S = v.high,
                        O = v.low,
                        U = E.high,
                        N = E.low,
                        G = m.high,
                        M = m.low,
                        j = B.high,
                        $ = B.low,
                        F = w.high,
                        R = w.low,
                        P = b.high,
                        k = b.low,
                        Z = I,
                        W = D,
                        t0 = C,
                        K = T,
                        K0 = S,
                        T0 = O,
                        fe = U,
                        q0 = N,
                        c0 = G,
                        i0 = M,
                        qt = j,
                        z0 = $,
                        zt = F,
                        V0 = R,
                        he = P,
                        M0 = k,
                        x0 = 0;
                      x0 < 80;
                      x0++
                    ) {
                      var o0,
                        y0,
                        Vt = h[x0];
                      if (x0 < 16) ((y0 = Vt.high = d[y + x0 * 2] | 0), (o0 = Vt.low = d[y + x0 * 2 + 1] | 0));
                      else {
                        var br = h[x0 - 15],
                          k0 = br.high,
                          $0 = br.low,
                          cs = ((k0 >>> 1) | ($0 << 31)) ^ ((k0 >>> 8) | ($0 << 24)) ^ (k0 >>> 7),
                          _r = (($0 >>> 1) | (k0 << 31)) ^ (($0 >>> 8) | (k0 << 24)) ^ (($0 >>> 7) | (k0 << 25)),
                          Fr = h[x0 - 2],
                          R0 = Fr.high,
                          j0 = Fr.low,
                          xs = ((R0 >>> 19) | (j0 << 13)) ^ ((R0 << 3) | (j0 >>> 29)) ^ (R0 >>> 6),
                          Sr = ((j0 >>> 19) | (R0 << 13)) ^ ((j0 << 3) | (R0 >>> 29)) ^ ((j0 >>> 6) | (R0 << 26)),
                          Tr = h[x0 - 7],
                          fs = Tr.high,
                          hs = Tr.low,
                          kr = h[x0 - 16],
                          us = kr.high,
                          Rr = kr.low;
                        ((o0 = _r + hs),
                          (y0 = cs + fs + (o0 >>> 0 < _r >>> 0 ? 1 : 0)),
                          (o0 = o0 + Sr),
                          (y0 = y0 + xs + (o0 >>> 0 < Sr >>> 0 ? 1 : 0)),
                          (o0 = o0 + Rr),
                          (y0 = y0 + us + (o0 >>> 0 < Rr >>> 0 ? 1 : 0)),
                          (Vt.high = y0),
                          (Vt.low = o0));
                      }
                      var ls = (c0 & qt) ^ (~c0 & zt),
                        Ir = (i0 & z0) ^ (~i0 & V0),
                        ds = (Z & t0) ^ (Z & K0) ^ (t0 & K0),
                        vs = (W & K) ^ (W & T0) ^ (K & T0),
                        ps = ((Z >>> 28) | (W << 4)) ^ ((Z << 30) | (W >>> 2)) ^ ((Z << 25) | (W >>> 7)),
                        Pr = ((W >>> 28) | (Z << 4)) ^ ((W << 30) | (Z >>> 2)) ^ ((W << 25) | (Z >>> 7)),
                        gs = ((c0 >>> 14) | (i0 << 18)) ^ ((c0 >>> 18) | (i0 << 14)) ^ ((c0 << 23) | (i0 >>> 9)),
                        ys = ((i0 >>> 14) | (c0 << 18)) ^ ((i0 >>> 18) | (c0 << 14)) ^ ((i0 << 23) | (c0 >>> 9)),
                        Or = g[x0],
                        Es = Or.high,
                        Hr = Or.low,
                        n0 = M0 + ys,
                        E0 = he + gs + (n0 >>> 0 < M0 >>> 0 ? 1 : 0),
                        n0 = n0 + Ir,
                        E0 = E0 + ls + (n0 >>> 0 < Ir >>> 0 ? 1 : 0),
                        n0 = n0 + Hr,
                        E0 = E0 + Es + (n0 >>> 0 < Hr >>> 0 ? 1 : 0),
                        n0 = n0 + o0,
                        E0 = E0 + y0 + (n0 >>> 0 < o0 >>> 0 ? 1 : 0),
                        Ur = Pr + vs,
                        Bs = ps + ds + (Ur >>> 0 < Pr >>> 0 ? 1 : 0);
                      ((he = zt),
                        (M0 = V0),
                        (zt = qt),
                        (V0 = z0),
                        (qt = c0),
                        (z0 = i0),
                        (i0 = (q0 + n0) | 0),
                        (c0 = (fe + E0 + (i0 >>> 0 < q0 >>> 0 ? 1 : 0)) | 0),
                        (fe = K0),
                        (q0 = T0),
                        (K0 = t0),
                        (T0 = K),
                        (t0 = Z),
                        (K = W),
                        (W = (n0 + Ur) | 0),
                        (Z = (E0 + Bs + (W >>> 0 < n0 >>> 0 ? 1 : 0)) | 0));
                    }
                    ((D = A.low = D + W),
                      (A.high = I + Z + (D >>> 0 < W >>> 0 ? 1 : 0)),
                      (T = u.low = T + K),
                      (u.high = C + t0 + (T >>> 0 < K >>> 0 ? 1 : 0)),
                      (O = v.low = O + T0),
                      (v.high = S + K0 + (O >>> 0 < T0 >>> 0 ? 1 : 0)),
                      (N = E.low = N + q0),
                      (E.high = U + fe + (N >>> 0 < q0 >>> 0 ? 1 : 0)),
                      (M = m.low = M + i0),
                      (m.high = G + c0 + (M >>> 0 < i0 >>> 0 ? 1 : 0)),
                      ($ = B.low = $ + z0),
                      (B.high = j + qt + ($ >>> 0 < z0 >>> 0 ? 1 : 0)),
                      (R = w.low = R + V0),
                      (w.high = F + zt + (R >>> 0 < V0 >>> 0 ? 1 : 0)),
                      (k = b.low = k + M0),
                      (b.high = P + he + (k >>> 0 < M0 >>> 0 ? 1 : 0)));
                  },
                  _doFinalize: function () {
                    var d = this._data,
                      y = d.words,
                      p = this._nDataBytes * 8,
                      A = d.sigBytes * 8;
                    ((y[A >>> 5] |= 128 << (24 - (A % 32))),
                      (y[(((A + 128) >>> 10) << 5) + 30] = Math.floor(p / 4294967296)),
                      (y[(((A + 128) >>> 10) << 5) + 31] = p),
                      (d.sigBytes = y.length * 4),
                      this._process());
                    var u = this._hash.toX32();
                    return u;
                  },
                  clone: function () {
                    var d = s.clone.call(this);
                    return ((d._hash = this._hash.clone()), d);
                  },
                  blockSize: 1024 / 32,
                }));
                ((r.SHA512 = s._createHelper(l)), (r.HmacSHA512 = s._createHmacHelper(l)));
              })(),
              e.SHA512
            );
          });
        })(pt)),
      pt.exports
    );
  }
  var gt = {exports: {}},
    dn = gt.exports,
    Qe;
  function vn() {
    return (
      Qe ||
        ((Qe = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), at(), Ye());
          })(dn, function (e) {
            return (
              (function () {
                var r = e,
                  n = r.x64,
                  s = n.Word,
                  a = n.WordArray,
                  o = r.algo,
                  x = o.SHA512,
                  c = (o.SHA384 = x.extend({
                    _doReset: function () {
                      this._hash = new a.init([
                        new s.init(3418070365, 3238371032),
                        new s.init(1654270250, 914150663),
                        new s.init(2438529370, 812702999),
                        new s.init(355462360, 4144912697),
                        new s.init(1731405415, 4290775857),
                        new s.init(2394180231, 1750603025),
                        new s.init(3675008525, 1694076839),
                        new s.init(1203062813, 3204075428),
                      ]);
                    },
                    _doFinalize: function () {
                      var f = x._doFinalize.call(this);
                      return ((f.sigBytes -= 16), f);
                    },
                  }));
                ((r.SHA384 = x._createHelper(c)), (r.HmacSHA384 = x._createHmacHelper(c)));
              })(),
              e.SHA384
            );
          });
        })(gt)),
      gt.exports
    );
  }
  var yt = {exports: {}},
    pn = yt.exports,
    Je;
  function gn() {
    return (
      Je ||
        ((Je = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), at());
          })(pn, function (e) {
            return (
              (function (r) {
                var n = e,
                  s = n.lib,
                  a = s.WordArray,
                  o = s.Hasher,
                  x = n.x64,
                  c = x.Word,
                  f = n.algo,
                  g = [],
                  h = [],
                  l = [];
                (function () {
                  for (var p = 1, A = 0, u = 0; u < 24; u++) {
                    g[p + 5 * A] = (((u + 1) * (u + 2)) / 2) % 64;
                    var v = A % 5,
                      E = (2 * p + 3 * A) % 5;
                    ((p = v), (A = E));
                  }
                  for (var p = 0; p < 5; p++) for (var A = 0; A < 5; A++) h[p + 5 * A] = A + ((2 * p + 3 * A) % 5) * 5;
                  for (var m = 1, B = 0; B < 24; B++) {
                    for (var w = 0, b = 0, I = 0; I < 7; I++) {
                      if (m & 1) {
                        var D = (1 << I) - 1;
                        D < 32 ? (b ^= 1 << D) : (w ^= 1 << (D - 32));
                      }
                      m & 128 ? (m = (m << 1) ^ 113) : (m <<= 1);
                    }
                    l[B] = c.create(w, b);
                  }
                })();
                var d = [];
                (function () {
                  for (var p = 0; p < 25; p++) d[p] = c.create();
                })();
                var y = (f.SHA3 = o.extend({
                  cfg: o.cfg.extend({outputLength: 512}),
                  _doReset: function () {
                    for (var p = (this._state = []), A = 0; A < 25; A++) p[A] = new c.init();
                    this.blockSize = (1600 - 2 * this.cfg.outputLength) / 32;
                  },
                  _doProcessBlock: function (p, A) {
                    for (var u = this._state, v = this.blockSize / 2, E = 0; E < v; E++) {
                      var m = p[A + 2 * E],
                        B = p[A + 2 * E + 1];
                      ((m = (((m << 8) | (m >>> 24)) & 16711935) | (((m << 24) | (m >>> 8)) & 4278255360)),
                        (B = (((B << 8) | (B >>> 24)) & 16711935) | (((B << 24) | (B >>> 8)) & 4278255360)));
                      var w = u[E];
                      ((w.high ^= B), (w.low ^= m));
                    }
                    for (var b = 0; b < 24; b++) {
                      for (var I = 0; I < 5; I++) {
                        for (var D = 0, C = 0, T = 0; T < 5; T++) {
                          var w = u[I + 5 * T];
                          ((D ^= w.high), (C ^= w.low));
                        }
                        var S = d[I];
                        ((S.high = D), (S.low = C));
                      }
                      for (var I = 0; I < 5; I++)
                        for (
                          var O = d[(I + 4) % 5],
                            U = d[(I + 1) % 5],
                            N = U.high,
                            G = U.low,
                            D = O.high ^ ((N << 1) | (G >>> 31)),
                            C = O.low ^ ((G << 1) | (N >>> 31)),
                            T = 0;
                          T < 5;
                          T++
                        ) {
                          var w = u[I + 5 * T];
                          ((w.high ^= D), (w.low ^= C));
                        }
                      for (var M = 1; M < 25; M++) {
                        var D,
                          C,
                          w = u[M],
                          j = w.high,
                          $ = w.low,
                          F = g[M];
                        F < 32
                          ? ((D = (j << F) | ($ >>> (32 - F))), (C = ($ << F) | (j >>> (32 - F))))
                          : ((D = ($ << (F - 32)) | (j >>> (64 - F))), (C = (j << (F - 32)) | ($ >>> (64 - F))));
                        var R = d[h[M]];
                        ((R.high = D), (R.low = C));
                      }
                      var P = d[0],
                        k = u[0];
                      ((P.high = k.high), (P.low = k.low));
                      for (var I = 0; I < 5; I++)
                        for (var T = 0; T < 5; T++) {
                          var M = I + 5 * T,
                            w = u[M],
                            Z = d[M],
                            W = d[((I + 1) % 5) + 5 * T],
                            t0 = d[((I + 2) % 5) + 5 * T];
                          ((w.high = Z.high ^ (~W.high & t0.high)), (w.low = Z.low ^ (~W.low & t0.low)));
                        }
                      var w = u[0],
                        K = l[b];
                      ((w.high ^= K.high), (w.low ^= K.low));
                    }
                  },
                  _doFinalize: function () {
                    var p = this._data,
                      A = p.words;
                    this._nDataBytes * 8;
                    var u = p.sigBytes * 8,
                      v = this.blockSize * 32;
                    ((A[u >>> 5] |= 1 << (24 - (u % 32))),
                      (A[((r.ceil((u + 1) / v) * v) >>> 5) - 1] |= 128),
                      (p.sigBytes = A.length * 4),
                      this._process());
                    for (var E = this._state, m = this.cfg.outputLength / 8, B = m / 8, w = [], b = 0; b < B; b++) {
                      var I = E[b],
                        D = I.high,
                        C = I.low;
                      ((D = (((D << 8) | (D >>> 24)) & 16711935) | (((D << 24) | (D >>> 8)) & 4278255360)),
                        (C = (((C << 8) | (C >>> 24)) & 16711935) | (((C << 24) | (C >>> 8)) & 4278255360)),
                        w.push(C),
                        w.push(D));
                    }
                    return new a.init(w, m);
                  },
                  clone: function () {
                    for (var p = o.clone.call(this), A = (p._state = this._state.slice(0)), u = 0; u < 25; u++)
                      A[u] = A[u].clone();
                    return p;
                  },
                }));
                ((n.SHA3 = o._createHelper(y)), (n.HmacSHA3 = o._createHmacHelper(y)));
              })(Math),
              e.SHA3
            );
          });
        })(yt)),
      yt.exports
    );
  }
  var Et = {exports: {}},
    yn = Et.exports,
    tr;
  function En() {
    return (
      tr ||
        ((tr = 1),
        (function (i, t) {
          (function (e, r) {
            i.exports = r(z());
          })(yn, function (e) {
            /** @preserve
  			(c) 2012 by Cédric Mesnil. All rights reserved.

  			Redistribution and use in source and binary forms, with or without modification, are permitted provided that the following conditions are met:

  			    - Redistributions of source code must retain the above copyright notice, this list of conditions and the following disclaimer.
  			    - Redistributions in binary form must reproduce the above copyright notice, this list of conditions and the following disclaimer in the documentation and/or other materials provided with the distribution.

  			THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  			*/ return (
              (function (r) {
                var n = e,
                  s = n.lib,
                  a = s.WordArray,
                  o = s.Hasher,
                  x = n.algo,
                  c = a.create([
                    0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 7, 4, 13, 1, 10, 6, 15, 3, 12, 0, 9, 5, 2, 14, 11,
                    8, 3, 10, 14, 4, 9, 15, 8, 1, 2, 7, 0, 6, 13, 11, 5, 12, 1, 9, 11, 10, 0, 8, 12, 4, 13, 3, 7, 15, 14, 5,
                    6, 2, 4, 0, 5, 9, 7, 12, 2, 10, 14, 1, 3, 8, 11, 6, 15, 13,
                  ]),
                  f = a.create([
                    5, 14, 7, 0, 9, 2, 11, 4, 13, 6, 15, 8, 1, 10, 3, 12, 6, 11, 3, 7, 0, 13, 5, 10, 14, 15, 8, 12, 4, 9, 1,
                    2, 15, 5, 1, 3, 7, 14, 6, 9, 11, 8, 12, 2, 10, 0, 4, 13, 8, 6, 4, 1, 3, 11, 15, 0, 5, 12, 2, 13, 9, 7,
                    10, 14, 12, 15, 10, 4, 1, 5, 8, 7, 6, 2, 13, 14, 0, 3, 9, 11,
                  ]),
                  g = a.create([
                    11, 14, 15, 12, 5, 8, 7, 9, 11, 13, 14, 15, 6, 7, 9, 8, 7, 6, 8, 13, 11, 9, 7, 15, 7, 12, 15, 9, 11, 7,
                    13, 12, 11, 13, 6, 7, 14, 9, 13, 15, 14, 8, 13, 6, 5, 12, 7, 5, 11, 12, 14, 15, 14, 15, 9, 8, 9, 14, 5,
                    6, 8, 6, 5, 12, 9, 15, 5, 11, 6, 8, 13, 12, 5, 12, 13, 14, 11, 8, 5, 6,
                  ]),
                  h = a.create([
                    8, 9, 9, 11, 13, 15, 15, 5, 7, 7, 8, 11, 14, 14, 12, 6, 9, 13, 15, 7, 12, 8, 9, 11, 7, 7, 12, 7, 6, 15,
                    13, 11, 9, 7, 15, 11, 8, 6, 6, 14, 12, 13, 5, 14, 13, 13, 7, 5, 15, 5, 8, 11, 14, 14, 6, 14, 6, 9, 12,
                    9, 12, 5, 15, 8, 8, 5, 12, 9, 12, 5, 14, 6, 8, 13, 6, 5, 15, 13, 11, 11,
                  ]),
                  l = a.create([0, 1518500249, 1859775393, 2400959708, 2840853838]),
                  d = a.create([1352829926, 1548603684, 1836072691, 2053994217, 0]),
                  y = (x.RIPEMD160 = o.extend({
                    _doReset: function () {
                      this._hash = a.create([1732584193, 4023233417, 2562383102, 271733878, 3285377520]);
                    },
                    _doProcessBlock: function (B, w) {
                      for (var b = 0; b < 16; b++) {
                        var I = w + b,
                          D = B[I];
                        B[I] = (((D << 8) | (D >>> 24)) & 16711935) | (((D << 24) | (D >>> 8)) & 4278255360);
                      }
                      var C = this._hash.words,
                        T = l.words,
                        S = d.words,
                        O = c.words,
                        U = f.words,
                        N = g.words,
                        G = h.words,
                        M,
                        j,
                        $,
                        F,
                        R,
                        P,
                        k,
                        Z,
                        W,
                        t0;
                      ((P = M = C[0]), (k = j = C[1]), (Z = $ = C[2]), (W = F = C[3]), (t0 = R = C[4]));
                      for (var K, b = 0; b < 80; b += 1)
                        ((K = (M + B[w + O[b]]) | 0),
                          b < 16
                            ? (K += p(j, $, F) + T[0])
                            : b < 32
                              ? (K += A(j, $, F) + T[1])
                              : b < 48
                                ? (K += u(j, $, F) + T[2])
                                : b < 64
                                  ? (K += v(j, $, F) + T[3])
                                  : (K += E(j, $, F) + T[4]),
                          (K = K | 0),
                          (K = m(K, N[b])),
                          (K = (K + R) | 0),
                          (M = R),
                          (R = F),
                          (F = m($, 10)),
                          ($ = j),
                          (j = K),
                          (K = (P + B[w + U[b]]) | 0),
                          b < 16
                            ? (K += E(k, Z, W) + S[0])
                            : b < 32
                              ? (K += v(k, Z, W) + S[1])
                              : b < 48
                                ? (K += u(k, Z, W) + S[2])
                                : b < 64
                                  ? (K += A(k, Z, W) + S[3])
                                  : (K += p(k, Z, W) + S[4]),
                          (K = K | 0),
                          (K = m(K, G[b])),
                          (K = (K + t0) | 0),
                          (P = t0),
                          (t0 = W),
                          (W = m(Z, 10)),
                          (Z = k),
                          (k = K));
                      ((K = (C[1] + $ + W) | 0),
                        (C[1] = (C[2] + F + t0) | 0),
                        (C[2] = (C[3] + R + P) | 0),
                        (C[3] = (C[4] + M + k) | 0),
                        (C[4] = (C[0] + j + Z) | 0),
                        (C[0] = K));
                    },
                    _doFinalize: function () {
                      var B = this._data,
                        w = B.words,
                        b = this._nDataBytes * 8,
                        I = B.sigBytes * 8;
                      ((w[I >>> 5] |= 128 << (24 - (I % 32))),
                        (w[(((I + 64) >>> 9) << 4) + 14] =
                          (((b << 8) | (b >>> 24)) & 16711935) | (((b << 24) | (b >>> 8)) & 4278255360)),
                        (B.sigBytes = (w.length + 1) * 4),
                        this._process());
                      for (var D = this._hash, C = D.words, T = 0; T < 5; T++) {
                        var S = C[T];
                        C[T] = (((S << 8) | (S >>> 24)) & 16711935) | (((S << 24) | (S >>> 8)) & 4278255360);
                      }
                      return D;
                    },
                    clone: function () {
                      var B = o.clone.call(this);
                      return ((B._hash = this._hash.clone()), B);
                    },
                  }));
                function p(B, w, b) {
                  return B ^ w ^ b;
                }
                function A(B, w, b) {
                  return (B & w) | (~B & b);
                }
                function u(B, w, b) {
                  return (B | ~w) ^ b;
                }
                function v(B, w, b) {
                  return (B & b) | (w & ~b);
                }
                function E(B, w, b) {
                  return B ^ (w | ~b);
                }
                function m(B, w) {
                  return (B << w) | (B >>> (32 - w));
                }
                ((n.RIPEMD160 = o._createHelper(y)), (n.HmacRIPEMD160 = o._createHmacHelper(y)));
              })(),
              e.RIPEMD160
            );
          });
        })(Et)),
      Et.exports
    );
  }
  var Bt = {exports: {}},
    Bn = Bt.exports,
    er;
  function oe() {
    return (
      er ||
        ((er = 1),
        (function (i, t) {
          (function (e, r) {
            i.exports = r(z());
          })(Bn, function (e) {
            (function () {
              var r = e,
                n = r.lib,
                s = n.Base,
                a = r.enc,
                o = a.Utf8,
                x = r.algo;
              x.HMAC = s.extend({
                init: function (c, f) {
                  ((c = this._hasher = new c.init()), typeof f == "string" && (f = o.parse(f)));
                  var g = c.blockSize,
                    h = g * 4;
                  (f.sigBytes > h && (f = c.finalize(f)), f.clamp());
                  for (
                    var l = (this._oKey = f.clone()), d = (this._iKey = f.clone()), y = l.words, p = d.words, A = 0;
                    A < g;
                    A++
                  )
                    ((y[A] ^= 1549556828), (p[A] ^= 909522486));
                  ((l.sigBytes = d.sigBytes = h), this.reset());
                },
                reset: function () {
                  var c = this._hasher;
                  (c.reset(), c.update(this._iKey));
                },
                update: function (c) {
                  return (this._hasher.update(c), this);
                },
                finalize: function (c) {
                  var f = this._hasher,
                    g = f.finalize(c);
                  f.reset();
                  var h = f.finalize(this._oKey.clone().concat(g));
                  return h;
                },
              });
            })();
          });
        })(Bt)),
      Bt.exports
    );
  }
  var Dt = {exports: {}},
    Dn = Dt.exports,
    rr;
  function An() {
    return (
      rr ||
        ((rr = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), se(), oe());
          })(Dn, function (e) {
            return (
              (function () {
                var r = e,
                  n = r.lib,
                  s = n.Base,
                  a = n.WordArray,
                  o = r.algo,
                  x = o.SHA256,
                  c = o.HMAC,
                  f = (o.PBKDF2 = s.extend({
                    cfg: s.extend({keySize: 128 / 32, hasher: x, iterations: 25e4}),
                    init: function (g) {
                      this.cfg = this.cfg.extend(g);
                    },
                    compute: function (g, h) {
                      for (
                        var l = this.cfg,
                          d = c.create(l.hasher, g),
                          y = a.create(),
                          p = a.create([1]),
                          A = y.words,
                          u = p.words,
                          v = l.keySize,
                          E = l.iterations;
                        A.length < v;
                      ) {
                        var m = d.update(h).finalize(p);
                        d.reset();
                        for (var B = m.words, w = B.length, b = m, I = 1; I < E; I++) {
                          ((b = d.finalize(b)), d.reset());
                          for (var D = b.words, C = 0; C < w; C++) B[C] ^= D[C];
                        }
                        (y.concat(m), u[0]++);
                      }
                      return ((y.sigBytes = v * 4), y);
                    },
                  }));
                r.PBKDF2 = function (g, h, l) {
                  return f.create(l).compute(g, h);
                };
              })(),
              e.PBKDF2
            );
          });
        })(Dt)),
      Dt.exports
    );
  }
  var At = {exports: {}},
    Cn = At.exports,
    ir;
  function g0() {
    return (
      ir ||
        ((ir = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), We(), oe());
          })(Cn, function (e) {
            return (
              (function () {
                var r = e,
                  n = r.lib,
                  s = n.Base,
                  a = n.WordArray,
                  o = r.algo,
                  x = o.MD5,
                  c = (o.EvpKDF = s.extend({
                    cfg: s.extend({keySize: 128 / 32, hasher: x, iterations: 1}),
                    init: function (f) {
                      this.cfg = this.cfg.extend(f);
                    },
                    compute: function (f, g) {
                      for (
                        var h,
                          l = this.cfg,
                          d = l.hasher.create(),
                          y = a.create(),
                          p = y.words,
                          A = l.keySize,
                          u = l.iterations;
                        p.length < A;
                      ) {
                        (h && d.update(h), (h = d.update(f).finalize(g)), d.reset());
                        for (var v = 1; v < u; v++) ((h = d.finalize(h)), d.reset());
                        y.concat(h);
                      }
                      return ((y.sigBytes = A * 4), y);
                    },
                  }));
                r.EvpKDF = function (f, g, h) {
                  return c.create(h).compute(f, g);
                };
              })(),
              e.EvpKDF
            );
          });
        })(At)),
      At.exports
    );
  }
  var Ct = {exports: {}},
    mn = Ct.exports,
    nr;
  function Q() {
    return (
      nr ||
        ((nr = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), g0());
          })(mn, function (e) {
            e.lib.Cipher ||
              (function (r) {
                var n = e,
                  s = n.lib,
                  a = s.Base,
                  o = s.WordArray,
                  x = s.BufferedBlockAlgorithm,
                  c = n.enc;
                c.Utf8;
                var f = c.Base64,
                  g = n.algo,
                  h = g.EvpKDF,
                  l = (s.Cipher = x.extend({
                    cfg: a.extend(),
                    createEncryptor: function (D, C) {
                      return this.create(this._ENC_XFORM_MODE, D, C);
                    },
                    createDecryptor: function (D, C) {
                      return this.create(this._DEC_XFORM_MODE, D, C);
                    },
                    init: function (D, C, T) {
                      ((this.cfg = this.cfg.extend(T)), (this._xformMode = D), (this._key = C), this.reset());
                    },
                    reset: function () {
                      (x.reset.call(this), this._doReset());
                    },
                    process: function (D) {
                      return (this._append(D), this._process());
                    },
                    finalize: function (D) {
                      D && this._append(D);
                      var C = this._doFinalize();
                      return C;
                    },
                    keySize: 128 / 32,
                    ivSize: 128 / 32,
                    _ENC_XFORM_MODE: 1,
                    _DEC_XFORM_MODE: 2,
                    _createHelper: (function () {
                      function D(C) {
                        return typeof C == "string" ? I : B;
                      }
                      return function (C) {
                        return {
                          encrypt: function (T, S, O) {
                            return D(S).encrypt(C, T, S, O);
                          },
                          decrypt: function (T, S, O) {
                            return D(S).decrypt(C, T, S, O);
                          },
                        };
                      };
                    })(),
                  }));
                s.StreamCipher = l.extend({
                  _doFinalize: function () {
                    var D = this._process(!0);
                    return D;
                  },
                  blockSize: 1,
                });
                var d = (n.mode = {}),
                  y = (s.BlockCipherMode = a.extend({
                    createEncryptor: function (D, C) {
                      return this.Encryptor.create(D, C);
                    },
                    createDecryptor: function (D, C) {
                      return this.Decryptor.create(D, C);
                    },
                    init: function (D, C) {
                      ((this._cipher = D), (this._iv = C));
                    },
                  })),
                  p = (d.CBC = (function () {
                    var D = y.extend();
                    ((D.Encryptor = D.extend({
                      processBlock: function (T, S) {
                        var O = this._cipher,
                          U = O.blockSize;
                        (C.call(this, T, S, U), O.encryptBlock(T, S), (this._prevBlock = T.slice(S, S + U)));
                      },
                    })),
                      (D.Decryptor = D.extend({
                        processBlock: function (T, S) {
                          var O = this._cipher,
                            U = O.blockSize,
                            N = T.slice(S, S + U);
                          (O.decryptBlock(T, S), C.call(this, T, S, U), (this._prevBlock = N));
                        },
                      })));
                    function C(T, S, O) {
                      var U,
                        N = this._iv;
                      N ? ((U = N), (this._iv = r)) : (U = this._prevBlock);
                      for (var G = 0; G < O; G++) T[S + G] ^= U[G];
                    }
                    return D;
                  })()),
                  A = (n.pad = {}),
                  u = (A.Pkcs7 = {
                    pad: function (D, C) {
                      for (
                        var T = C * 4, S = T - (D.sigBytes % T), O = (S << 24) | (S << 16) | (S << 8) | S, U = [], N = 0;
                        N < S;
                        N += 4
                      )
                        U.push(O);
                      var G = o.create(U, S);
                      D.concat(G);
                    },
                    unpad: function (D) {
                      var C = D.words[(D.sigBytes - 1) >>> 2] & 255;
                      D.sigBytes -= C;
                    },
                  });
                s.BlockCipher = l.extend({
                  cfg: l.cfg.extend({mode: p, padding: u}),
                  reset: function () {
                    var D;
                    l.reset.call(this);
                    var C = this.cfg,
                      T = C.iv,
                      S = C.mode;
                    (this._xformMode == this._ENC_XFORM_MODE
                      ? (D = S.createEncryptor)
                      : ((D = S.createDecryptor), (this._minBufferSize = 1)),
                      this._mode && this._mode.__creator == D
                        ? this._mode.init(this, T && T.words)
                        : ((this._mode = D.call(S, this, T && T.words)), (this._mode.__creator = D)));
                  },
                  _doProcessBlock: function (D, C) {
                    this._mode.processBlock(D, C);
                  },
                  _doFinalize: function () {
                    var D,
                      C = this.cfg.padding;
                    return (
                      this._xformMode == this._ENC_XFORM_MODE
                        ? (C.pad(this._data, this.blockSize), (D = this._process(!0)))
                        : ((D = this._process(!0)), C.unpad(D)),
                      D
                    );
                  },
                  blockSize: 128 / 32,
                });
                var v = (s.CipherParams = a.extend({
                    init: function (D) {
                      this.mixIn(D);
                    },
                    toString: function (D) {
                      return (D || this.formatter).stringify(this);
                    },
                  })),
                  E = (n.format = {}),
                  m = (E.OpenSSL = {
                    stringify: function (D) {
                      var C,
                        T = D.ciphertext,
                        S = D.salt;
                      return (S ? (C = o.create([1398893684, 1701076831]).concat(S).concat(T)) : (C = T), C.toString(f));
                    },
                    parse: function (D) {
                      var C,
                        T = f.parse(D),
                        S = T.words;
                      return (
                        S[0] == 1398893684 &&
                          S[1] == 1701076831 &&
                          ((C = o.create(S.slice(2, 4))), S.splice(0, 4), (T.sigBytes -= 16)),
                        v.create({ciphertext: T, salt: C})
                      );
                    },
                  }),
                  B = (s.SerializableCipher = a.extend({
                    cfg: a.extend({format: m}),
                    encrypt: function (D, C, T, S) {
                      S = this.cfg.extend(S);
                      var O = D.createEncryptor(T, S),
                        U = O.finalize(C),
                        N = O.cfg;
                      return v.create({
                        ciphertext: U,
                        key: T,
                        iv: N.iv,
                        algorithm: D,
                        mode: N.mode,
                        padding: N.padding,
                        blockSize: D.blockSize,
                        formatter: S.format,
                      });
                    },
                    decrypt: function (D, C, T, S) {
                      ((S = this.cfg.extend(S)), (C = this._parse(C, S.format)));
                      var O = D.createDecryptor(T, S).finalize(C.ciphertext);
                      return O;
                    },
                    _parse: function (D, C) {
                      return typeof D == "string" ? C.parse(D, this) : D;
                    },
                  })),
                  w = (n.kdf = {}),
                  b = (w.OpenSSL = {
                    execute: function (D, C, T, S, O) {
                      if ((S || (S = o.random(64 / 8)), O)) var U = h.create({keySize: C + T, hasher: O}).compute(D, S);
                      else var U = h.create({keySize: C + T}).compute(D, S);
                      var N = o.create(U.words.slice(C), T * 4);
                      return ((U.sigBytes = C * 4), v.create({key: U, iv: N, salt: S}));
                    },
                  }),
                  I = (s.PasswordBasedCipher = B.extend({
                    cfg: B.cfg.extend({kdf: b}),
                    encrypt: function (D, C, T, S) {
                      S = this.cfg.extend(S);
                      var O = S.kdf.execute(T, D.keySize, D.ivSize, S.salt, S.hasher);
                      S.iv = O.iv;
                      var U = B.encrypt.call(this, D, C, O.key, S);
                      return (U.mixIn(O), U);
                    },
                    decrypt: function (D, C, T, S) {
                      ((S = this.cfg.extend(S)), (C = this._parse(C, S.format)));
                      var O = S.kdf.execute(T, D.keySize, D.ivSize, C.salt, S.hasher);
                      S.iv = O.iv;
                      var U = B.decrypt.call(this, D, C, O.key, S);
                      return U;
                    },
                  }));
              })();
          });
        })(Ct)),
      Ct.exports
    );
  }
  var mt = {exports: {}},
    wn = mt.exports,
    sr;
  function bn() {
    return (
      sr ||
        ((sr = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), Q());
          })(wn, function (e) {
            return (
              (e.mode.CFB = (function () {
                var r = e.lib.BlockCipherMode.extend();
                ((r.Encryptor = r.extend({
                  processBlock: function (s, a) {
                    var o = this._cipher,
                      x = o.blockSize;
                    (n.call(this, s, a, x, o), (this._prevBlock = s.slice(a, a + x)));
                  },
                })),
                  (r.Decryptor = r.extend({
                    processBlock: function (s, a) {
                      var o = this._cipher,
                        x = o.blockSize,
                        c = s.slice(a, a + x);
                      (n.call(this, s, a, x, o), (this._prevBlock = c));
                    },
                  })));
                function n(s, a, o, x) {
                  var c,
                    f = this._iv;
                  (f ? ((c = f.slice(0)), (this._iv = void 0)) : (c = this._prevBlock), x.encryptBlock(c, 0));
                  for (var g = 0; g < o; g++) s[a + g] ^= c[g];
                }
                return r;
              })()),
              e.mode.CFB
            );
          });
        })(mt)),
      mt.exports
    );
  }
  var wt = {exports: {}},
    _n = wt.exports,
    or;
  function Fn() {
    return (
      or ||
        ((or = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), Q());
          })(_n, function (e) {
            return (
              (e.mode.CTR = (function () {
                var r = e.lib.BlockCipherMode.extend(),
                  n = (r.Encryptor = r.extend({
                    processBlock: function (s, a) {
                      var o = this._cipher,
                        x = o.blockSize,
                        c = this._iv,
                        f = this._counter;
                      c && ((f = this._counter = c.slice(0)), (this._iv = void 0));
                      var g = f.slice(0);
                      (o.encryptBlock(g, 0), (f[x - 1] = (f[x - 1] + 1) | 0));
                      for (var h = 0; h < x; h++) s[a + h] ^= g[h];
                    },
                  }));
                return ((r.Decryptor = n), r);
              })()),
              e.mode.CTR
            );
          });
        })(wt)),
      wt.exports
    );
  }
  var bt = {exports: {}},
    Sn = bt.exports,
    ar;
  function Tn() {
    return (
      ar ||
        ((ar = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), Q());
          })(Sn, function (e) {
            /** @preserve
             * Counter block mode compatible with  Dr Brian Gladman fileenc.c
             * derived from CryptoJS.mode.CTR
             * Jan Hruby jhruby.web@gmail.com
             */ return (
              (e.mode.CTRGladman = (function () {
                var r = e.lib.BlockCipherMode.extend();
                function n(o) {
                  if (((o >> 24) & 255) === 255) {
                    var x = (o >> 16) & 255,
                      c = (o >> 8) & 255,
                      f = o & 255;
                    (x === 255 ? ((x = 0), c === 255 ? ((c = 0), f === 255 ? (f = 0) : ++f) : ++c) : ++x,
                      (o = 0),
                      (o += x << 16),
                      (o += c << 8),
                      (o += f));
                  } else o += 1 << 24;
                  return o;
                }
                function s(o) {
                  return ((o[0] = n(o[0])) === 0 && (o[1] = n(o[1])), o);
                }
                var a = (r.Encryptor = r.extend({
                  processBlock: function (o, x) {
                    var c = this._cipher,
                      f = c.blockSize,
                      g = this._iv,
                      h = this._counter;
                    (g && ((h = this._counter = g.slice(0)), (this._iv = void 0)), s(h));
                    var l = h.slice(0);
                    c.encryptBlock(l, 0);
                    for (var d = 0; d < f; d++) o[x + d] ^= l[d];
                  },
                }));
                return ((r.Decryptor = a), r);
              })()),
              e.mode.CTRGladman
            );
          });
        })(bt)),
      bt.exports
    );
  }
  var _t = {exports: {}},
    kn = _t.exports,
    cr;
  function Rn() {
    return (
      cr ||
        ((cr = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), Q());
          })(kn, function (e) {
            return (
              (e.mode.OFB = (function () {
                var r = e.lib.BlockCipherMode.extend(),
                  n = (r.Encryptor = r.extend({
                    processBlock: function (s, a) {
                      var o = this._cipher,
                        x = o.blockSize,
                        c = this._iv,
                        f = this._keystream;
                      (c && ((f = this._keystream = c.slice(0)), (this._iv = void 0)), o.encryptBlock(f, 0));
                      for (var g = 0; g < x; g++) s[a + g] ^= f[g];
                    },
                  }));
                return ((r.Decryptor = n), r);
              })()),
              e.mode.OFB
            );
          });
        })(_t)),
      _t.exports
    );
  }
  var Ft = {exports: {}},
    In = Ft.exports,
    xr;
  function Pn() {
    return (
      xr ||
        ((xr = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), Q());
          })(In, function (e) {
            return (
              (e.mode.ECB = (function () {
                var r = e.lib.BlockCipherMode.extend();
                return (
                  (r.Encryptor = r.extend({
                    processBlock: function (n, s) {
                      this._cipher.encryptBlock(n, s);
                    },
                  })),
                  (r.Decryptor = r.extend({
                    processBlock: function (n, s) {
                      this._cipher.decryptBlock(n, s);
                    },
                  })),
                  r
                );
              })()),
              e.mode.ECB
            );
          });
        })(Ft)),
      Ft.exports
    );
  }
  var St = {exports: {}},
    On = St.exports,
    fr;
  function Hn() {
    return (
      fr ||
        ((fr = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), Q());
          })(On, function (e) {
            return (
              (e.pad.AnsiX923 = {
                pad: function (r, n) {
                  var s = r.sigBytes,
                    a = n * 4,
                    o = a - (s % a),
                    x = s + o - 1;
                  (r.clamp(), (r.words[x >>> 2] |= o << (24 - (x % 4) * 8)), (r.sigBytes += o));
                },
                unpad: function (r) {
                  var n = r.words[(r.sigBytes - 1) >>> 2] & 255;
                  r.sigBytes -= n;
                },
              }),
              e.pad.Ansix923
            );
          });
        })(St)),
      St.exports
    );
  }
  var Tt = {exports: {}},
    Un = Tt.exports,
    hr;
  function Ln() {
    return (
      hr ||
        ((hr = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), Q());
          })(Un, function (e) {
            return (
              (e.pad.Iso10126 = {
                pad: function (r, n) {
                  var s = n * 4,
                    a = s - (r.sigBytes % s);
                  r.concat(e.lib.WordArray.random(a - 1)).concat(e.lib.WordArray.create([a << 24], 1));
                },
                unpad: function (r) {
                  var n = r.words[(r.sigBytes - 1) >>> 2] & 255;
                  r.sigBytes -= n;
                },
              }),
              e.pad.Iso10126
            );
          });
        })(Tt)),
      Tt.exports
    );
  }
  var kt = {exports: {}},
    Nn = kt.exports,
    ur;
  function Kn() {
    return (
      ur ||
        ((ur = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), Q());
          })(Nn, function (e) {
            return (
              (e.pad.Iso97971 = {
                pad: function (r, n) {
                  (r.concat(e.lib.WordArray.create([2147483648], 1)), e.pad.ZeroPadding.pad(r, n));
                },
                unpad: function (r) {
                  (e.pad.ZeroPadding.unpad(r), r.sigBytes--);
                },
              }),
              e.pad.Iso97971
            );
          });
        })(kt)),
      kt.exports
    );
  }
  var Rt = {exports: {}},
    qn = Rt.exports,
    lr;
  function zn() {
    return (
      lr ||
        ((lr = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), Q());
          })(qn, function (e) {
            return (
              (e.pad.ZeroPadding = {
                pad: function (r, n) {
                  var s = n * 4;
                  (r.clamp(), (r.sigBytes += s - (r.sigBytes % s || s)));
                },
                unpad: function (r) {
                  for (var n = r.words, s = r.sigBytes - 1, s = r.sigBytes - 1; s >= 0; s--)
                    if ((n[s >>> 2] >>> (24 - (s % 4) * 8)) & 255) {
                      r.sigBytes = s + 1;
                      break;
                    }
                },
              }),
              e.pad.ZeroPadding
            );
          });
        })(Rt)),
      Rt.exports
    );
  }
  var It = {exports: {}},
    Vn = It.exports,
    dr;
  function Mn() {
    return (
      dr ||
        ((dr = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), Q());
          })(Vn, function (e) {
            return ((e.pad.NoPadding = {pad: function () {}, unpad: function () {}}), e.pad.NoPadding);
          });
        })(It)),
      It.exports
    );
  }
  var Pt = {exports: {}},
    $n = Pt.exports,
    vr;
  function jn() {
    return (
      vr ||
        ((vr = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), Q());
          })($n, function (e) {
            return (
              (function (r) {
                var n = e,
                  s = n.lib,
                  a = s.CipherParams,
                  o = n.enc,
                  x = o.Hex,
                  c = n.format;
                c.Hex = {
                  stringify: function (f) {
                    return f.ciphertext.toString(x);
                  },
                  parse: function (f) {
                    var g = x.parse(f);
                    return a.create({ciphertext: g});
                  },
                };
              })(),
              e.format.Hex
            );
          });
        })(Pt)),
      Pt.exports
    );
  }
  var Ot = {exports: {}},
    Wn = Ot.exports,
    pr;
  function Gn() {
    return (
      pr ||
        ((pr = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), A0(), C0(), g0(), Q());
          })(Wn, function (e) {
            return (
              (function () {
                var r = e,
                  n = r.lib,
                  s = n.BlockCipher,
                  a = r.algo,
                  o = [],
                  x = [],
                  c = [],
                  f = [],
                  g = [],
                  h = [],
                  l = [],
                  d = [],
                  y = [],
                  p = [];
                (function () {
                  for (var v = [], E = 0; E < 256; E++) E < 128 ? (v[E] = E << 1) : (v[E] = (E << 1) ^ 283);
                  for (var m = 0, B = 0, E = 0; E < 256; E++) {
                    var w = B ^ (B << 1) ^ (B << 2) ^ (B << 3) ^ (B << 4);
                    ((w = (w >>> 8) ^ (w & 255) ^ 99), (o[m] = w), (x[w] = m));
                    var b = v[m],
                      I = v[b],
                      D = v[I],
                      C = (v[w] * 257) ^ (w * 16843008);
                    ((c[m] = (C << 24) | (C >>> 8)),
                      (f[m] = (C << 16) | (C >>> 16)),
                      (g[m] = (C << 8) | (C >>> 24)),
                      (h[m] = C));
                    var C = (D * 16843009) ^ (I * 65537) ^ (b * 257) ^ (m * 16843008);
                    ((l[w] = (C << 24) | (C >>> 8)),
                      (d[w] = (C << 16) | (C >>> 16)),
                      (y[w] = (C << 8) | (C >>> 24)),
                      (p[w] = C),
                      m ? ((m = b ^ v[v[v[D ^ b]]]), (B ^= v[v[B]])) : (m = B = 1));
                  }
                })();
                var A = [0, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54],
                  u = (a.AES = s.extend({
                    _doReset: function () {
                      var v;
                      if (!(this._nRounds && this._keyPriorReset === this._key)) {
                        for (
                          var E = (this._keyPriorReset = this._key),
                            m = E.words,
                            B = E.sigBytes / 4,
                            w = (this._nRounds = B + 6),
                            b = (w + 1) * 4,
                            I = (this._keySchedule = []),
                            D = 0;
                          D < b;
                          D++
                        )
                          D < B
                            ? (I[D] = m[D])
                            : ((v = I[D - 1]),
                              D % B
                                ? B > 6 &&
                                  D % B == 4 &&
                                  (v =
                                    (o[v >>> 24] << 24) |
                                    (o[(v >>> 16) & 255] << 16) |
                                    (o[(v >>> 8) & 255] << 8) |
                                    o[v & 255])
                                : ((v = (v << 8) | (v >>> 24)),
                                  (v =
                                    (o[v >>> 24] << 24) |
                                    (o[(v >>> 16) & 255] << 16) |
                                    (o[(v >>> 8) & 255] << 8) |
                                    o[v & 255]),
                                  (v ^= A[(D / B) | 0] << 24)),
                              (I[D] = I[D - B] ^ v));
                        for (var C = (this._invKeySchedule = []), T = 0; T < b; T++) {
                          var D = b - T;
                          if (T % 4) var v = I[D];
                          else var v = I[D - 4];
                          T < 4 || D <= 4
                            ? (C[T] = v)
                            : (C[T] = l[o[v >>> 24]] ^ d[o[(v >>> 16) & 255]] ^ y[o[(v >>> 8) & 255]] ^ p[o[v & 255]]);
                        }
                      }
                    },
                    encryptBlock: function (v, E) {
                      this._doCryptBlock(v, E, this._keySchedule, c, f, g, h, o);
                    },
                    decryptBlock: function (v, E) {
                      var m = v[E + 1];
                      ((v[E + 1] = v[E + 3]),
                        (v[E + 3] = m),
                        this._doCryptBlock(v, E, this._invKeySchedule, l, d, y, p, x));
                      var m = v[E + 1];
                      ((v[E + 1] = v[E + 3]), (v[E + 3] = m));
                    },
                    _doCryptBlock: function (v, E, m, B, w, b, I, D) {
                      for (
                        var C = this._nRounds,
                          T = v[E] ^ m[0],
                          S = v[E + 1] ^ m[1],
                          O = v[E + 2] ^ m[2],
                          U = v[E + 3] ^ m[3],
                          N = 4,
                          G = 1;
                        G < C;
                        G++
                      ) {
                        var M = B[T >>> 24] ^ w[(S >>> 16) & 255] ^ b[(O >>> 8) & 255] ^ I[U & 255] ^ m[N++],
                          j = B[S >>> 24] ^ w[(O >>> 16) & 255] ^ b[(U >>> 8) & 255] ^ I[T & 255] ^ m[N++],
                          $ = B[O >>> 24] ^ w[(U >>> 16) & 255] ^ b[(T >>> 8) & 255] ^ I[S & 255] ^ m[N++],
                          F = B[U >>> 24] ^ w[(T >>> 16) & 255] ^ b[(S >>> 8) & 255] ^ I[O & 255] ^ m[N++];
                        ((T = M), (S = j), (O = $), (U = F));
                      }
                      var M =
                          ((D[T >>> 24] << 24) | (D[(S >>> 16) & 255] << 16) | (D[(O >>> 8) & 255] << 8) | D[U & 255]) ^
                          m[N++],
                        j =
                          ((D[S >>> 24] << 24) | (D[(O >>> 16) & 255] << 16) | (D[(U >>> 8) & 255] << 8) | D[T & 255]) ^
                          m[N++],
                        $ =
                          ((D[O >>> 24] << 24) | (D[(U >>> 16) & 255] << 16) | (D[(T >>> 8) & 255] << 8) | D[S & 255]) ^
                          m[N++],
                        F =
                          ((D[U >>> 24] << 24) | (D[(T >>> 16) & 255] << 16) | (D[(S >>> 8) & 255] << 8) | D[O & 255]) ^
                          m[N++];
                      ((v[E] = M), (v[E + 1] = j), (v[E + 2] = $), (v[E + 3] = F));
                    },
                    keySize: 256 / 32,
                  }));
                r.AES = s._createHelper(u);
              })(),
              e.AES
            );
          });
        })(Ot)),
      Ot.exports
    );
  }
  var Ht = {exports: {}},
    Zn = Ht.exports,
    gr;
  function Xn() {
    return (
      gr ||
        ((gr = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), A0(), C0(), g0(), Q());
          })(Zn, function (e) {
            return (
              (function () {
                var r = e,
                  n = r.lib,
                  s = n.WordArray,
                  a = n.BlockCipher,
                  o = r.algo,
                  x = [
                    57, 49, 41, 33, 25, 17, 9, 1, 58, 50, 42, 34, 26, 18, 10, 2, 59, 51, 43, 35, 27, 19, 11, 3, 60, 52, 44,
                    36, 63, 55, 47, 39, 31, 23, 15, 7, 62, 54, 46, 38, 30, 22, 14, 6, 61, 53, 45, 37, 29, 21, 13, 5, 28, 20,
                    12, 4,
                  ],
                  c = [
                    14, 17, 11, 24, 1, 5, 3, 28, 15, 6, 21, 10, 23, 19, 12, 4, 26, 8, 16, 7, 27, 20, 13, 2, 41, 52, 31, 37,
                    47, 55, 30, 40, 51, 45, 33, 48, 44, 49, 39, 56, 34, 53, 46, 42, 50, 36, 29, 32,
                  ],
                  f = [1, 2, 4, 6, 8, 10, 12, 14, 15, 17, 19, 21, 23, 25, 27, 28],
                  g = [
                    {
                      0: 8421888,
                      268435456: 32768,
                      536870912: 8421378,
                      805306368: 2,
                      1073741824: 512,
                      1342177280: 8421890,
                      1610612736: 8389122,
                      1879048192: 8388608,
                      2147483648: 514,
                      2415919104: 8389120,
                      2684354560: 33280,
                      2952790016: 8421376,
                      3221225472: 32770,
                      3489660928: 8388610,
                      3758096384: 0,
                      4026531840: 33282,
                      134217728: 0,
                      402653184: 8421890,
                      671088640: 33282,
                      939524096: 32768,
                      1207959552: 8421888,
                      1476395008: 512,
                      1744830464: 8421378,
                      2013265920: 2,
                      2281701376: 8389120,
                      2550136832: 33280,
                      2818572288: 8421376,
                      3087007744: 8389122,
                      3355443200: 8388610,
                      3623878656: 32770,
                      3892314112: 514,
                      4160749568: 8388608,
                      1: 32768,
                      268435457: 2,
                      536870913: 8421888,
                      805306369: 8388608,
                      1073741825: 8421378,
                      1342177281: 33280,
                      1610612737: 512,
                      1879048193: 8389122,
                      2147483649: 8421890,
                      2415919105: 8421376,
                      2684354561: 8388610,
                      2952790017: 33282,
                      3221225473: 514,
                      3489660929: 8389120,
                      3758096385: 32770,
                      4026531841: 0,
                      134217729: 8421890,
                      402653185: 8421376,
                      671088641: 8388608,
                      939524097: 512,
                      1207959553: 32768,
                      1476395009: 8388610,
                      1744830465: 2,
                      2013265921: 33282,
                      2281701377: 32770,
                      2550136833: 8389122,
                      2818572289: 514,
                      3087007745: 8421888,
                      3355443201: 8389120,
                      3623878657: 0,
                      3892314113: 33280,
                      4160749569: 8421378,
                    },
                    {
                      0: 1074282512,
                      16777216: 16384,
                      33554432: 524288,
                      50331648: 1074266128,
                      67108864: 1073741840,
                      83886080: 1074282496,
                      100663296: 1073758208,
                      117440512: 16,
                      134217728: 540672,
                      150994944: 1073758224,
                      167772160: 1073741824,
                      184549376: 540688,
                      201326592: 524304,
                      218103808: 0,
                      234881024: 16400,
                      251658240: 1074266112,
                      8388608: 1073758208,
                      25165824: 540688,
                      41943040: 16,
                      58720256: 1073758224,
                      75497472: 1074282512,
                      92274688: 1073741824,
                      109051904: 524288,
                      125829120: 1074266128,
                      142606336: 524304,
                      159383552: 0,
                      176160768: 16384,
                      192937984: 1074266112,
                      209715200: 1073741840,
                      226492416: 540672,
                      243269632: 1074282496,
                      260046848: 16400,
                      268435456: 0,
                      285212672: 1074266128,
                      301989888: 1073758224,
                      318767104: 1074282496,
                      335544320: 1074266112,
                      352321536: 16,
                      369098752: 540688,
                      385875968: 16384,
                      402653184: 16400,
                      419430400: 524288,
                      436207616: 524304,
                      452984832: 1073741840,
                      469762048: 540672,
                      486539264: 1073758208,
                      503316480: 1073741824,
                      520093696: 1074282512,
                      276824064: 540688,
                      293601280: 524288,
                      310378496: 1074266112,
                      327155712: 16384,
                      343932928: 1073758208,
                      360710144: 1074282512,
                      377487360: 16,
                      394264576: 1073741824,
                      411041792: 1074282496,
                      427819008: 1073741840,
                      444596224: 1073758224,
                      461373440: 524304,
                      478150656: 0,
                      494927872: 16400,
                      511705088: 1074266128,
                      528482304: 540672,
                    },
                    {
                      0: 260,
                      1048576: 0,
                      2097152: 67109120,
                      3145728: 65796,
                      4194304: 65540,
                      5242880: 67108868,
                      6291456: 67174660,
                      7340032: 67174400,
                      8388608: 67108864,
                      9437184: 67174656,
                      10485760: 65792,
                      11534336: 67174404,
                      12582912: 67109124,
                      13631488: 65536,
                      14680064: 4,
                      15728640: 256,
                      524288: 67174656,
                      1572864: 67174404,
                      2621440: 0,
                      3670016: 67109120,
                      4718592: 67108868,
                      5767168: 65536,
                      6815744: 65540,
                      7864320: 260,
                      8912896: 4,
                      9961472: 256,
                      11010048: 67174400,
                      12058624: 65796,
                      13107200: 65792,
                      14155776: 67109124,
                      15204352: 67174660,
                      16252928: 67108864,
                      16777216: 67174656,
                      17825792: 65540,
                      18874368: 65536,
                      19922944: 67109120,
                      20971520: 256,
                      22020096: 67174660,
                      23068672: 67108868,
                      24117248: 0,
                      25165824: 67109124,
                      26214400: 67108864,
                      27262976: 4,
                      28311552: 65792,
                      29360128: 67174400,
                      30408704: 260,
                      31457280: 65796,
                      32505856: 67174404,
                      17301504: 67108864,
                      18350080: 260,
                      19398656: 67174656,
                      20447232: 0,
                      21495808: 65540,
                      22544384: 67109120,
                      23592960: 256,
                      24641536: 67174404,
                      25690112: 65536,
                      26738688: 67174660,
                      27787264: 65796,
                      28835840: 67108868,
                      29884416: 67109124,
                      30932992: 67174400,
                      31981568: 4,
                      33030144: 65792,
                    },
                    {
                      0: 2151682048,
                      65536: 2147487808,
                      131072: 4198464,
                      196608: 2151677952,
                      262144: 0,
                      327680: 4198400,
                      393216: 2147483712,
                      458752: 4194368,
                      524288: 2147483648,
                      589824: 4194304,
                      655360: 64,
                      720896: 2147487744,
                      786432: 2151678016,
                      851968: 4160,
                      917504: 4096,
                      983040: 2151682112,
                      32768: 2147487808,
                      98304: 64,
                      163840: 2151678016,
                      229376: 2147487744,
                      294912: 4198400,
                      360448: 2151682112,
                      425984: 0,
                      491520: 2151677952,
                      557056: 4096,
                      622592: 2151682048,
                      688128: 4194304,
                      753664: 4160,
                      819200: 2147483648,
                      884736: 4194368,
                      950272: 4198464,
                      1015808: 2147483712,
                      1048576: 4194368,
                      1114112: 4198400,
                      1179648: 2147483712,
                      1245184: 0,
                      1310720: 4160,
                      1376256: 2151678016,
                      1441792: 2151682048,
                      1507328: 2147487808,
                      1572864: 2151682112,
                      1638400: 2147483648,
                      1703936: 2151677952,
                      1769472: 4198464,
                      1835008: 2147487744,
                      1900544: 4194304,
                      1966080: 64,
                      2031616: 4096,
                      1081344: 2151677952,
                      1146880: 2151682112,
                      1212416: 0,
                      1277952: 4198400,
                      1343488: 4194368,
                      1409024: 2147483648,
                      1474560: 2147487808,
                      1540096: 64,
                      1605632: 2147483712,
                      1671168: 4096,
                      1736704: 2147487744,
                      1802240: 2151678016,
                      1867776: 4160,
                      1933312: 2151682048,
                      1998848: 4194304,
                      2064384: 4198464,
                    },
                    {
                      0: 128,
                      4096: 17039360,
                      8192: 262144,
                      12288: 536870912,
                      16384: 537133184,
                      20480: 16777344,
                      24576: 553648256,
                      28672: 262272,
                      32768: 16777216,
                      36864: 537133056,
                      40960: 536871040,
                      45056: 553910400,
                      49152: 553910272,
                      53248: 0,
                      57344: 17039488,
                      61440: 553648128,
                      2048: 17039488,
                      6144: 553648256,
                      10240: 128,
                      14336: 17039360,
                      18432: 262144,
                      22528: 537133184,
                      26624: 553910272,
                      30720: 536870912,
                      34816: 537133056,
                      38912: 0,
                      43008: 553910400,
                      47104: 16777344,
                      51200: 536871040,
                      55296: 553648128,
                      59392: 16777216,
                      63488: 262272,
                      65536: 262144,
                      69632: 128,
                      73728: 536870912,
                      77824: 553648256,
                      81920: 16777344,
                      86016: 553910272,
                      90112: 537133184,
                      94208: 16777216,
                      98304: 553910400,
                      102400: 553648128,
                      106496: 17039360,
                      110592: 537133056,
                      114688: 262272,
                      118784: 536871040,
                      122880: 0,
                      126976: 17039488,
                      67584: 553648256,
                      71680: 16777216,
                      75776: 17039360,
                      79872: 537133184,
                      83968: 536870912,
                      88064: 17039488,
                      92160: 128,
                      96256: 553910272,
                      100352: 262272,
                      104448: 553910400,
                      108544: 0,
                      112640: 553648128,
                      116736: 16777344,
                      120832: 262144,
                      124928: 537133056,
                      129024: 536871040,
                    },
                    {
                      0: 268435464,
                      256: 8192,
                      512: 270532608,
                      768: 270540808,
                      1024: 268443648,
                      1280: 2097152,
                      1536: 2097160,
                      1792: 268435456,
                      2048: 0,
                      2304: 268443656,
                      2560: 2105344,
                      2816: 8,
                      3072: 270532616,
                      3328: 2105352,
                      3584: 8200,
                      3840: 270540800,
                      128: 270532608,
                      384: 270540808,
                      640: 8,
                      896: 2097152,
                      1152: 2105352,
                      1408: 268435464,
                      1664: 268443648,
                      1920: 8200,
                      2176: 2097160,
                      2432: 8192,
                      2688: 268443656,
                      2944: 270532616,
                      3200: 0,
                      3456: 270540800,
                      3712: 2105344,
                      3968: 268435456,
                      4096: 268443648,
                      4352: 270532616,
                      4608: 270540808,
                      4864: 8200,
                      5120: 2097152,
                      5376: 268435456,
                      5632: 268435464,
                      5888: 2105344,
                      6144: 2105352,
                      6400: 0,
                      6656: 8,
                      6912: 270532608,
                      7168: 8192,
                      7424: 268443656,
                      7680: 270540800,
                      7936: 2097160,
                      4224: 8,
                      4480: 2105344,
                      4736: 2097152,
                      4992: 268435464,
                      5248: 268443648,
                      5504: 8200,
                      5760: 270540808,
                      6016: 270532608,
                      6272: 270540800,
                      6528: 270532616,
                      6784: 8192,
                      7040: 2105352,
                      7296: 2097160,
                      7552: 0,
                      7808: 268435456,
                      8064: 268443656,
                    },
                    {
                      0: 1048576,
                      16: 33555457,
                      32: 1024,
                      48: 1049601,
                      64: 34604033,
                      80: 0,
                      96: 1,
                      112: 34603009,
                      128: 33555456,
                      144: 1048577,
                      160: 33554433,
                      176: 34604032,
                      192: 34603008,
                      208: 1025,
                      224: 1049600,
                      240: 33554432,
                      8: 34603009,
                      24: 0,
                      40: 33555457,
                      56: 34604032,
                      72: 1048576,
                      88: 33554433,
                      104: 33554432,
                      120: 1025,
                      136: 1049601,
                      152: 33555456,
                      168: 34603008,
                      184: 1048577,
                      200: 1024,
                      216: 34604033,
                      232: 1,
                      248: 1049600,
                      256: 33554432,
                      272: 1048576,
                      288: 33555457,
                      304: 34603009,
                      320: 1048577,
                      336: 33555456,
                      352: 34604032,
                      368: 1049601,
                      384: 1025,
                      400: 34604033,
                      416: 1049600,
                      432: 1,
                      448: 0,
                      464: 34603008,
                      480: 33554433,
                      496: 1024,
                      264: 1049600,
                      280: 33555457,
                      296: 34603009,
                      312: 1,
                      328: 33554432,
                      344: 1048576,
                      360: 1025,
                      376: 34604032,
                      392: 33554433,
                      408: 34603008,
                      424: 0,
                      440: 34604033,
                      456: 1049601,
                      472: 1024,
                      488: 33555456,
                      504: 1048577,
                    },
                    {
                      0: 134219808,
                      1: 131072,
                      2: 134217728,
                      3: 32,
                      4: 131104,
                      5: 134350880,
                      6: 134350848,
                      7: 2048,
                      8: 134348800,
                      9: 134219776,
                      10: 133120,
                      11: 134348832,
                      12: 2080,
                      13: 0,
                      14: 134217760,
                      15: 133152,
                      2147483648: 2048,
                      2147483649: 134350880,
                      2147483650: 134219808,
                      2147483651: 134217728,
                      2147483652: 134348800,
                      2147483653: 133120,
                      2147483654: 133152,
                      2147483655: 32,
                      2147483656: 134217760,
                      2147483657: 2080,
                      2147483658: 131104,
                      2147483659: 134350848,
                      2147483660: 0,
                      2147483661: 134348832,
                      2147483662: 134219776,
                      2147483663: 131072,
                      16: 133152,
                      17: 134350848,
                      18: 32,
                      19: 2048,
                      20: 134219776,
                      21: 134217760,
                      22: 134348832,
                      23: 131072,
                      24: 0,
                      25: 131104,
                      26: 134348800,
                      27: 134219808,
                      28: 134350880,
                      29: 133120,
                      30: 2080,
                      31: 134217728,
                      2147483664: 131072,
                      2147483665: 2048,
                      2147483666: 134348832,
                      2147483667: 133152,
                      2147483668: 32,
                      2147483669: 134348800,
                      2147483670: 134217728,
                      2147483671: 134219808,
                      2147483672: 134350880,
                      2147483673: 134217760,
                      2147483674: 134219776,
                      2147483675: 0,
                      2147483676: 133120,
                      2147483677: 2080,
                      2147483678: 131104,
                      2147483679: 134350848,
                    },
                  ],
                  h = [4160749569, 528482304, 33030144, 2064384, 129024, 8064, 504, 2147483679],
                  l = (o.DES = a.extend({
                    _doReset: function () {
                      for (var A = this._key, u = A.words, v = [], E = 0; E < 56; E++) {
                        var m = x[E] - 1;
                        v[E] = (u[m >>> 5] >>> (31 - (m % 32))) & 1;
                      }
                      for (var B = (this._subKeys = []), w = 0; w < 16; w++) {
                        for (var b = (B[w] = []), I = f[w], E = 0; E < 24; E++)
                          ((b[(E / 6) | 0] |= v[(c[E] - 1 + I) % 28] << (31 - (E % 6))),
                            (b[4 + ((E / 6) | 0)] |= v[28 + ((c[E + 24] - 1 + I) % 28)] << (31 - (E % 6))));
                        b[0] = (b[0] << 1) | (b[0] >>> 31);
                        for (var E = 1; E < 7; E++) b[E] = b[E] >>> ((E - 1) * 4 + 3);
                        b[7] = (b[7] << 5) | (b[7] >>> 27);
                      }
                      for (var D = (this._invSubKeys = []), E = 0; E < 16; E++) D[E] = B[15 - E];
                    },
                    encryptBlock: function (A, u) {
                      this._doCryptBlock(A, u, this._subKeys);
                    },
                    decryptBlock: function (A, u) {
                      this._doCryptBlock(A, u, this._invSubKeys);
                    },
                    _doCryptBlock: function (A, u, v) {
                      ((this._lBlock = A[u]),
                        (this._rBlock = A[u + 1]),
                        d.call(this, 4, 252645135),
                        d.call(this, 16, 65535),
                        y.call(this, 2, 858993459),
                        y.call(this, 8, 16711935),
                        d.call(this, 1, 1431655765));
                      for (var E = 0; E < 16; E++) {
                        for (var m = v[E], B = this._lBlock, w = this._rBlock, b = 0, I = 0; I < 8; I++)
                          b |= g[I][((w ^ m[I]) & h[I]) >>> 0];
                        ((this._lBlock = w), (this._rBlock = B ^ b));
                      }
                      var D = this._lBlock;
                      ((this._lBlock = this._rBlock),
                        (this._rBlock = D),
                        d.call(this, 1, 1431655765),
                        y.call(this, 8, 16711935),
                        y.call(this, 2, 858993459),
                        d.call(this, 16, 65535),
                        d.call(this, 4, 252645135),
                        (A[u] = this._lBlock),
                        (A[u + 1] = this._rBlock));
                    },
                    keySize: 64 / 32,
                    ivSize: 64 / 32,
                    blockSize: 64 / 32,
                  }));
                function d(A, u) {
                  var v = ((this._lBlock >>> A) ^ this._rBlock) & u;
                  ((this._rBlock ^= v), (this._lBlock ^= v << A));
                }
                function y(A, u) {
                  var v = ((this._rBlock >>> A) ^ this._lBlock) & u;
                  ((this._lBlock ^= v), (this._rBlock ^= v << A));
                }
                r.DES = a._createHelper(l);
                var p = (o.TripleDES = a.extend({
                  _doReset: function () {
                    var A = this._key,
                      u = A.words;
                    if (u.length !== 2 && u.length !== 4 && u.length < 6)
                      throw new Error("Invalid key length - 3DES requires the key length to be 64, 128, 192 or >192.");
                    var v = u.slice(0, 2),
                      E = u.length < 4 ? u.slice(0, 2) : u.slice(2, 4),
                      m = u.length < 6 ? u.slice(0, 2) : u.slice(4, 6);
                    ((this._des1 = l.createEncryptor(s.create(v))),
                      (this._des2 = l.createEncryptor(s.create(E))),
                      (this._des3 = l.createEncryptor(s.create(m))));
                  },
                  encryptBlock: function (A, u) {
                    (this._des1.encryptBlock(A, u), this._des2.decryptBlock(A, u), this._des3.encryptBlock(A, u));
                  },
                  decryptBlock: function (A, u) {
                    (this._des3.decryptBlock(A, u), this._des2.encryptBlock(A, u), this._des1.decryptBlock(A, u));
                  },
                  keySize: 192 / 32,
                  ivSize: 64 / 32,
                  blockSize: 64 / 32,
                }));
                r.TripleDES = a._createHelper(p);
              })(),
              e.TripleDES
            );
          });
        })(Ht)),
      Ht.exports
    );
  }
  var Ut = {exports: {}},
    Yn = Ut.exports,
    yr;
  function Qn() {
    return (
      yr ||
        ((yr = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), A0(), C0(), g0(), Q());
          })(Yn, function (e) {
            return (
              (function () {
                var r = e,
                  n = r.lib,
                  s = n.StreamCipher,
                  a = r.algo,
                  o = (a.RC4 = s.extend({
                    _doReset: function () {
                      for (var f = this._key, g = f.words, h = f.sigBytes, l = (this._S = []), d = 0; d < 256; d++)
                        l[d] = d;
                      for (var d = 0, y = 0; d < 256; d++) {
                        var p = d % h,
                          A = (g[p >>> 2] >>> (24 - (p % 4) * 8)) & 255;
                        y = (y + l[d] + A) % 256;
                        var u = l[d];
                        ((l[d] = l[y]), (l[y] = u));
                      }
                      this._i = this._j = 0;
                    },
                    _doProcessBlock: function (f, g) {
                      f[g] ^= x.call(this);
                    },
                    keySize: 256 / 32,
                    ivSize: 0,
                  }));
                function x() {
                  for (var f = this._S, g = this._i, h = this._j, l = 0, d = 0; d < 4; d++) {
                    ((g = (g + 1) % 256), (h = (h + f[g]) % 256));
                    var y = f[g];
                    ((f[g] = f[h]), (f[h] = y), (l |= f[(f[g] + f[h]) % 256] << (24 - d * 8)));
                  }
                  return ((this._i = g), (this._j = h), l);
                }
                r.RC4 = s._createHelper(o);
                var c = (a.RC4Drop = o.extend({
                  cfg: o.cfg.extend({drop: 192}),
                  _doReset: function () {
                    o._doReset.call(this);
                    for (var f = this.cfg.drop; f > 0; f--) x.call(this);
                  },
                }));
                r.RC4Drop = s._createHelper(c);
              })(),
              e.RC4
            );
          });
        })(Ut)),
      Ut.exports
    );
  }
  var Lt = {exports: {}},
    Jn = Lt.exports,
    Er;
  function ts() {
    return (
      Er ||
        ((Er = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), A0(), C0(), g0(), Q());
          })(Jn, function (e) {
            return (
              (function () {
                var r = e,
                  n = r.lib,
                  s = n.StreamCipher,
                  a = r.algo,
                  o = [],
                  x = [],
                  c = [],
                  f = (a.Rabbit = s.extend({
                    _doReset: function () {
                      for (var h = this._key.words, l = this.cfg.iv, d = 0; d < 4; d++)
                        h[d] = (((h[d] << 8) | (h[d] >>> 24)) & 16711935) | (((h[d] << 24) | (h[d] >>> 8)) & 4278255360);
                      var y = (this._X = [
                          h[0],
                          (h[3] << 16) | (h[2] >>> 16),
                          h[1],
                          (h[0] << 16) | (h[3] >>> 16),
                          h[2],
                          (h[1] << 16) | (h[0] >>> 16),
                          h[3],
                          (h[2] << 16) | (h[1] >>> 16),
                        ]),
                        p = (this._C = [
                          (h[2] << 16) | (h[2] >>> 16),
                          (h[0] & 4294901760) | (h[1] & 65535),
                          (h[3] << 16) | (h[3] >>> 16),
                          (h[1] & 4294901760) | (h[2] & 65535),
                          (h[0] << 16) | (h[0] >>> 16),
                          (h[2] & 4294901760) | (h[3] & 65535),
                          (h[1] << 16) | (h[1] >>> 16),
                          (h[3] & 4294901760) | (h[0] & 65535),
                        ]);
                      this._b = 0;
                      for (var d = 0; d < 4; d++) g.call(this);
                      for (var d = 0; d < 8; d++) p[d] ^= y[(d + 4) & 7];
                      if (l) {
                        var A = l.words,
                          u = A[0],
                          v = A[1],
                          E = (((u << 8) | (u >>> 24)) & 16711935) | (((u << 24) | (u >>> 8)) & 4278255360),
                          m = (((v << 8) | (v >>> 24)) & 16711935) | (((v << 24) | (v >>> 8)) & 4278255360),
                          B = (E >>> 16) | (m & 4294901760),
                          w = (m << 16) | (E & 65535);
                        ((p[0] ^= E),
                          (p[1] ^= B),
                          (p[2] ^= m),
                          (p[3] ^= w),
                          (p[4] ^= E),
                          (p[5] ^= B),
                          (p[6] ^= m),
                          (p[7] ^= w));
                        for (var d = 0; d < 4; d++) g.call(this);
                      }
                    },
                    _doProcessBlock: function (h, l) {
                      var d = this._X;
                      (g.call(this),
                        (o[0] = d[0] ^ (d[5] >>> 16) ^ (d[3] << 16)),
                        (o[1] = d[2] ^ (d[7] >>> 16) ^ (d[5] << 16)),
                        (o[2] = d[4] ^ (d[1] >>> 16) ^ (d[7] << 16)),
                        (o[3] = d[6] ^ (d[3] >>> 16) ^ (d[1] << 16)));
                      for (var y = 0; y < 4; y++)
                        ((o[y] = (((o[y] << 8) | (o[y] >>> 24)) & 16711935) | (((o[y] << 24) | (o[y] >>> 8)) & 4278255360)),
                          (h[l + y] ^= o[y]));
                    },
                    blockSize: 128 / 32,
                    ivSize: 64 / 32,
                  }));
                function g() {
                  for (var h = this._X, l = this._C, d = 0; d < 8; d++) x[d] = l[d];
                  ((l[0] = (l[0] + 1295307597 + this._b) | 0),
                    (l[1] = (l[1] + 3545052371 + (l[0] >>> 0 < x[0] >>> 0 ? 1 : 0)) | 0),
                    (l[2] = (l[2] + 886263092 + (l[1] >>> 0 < x[1] >>> 0 ? 1 : 0)) | 0),
                    (l[3] = (l[3] + 1295307597 + (l[2] >>> 0 < x[2] >>> 0 ? 1 : 0)) | 0),
                    (l[4] = (l[4] + 3545052371 + (l[3] >>> 0 < x[3] >>> 0 ? 1 : 0)) | 0),
                    (l[5] = (l[5] + 886263092 + (l[4] >>> 0 < x[4] >>> 0 ? 1 : 0)) | 0),
                    (l[6] = (l[6] + 1295307597 + (l[5] >>> 0 < x[5] >>> 0 ? 1 : 0)) | 0),
                    (l[7] = (l[7] + 3545052371 + (l[6] >>> 0 < x[6] >>> 0 ? 1 : 0)) | 0),
                    (this._b = l[7] >>> 0 < x[7] >>> 0 ? 1 : 0));
                  for (var d = 0; d < 8; d++) {
                    var y = h[d] + l[d],
                      p = y & 65535,
                      A = y >>> 16,
                      u = ((((p * p) >>> 17) + p * A) >>> 15) + A * A,
                      v = (((y & 4294901760) * y) | 0) + (((y & 65535) * y) | 0);
                    c[d] = u ^ v;
                  }
                  ((h[0] = (c[0] + ((c[7] << 16) | (c[7] >>> 16)) + ((c[6] << 16) | (c[6] >>> 16))) | 0),
                    (h[1] = (c[1] + ((c[0] << 8) | (c[0] >>> 24)) + c[7]) | 0),
                    (h[2] = (c[2] + ((c[1] << 16) | (c[1] >>> 16)) + ((c[0] << 16) | (c[0] >>> 16))) | 0),
                    (h[3] = (c[3] + ((c[2] << 8) | (c[2] >>> 24)) + c[1]) | 0),
                    (h[4] = (c[4] + ((c[3] << 16) | (c[3] >>> 16)) + ((c[2] << 16) | (c[2] >>> 16))) | 0),
                    (h[5] = (c[5] + ((c[4] << 8) | (c[4] >>> 24)) + c[3]) | 0),
                    (h[6] = (c[6] + ((c[5] << 16) | (c[5] >>> 16)) + ((c[4] << 16) | (c[4] >>> 16))) | 0),
                    (h[7] = (c[7] + ((c[6] << 8) | (c[6] >>> 24)) + c[5]) | 0));
                }
                r.Rabbit = s._createHelper(f);
              })(),
              e.Rabbit
            );
          });
        })(Lt)),
      Lt.exports
    );
  }
  var Nt = {exports: {}},
    es = Nt.exports,
    Br;
  function rs() {
    return (
      Br ||
        ((Br = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), A0(), C0(), g0(), Q());
          })(es, function (e) {
            return (
              (function () {
                var r = e,
                  n = r.lib,
                  s = n.StreamCipher,
                  a = r.algo,
                  o = [],
                  x = [],
                  c = [],
                  f = (a.RabbitLegacy = s.extend({
                    _doReset: function () {
                      var h = this._key.words,
                        l = this.cfg.iv,
                        d = (this._X = [
                          h[0],
                          (h[3] << 16) | (h[2] >>> 16),
                          h[1],
                          (h[0] << 16) | (h[3] >>> 16),
                          h[2],
                          (h[1] << 16) | (h[0] >>> 16),
                          h[3],
                          (h[2] << 16) | (h[1] >>> 16),
                        ]),
                        y = (this._C = [
                          (h[2] << 16) | (h[2] >>> 16),
                          (h[0] & 4294901760) | (h[1] & 65535),
                          (h[3] << 16) | (h[3] >>> 16),
                          (h[1] & 4294901760) | (h[2] & 65535),
                          (h[0] << 16) | (h[0] >>> 16),
                          (h[2] & 4294901760) | (h[3] & 65535),
                          (h[1] << 16) | (h[1] >>> 16),
                          (h[3] & 4294901760) | (h[0] & 65535),
                        ]);
                      this._b = 0;
                      for (var p = 0; p < 4; p++) g.call(this);
                      for (var p = 0; p < 8; p++) y[p] ^= d[(p + 4) & 7];
                      if (l) {
                        var A = l.words,
                          u = A[0],
                          v = A[1],
                          E = (((u << 8) | (u >>> 24)) & 16711935) | (((u << 24) | (u >>> 8)) & 4278255360),
                          m = (((v << 8) | (v >>> 24)) & 16711935) | (((v << 24) | (v >>> 8)) & 4278255360),
                          B = (E >>> 16) | (m & 4294901760),
                          w = (m << 16) | (E & 65535);
                        ((y[0] ^= E),
                          (y[1] ^= B),
                          (y[2] ^= m),
                          (y[3] ^= w),
                          (y[4] ^= E),
                          (y[5] ^= B),
                          (y[6] ^= m),
                          (y[7] ^= w));
                        for (var p = 0; p < 4; p++) g.call(this);
                      }
                    },
                    _doProcessBlock: function (h, l) {
                      var d = this._X;
                      (g.call(this),
                        (o[0] = d[0] ^ (d[5] >>> 16) ^ (d[3] << 16)),
                        (o[1] = d[2] ^ (d[7] >>> 16) ^ (d[5] << 16)),
                        (o[2] = d[4] ^ (d[1] >>> 16) ^ (d[7] << 16)),
                        (o[3] = d[6] ^ (d[3] >>> 16) ^ (d[1] << 16)));
                      for (var y = 0; y < 4; y++)
                        ((o[y] = (((o[y] << 8) | (o[y] >>> 24)) & 16711935) | (((o[y] << 24) | (o[y] >>> 8)) & 4278255360)),
                          (h[l + y] ^= o[y]));
                    },
                    blockSize: 128 / 32,
                    ivSize: 64 / 32,
                  }));
                function g() {
                  for (var h = this._X, l = this._C, d = 0; d < 8; d++) x[d] = l[d];
                  ((l[0] = (l[0] + 1295307597 + this._b) | 0),
                    (l[1] = (l[1] + 3545052371 + (l[0] >>> 0 < x[0] >>> 0 ? 1 : 0)) | 0),
                    (l[2] = (l[2] + 886263092 + (l[1] >>> 0 < x[1] >>> 0 ? 1 : 0)) | 0),
                    (l[3] = (l[3] + 1295307597 + (l[2] >>> 0 < x[2] >>> 0 ? 1 : 0)) | 0),
                    (l[4] = (l[4] + 3545052371 + (l[3] >>> 0 < x[3] >>> 0 ? 1 : 0)) | 0),
                    (l[5] = (l[5] + 886263092 + (l[4] >>> 0 < x[4] >>> 0 ? 1 : 0)) | 0),
                    (l[6] = (l[6] + 1295307597 + (l[5] >>> 0 < x[5] >>> 0 ? 1 : 0)) | 0),
                    (l[7] = (l[7] + 3545052371 + (l[6] >>> 0 < x[6] >>> 0 ? 1 : 0)) | 0),
                    (this._b = l[7] >>> 0 < x[7] >>> 0 ? 1 : 0));
                  for (var d = 0; d < 8; d++) {
                    var y = h[d] + l[d],
                      p = y & 65535,
                      A = y >>> 16,
                      u = ((((p * p) >>> 17) + p * A) >>> 15) + A * A,
                      v = (((y & 4294901760) * y) | 0) + (((y & 65535) * y) | 0);
                    c[d] = u ^ v;
                  }
                  ((h[0] = (c[0] + ((c[7] << 16) | (c[7] >>> 16)) + ((c[6] << 16) | (c[6] >>> 16))) | 0),
                    (h[1] = (c[1] + ((c[0] << 8) | (c[0] >>> 24)) + c[7]) | 0),
                    (h[2] = (c[2] + ((c[1] << 16) | (c[1] >>> 16)) + ((c[0] << 16) | (c[0] >>> 16))) | 0),
                    (h[3] = (c[3] + ((c[2] << 8) | (c[2] >>> 24)) + c[1]) | 0),
                    (h[4] = (c[4] + ((c[3] << 16) | (c[3] >>> 16)) + ((c[2] << 16) | (c[2] >>> 16))) | 0),
                    (h[5] = (c[5] + ((c[4] << 8) | (c[4] >>> 24)) + c[3]) | 0),
                    (h[6] = (c[6] + ((c[5] << 16) | (c[5] >>> 16)) + ((c[4] << 16) | (c[4] >>> 16))) | 0),
                    (h[7] = (c[7] + ((c[6] << 8) | (c[6] >>> 24)) + c[5]) | 0));
                }
                r.RabbitLegacy = s._createHelper(f);
              })(),
              e.RabbitLegacy
            );
          });
        })(Nt)),
      Nt.exports
    );
  }
  var Kt = {exports: {}},
    is = Kt.exports,
    Dr;
  function ns() {
    return (
      Dr ||
        ((Dr = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(z(), A0(), C0(), g0(), Q());
          })(is, function (e) {
            return (
              (function () {
                var r = e,
                  n = r.lib,
                  s = n.BlockCipher,
                  a = r.algo;
                const o = 16,
                  x = [
                    608135816, 2242054355, 320440878, 57701188, 2752067618, 698298832, 137296536, 3964562569, 1160258022,
                    953160567, 3193202383, 887688300, 3232508343, 3380367581, 1065670069, 3041331479, 2450970073,
                    2306472731,
                  ],
                  c = [
                    [
                      3509652390, 2564797868, 805139163, 3491422135, 3101798381, 1780907670, 3128725573, 4046225305,
                      614570311, 3012652279, 134345442, 2240740374, 1667834072, 1901547113, 2757295779, 4103290238,
                      227898511, 1921955416, 1904987480, 2182433518, 2069144605, 3260701109, 2620446009, 720527379,
                      3318853667, 677414384, 3393288472, 3101374703, 2390351024, 1614419982, 1822297739, 2954791486,
                      3608508353, 3174124327, 2024746970, 1432378464, 3864339955, 2857741204, 1464375394, 1676153920,
                      1439316330, 715854006, 3033291828, 289532110, 2706671279, 2087905683, 3018724369, 1668267050,
                      732546397, 1947742710, 3462151702, 2609353502, 2950085171, 1814351708, 2050118529, 680887927,
                      999245976, 1800124847, 3300911131, 1713906067, 1641548236, 4213287313, 1216130144, 1575780402,
                      4018429277, 3917837745, 3693486850, 3949271944, 596196993, 3549867205, 258830323, 2213823033,
                      772490370, 2760122372, 1774776394, 2652871518, 566650946, 4142492826, 1728879713, 2882767088,
                      1783734482, 3629395816, 2517608232, 2874225571, 1861159788, 326777828, 3124490320, 2130389656,
                      2716951837, 967770486, 1724537150, 2185432712, 2364442137, 1164943284, 2105845187, 998989502,
                      3765401048, 2244026483, 1075463327, 1455516326, 1322494562, 910128902, 469688178, 1117454909,
                      936433444, 3490320968, 3675253459, 1240580251, 122909385, 2157517691, 634681816, 4142456567,
                      3825094682, 3061402683, 2540495037, 79693498, 3249098678, 1084186820, 1583128258, 426386531,
                      1761308591, 1047286709, 322548459, 995290223, 1845252383, 2603652396, 3431023940, 2942221577,
                      3202600964, 3727903485, 1712269319, 422464435, 3234572375, 1170764815, 3523960633, 3117677531,
                      1434042557, 442511882, 3600875718, 1076654713, 1738483198, 4213154764, 2393238008, 3677496056,
                      1014306527, 4251020053, 793779912, 2902807211, 842905082, 4246964064, 1395751752, 1040244610,
                      2656851899, 3396308128, 445077038, 3742853595, 3577915638, 679411651, 2892444358, 2354009459,
                      1767581616, 3150600392, 3791627101, 3102740896, 284835224, 4246832056, 1258075500, 768725851,
                      2589189241, 3069724005, 3532540348, 1274779536, 3789419226, 2764799539, 1660621633, 3471099624,
                      4011903706, 913787905, 3497959166, 737222580, 2514213453, 2928710040, 3937242737, 1804850592,
                      3499020752, 2949064160, 2386320175, 2390070455, 2415321851, 4061277028, 2290661394, 2416832540,
                      1336762016, 1754252060, 3520065937, 3014181293, 791618072, 3188594551, 3933548030, 2332172193,
                      3852520463, 3043980520, 413987798, 3465142937, 3030929376, 4245938359, 2093235073, 3534596313,
                      375366246, 2157278981, 2479649556, 555357303, 3870105701, 2008414854, 3344188149, 4221384143,
                      3956125452, 2067696032, 3594591187, 2921233993, 2428461, 544322398, 577241275, 1471733935, 610547355,
                      4027169054, 1432588573, 1507829418, 2025931657, 3646575487, 545086370, 48609733, 2200306550,
                      1653985193, 298326376, 1316178497, 3007786442, 2064951626, 458293330, 2589141269, 3591329599,
                      3164325604, 727753846, 2179363840, 146436021, 1461446943, 4069977195, 705550613, 3059967265,
                      3887724982, 4281599278, 3313849956, 1404054877, 2845806497, 146425753, 1854211946,
                    ],
                    [
                      1266315497, 3048417604, 3681880366, 3289982499, 290971e4, 1235738493, 2632868024, 2414719590,
                      3970600049, 1771706367, 1449415276, 3266420449, 422970021, 1963543593, 2690192192, 3826793022,
                      1062508698, 1531092325, 1804592342, 2583117782, 2714934279, 4024971509, 1294809318, 4028980673,
                      1289560198, 2221992742, 1669523910, 35572830, 157838143, 1052438473, 1016535060, 1802137761,
                      1753167236, 1386275462, 3080475397, 2857371447, 1040679964, 2145300060, 2390574316, 1461121720,
                      2956646967, 4031777805, 4028374788, 33600511, 2920084762, 1018524850, 629373528, 3691585981,
                      3515945977, 2091462646, 2486323059, 586499841, 988145025, 935516892, 3367335476, 2599673255,
                      2839830854, 265290510, 3972581182, 2759138881, 3795373465, 1005194799, 847297441, 406762289,
                      1314163512, 1332590856, 1866599683, 4127851711, 750260880, 613907577, 1450815602, 3165620655,
                      3734664991, 3650291728, 3012275730, 3704569646, 1427272223, 778793252, 1343938022, 2676280711,
                      2052605720, 1946737175, 3164576444, 3914038668, 3967478842, 3682934266, 1661551462, 3294938066,
                      4011595847, 840292616, 3712170807, 616741398, 312560963, 711312465, 1351876610, 322626781, 1910503582,
                      271666773, 2175563734, 1594956187, 70604529, 3617834859, 1007753275, 1495573769, 4069517037,
                      2549218298, 2663038764, 504708206, 2263041392, 3941167025, 2249088522, 1514023603, 1998579484,
                      1312622330, 694541497, 2582060303, 2151582166, 1382467621, 776784248, 2618340202, 3323268794,
                      2497899128, 2784771155, 503983604, 4076293799, 907881277, 423175695, 432175456, 1378068232,
                      4145222326, 3954048622, 3938656102, 3820766613, 2793130115, 2977904593, 26017576, 3274890735,
                      3194772133, 1700274565, 1756076034, 4006520079, 3677328699, 720338349, 1533947780, 354530856,
                      688349552, 3973924725, 1637815568, 332179504, 3949051286, 53804574, 2852348879, 3044236432,
                      1282449977, 3583942155, 3416972820, 4006381244, 1617046695, 2628476075, 3002303598, 1686838959,
                      431878346, 2686675385, 1700445008, 1080580658, 1009431731, 832498133, 3223435511, 2605976345,
                      2271191193, 2516031870, 1648197032, 4164389018, 2548247927, 300782431, 375919233, 238389289,
                      3353747414, 2531188641, 2019080857, 1475708069, 455242339, 2609103871, 448939670, 3451063019,
                      1395535956, 2413381860, 1841049896, 1491858159, 885456874, 4264095073, 4001119347, 1565136089,
                      3898914787, 1108368660, 540939232, 1173283510, 2745871338, 3681308437, 4207628240, 3343053890,
                      4016749493, 1699691293, 1103962373, 3625875870, 2256883143, 3830138730, 1031889488, 3479347698,
                      1535977030, 4236805024, 3251091107, 2132092099, 1774941330, 1199868427, 1452454533, 157007616,
                      2904115357, 342012276, 595725824, 1480756522, 206960106, 497939518, 591360097, 863170706, 2375253569,
                      3596610801, 1814182875, 2094937945, 3421402208, 1082520231, 3463918190, 2785509508, 435703966,
                      3908032597, 1641649973, 2842273706, 3305899714, 1510255612, 2148256476, 2655287854, 3276092548,
                      4258621189, 236887753, 3681803219, 274041037, 1734335097, 3815195456, 3317970021, 1899903192,
                      1026095262, 4050517792, 356393447, 2410691914, 3873677099, 3682840055,
                    ],
                    [
                      3913112168, 2491498743, 4132185628, 2489919796, 1091903735, 1979897079, 3170134830, 3567386728,
                      3557303409, 857797738, 1136121015, 1342202287, 507115054, 2535736646, 337727348, 3213592640,
                      1301675037, 2528481711, 1895095763, 1721773893, 3216771564, 62756741, 2142006736, 835421444,
                      2531993523, 1442658625, 3659876326, 2882144922, 676362277, 1392781812, 170690266, 3921047035,
                      1759253602, 3611846912, 1745797284, 664899054, 1329594018, 3901205900, 3045908486, 2062866102,
                      2865634940, 3543621612, 3464012697, 1080764994, 553557557, 3656615353, 3996768171, 991055499,
                      499776247, 1265440854, 648242737, 3940784050, 980351604, 3713745714, 1749149687, 3396870395,
                      4211799374, 3640570775, 1161844396, 3125318951, 1431517754, 545492359, 4268468663, 3499529547,
                      1437099964, 2702547544, 3433638243, 2581715763, 2787789398, 1060185593, 1593081372, 2418618748,
                      4260947970, 69676912, 2159744348, 86519011, 2512459080, 3838209314, 1220612927, 3339683548, 133810670,
                      1090789135, 1078426020, 1569222167, 845107691, 3583754449, 4072456591, 1091646820, 628848692,
                      1613405280, 3757631651, 526609435, 236106946, 48312990, 2942717905, 3402727701, 1797494240, 859738849,
                      992217954, 4005476642, 2243076622, 3870952857, 3732016268, 765654824, 3490871365, 2511836413,
                      1685915746, 3888969200, 1414112111, 2273134842, 3281911079, 4080962846, 172450625, 2569994100,
                      980381355, 4109958455, 2819808352, 2716589560, 2568741196, 3681446669, 3329971472, 1835478071,
                      660984891, 3704678404, 4045999559, 3422617507, 3040415634, 1762651403, 1719377915, 3470491036,
                      2693910283, 3642056355, 3138596744, 1364962596, 2073328063, 1983633131, 926494387, 3423689081,
                      2150032023, 4096667949, 1749200295, 3328846651, 309677260, 2016342300, 1779581495, 3079819751,
                      111262694, 1274766160, 443224088, 298511866, 1025883608, 3806446537, 1145181785, 168956806,
                      3641502830, 3584813610, 1689216846, 3666258015, 3200248200, 1692713982, 2646376535, 4042768518,
                      1618508792, 1610833997, 3523052358, 4130873264, 2001055236, 3610705100, 2202168115, 4028541809,
                      2961195399, 1006657119, 2006996926, 3186142756, 1430667929, 3210227297, 1314452623, 4074634658,
                      4101304120, 2273951170, 1399257539, 3367210612, 3027628629, 1190975929, 2062231137, 2333990788,
                      2221543033, 2438960610, 1181637006, 548689776, 2362791313, 3372408396, 3104550113, 3145860560,
                      296247880, 1970579870, 3078560182, 3769228297, 1714227617, 3291629107, 3898220290, 166772364,
                      1251581989, 493813264, 448347421, 195405023, 2709975567, 677966185, 3703036547, 1463355134,
                      2715995803, 1338867538, 1343315457, 2802222074, 2684532164, 233230375, 2599980071, 2000651841,
                      3277868038, 1638401717, 4028070440, 3237316320, 6314154, 819756386, 300326615, 590932579, 1405279636,
                      3267499572, 3150704214, 2428286686, 3959192993, 3461946742, 1862657033, 1266418056, 963775037,
                      2089974820, 2263052895, 1917689273, 448879540, 3550394620, 3981727096, 150775221, 3627908307,
                      1303187396, 508620638, 2975983352, 2726630617, 1817252668, 1876281319, 1457606340, 908771278,
                      3720792119, 3617206836, 2455994898, 1729034894, 1080033504,
                    ],
                    [
                      976866871, 3556439503, 2881648439, 1522871579, 1555064734, 1336096578, 3548522304, 2579274686,
                      3574697629, 3205460757, 3593280638, 3338716283, 3079412587, 564236357, 2993598910, 1781952180,
                      1464380207, 3163844217, 3332601554, 1699332808, 1393555694, 1183702653, 3581086237, 1288719814,
                      691649499, 2847557200, 2895455976, 3193889540, 2717570544, 1781354906, 1676643554, 2592534050,
                      3230253752, 1126444790, 2770207658, 2633158820, 2210423226, 2615765581, 2414155088, 3127139286,
                      673620729, 2805611233, 1269405062, 4015350505, 3341807571, 4149409754, 1057255273, 2012875353,
                      2162469141, 2276492801, 2601117357, 993977747, 3918593370, 2654263191, 753973209, 36408145,
                      2530585658, 25011837, 3520020182, 2088578344, 530523599, 2918365339, 1524020338, 1518925132,
                      3760827505, 3759777254, 1202760957, 3985898139, 3906192525, 674977740, 4174734889, 2031300136,
                      2019492241, 3983892565, 4153806404, 3822280332, 352677332, 2297720250, 60907813, 90501309, 3286998549,
                      1016092578, 2535922412, 2839152426, 457141659, 509813237, 4120667899, 652014361, 1966332200,
                      2975202805, 55981186, 2327461051, 676427537, 3255491064, 2882294119, 3433927263, 1307055953,
                      942726286, 933058658, 2468411793, 3933900994, 4215176142, 1361170020, 2001714738, 2830558078,
                      3274259782, 1222529897, 1679025792, 2729314320, 3714953764, 1770335741, 151462246, 3013232138,
                      1682292957, 1483529935, 471910574, 1539241949, 458788160, 3436315007, 1807016891, 3718408830,
                      978976581, 1043663428, 3165965781, 1927990952, 4200891579, 2372276910, 3208408903, 3533431907,
                      1412390302, 2931980059, 4132332400, 1947078029, 3881505623, 4168226417, 2941484381, 1077988104,
                      1320477388, 886195818, 18198404, 3786409e3, 2509781533, 112762804, 3463356488, 1866414978, 891333506,
                      18488651, 661792760, 1628790961, 3885187036, 3141171499, 876946877, 2693282273, 1372485963, 791857591,
                      2686433993, 3759982718, 3167212022, 3472953795, 2716379847, 445679433, 3561995674, 3504004811,
                      3574258232, 54117162, 3331405415, 2381918588, 3769707343, 4154350007, 1140177722, 4074052095,
                      668550556, 3214352940, 367459370, 261225585, 2610173221, 4209349473, 3468074219, 3265815641,
                      314222801, 3066103646, 3808782860, 282218597, 3406013506, 3773591054, 379116347, 1285071038,
                      846784868, 2669647154, 3771962079, 3550491691, 2305946142, 453669953, 1268987020, 3317592352,
                      3279303384, 3744833421, 2610507566, 3859509063, 266596637, 3847019092, 517658769, 3462560207,
                      3443424879, 370717030, 4247526661, 2224018117, 4143653529, 4112773975, 2788324899, 2477274417,
                      1456262402, 2901442914, 1517677493, 1846949527, 2295493580, 3734397586, 2176403920, 1280348187,
                      1908823572, 3871786941, 846861322, 1172426758, 3287448474, 3383383037, 1655181056, 3139813346,
                      901632758, 1897031941, 2986607138, 3066810236, 3447102507, 1393639104, 373351379, 950779232,
                      625454576, 3124240540, 4148612726, 2007998917, 544563296, 2244738638, 2330496472, 2058025392,
                      1291430526, 424198748, 50039436, 29584100, 3605783033, 2429876329, 2791104160, 1057563949, 3255363231,
                      3075367218, 3463963227, 1469046755, 985887462,
                    ],
                  ];
                var f = {pbox: [], sbox: []};
                function g(p, A) {
                  let u = (A >> 24) & 255,
                    v = (A >> 16) & 255,
                    E = (A >> 8) & 255,
                    m = A & 255,
                    B = p.sbox[0][u] + p.sbox[1][v];
                  return ((B = B ^ p.sbox[2][E]), (B = B + p.sbox[3][m]), B);
                }
                function h(p, A, u) {
                  let v = A,
                    E = u,
                    m;
                  for (let B = 0; B < o; ++B) ((v = v ^ p.pbox[B]), (E = g(p, v) ^ E), (m = v), (v = E), (E = m));
                  return ((m = v), (v = E), (E = m), (E = E ^ p.pbox[o]), (v = v ^ p.pbox[o + 1]), {left: v, right: E});
                }
                function l(p, A, u) {
                  let v = A,
                    E = u,
                    m;
                  for (let B = o + 1; B > 1; --B) ((v = v ^ p.pbox[B]), (E = g(p, v) ^ E), (m = v), (v = E), (E = m));
                  return ((m = v), (v = E), (E = m), (E = E ^ p.pbox[1]), (v = v ^ p.pbox[0]), {left: v, right: E});
                }
                function d(p, A, u) {
                  for (let w = 0; w < 4; w++) {
                    p.sbox[w] = [];
                    for (let b = 0; b < 256; b++) p.sbox[w][b] = c[w][b];
                  }
                  let v = 0;
                  for (let w = 0; w < o + 2; w++) ((p.pbox[w] = x[w] ^ A[v]), v++, v >= u && (v = 0));
                  let E = 0,
                    m = 0,
                    B = 0;
                  for (let w = 0; w < o + 2; w += 2)
                    ((B = h(p, E, m)), (E = B.left), (m = B.right), (p.pbox[w] = E), (p.pbox[w + 1] = m));
                  for (let w = 0; w < 4; w++)
                    for (let b = 0; b < 256; b += 2)
                      ((B = h(p, E, m)), (E = B.left), (m = B.right), (p.sbox[w][b] = E), (p.sbox[w][b + 1] = m));
                  return !0;
                }
                var y = (a.Blowfish = s.extend({
                  _doReset: function () {
                    if (this._keyPriorReset !== this._key) {
                      var p = (this._keyPriorReset = this._key),
                        A = p.words,
                        u = p.sigBytes / 4;
                      d(f, A, u);
                    }
                  },
                  encryptBlock: function (p, A) {
                    var u = h(f, p[A], p[A + 1]);
                    ((p[A] = u.left), (p[A + 1] = u.right));
                  },
                  decryptBlock: function (p, A) {
                    var u = l(f, p[A], p[A + 1]);
                    ((p[A] = u.left), (p[A + 1] = u.right));
                  },
                  blockSize: 64 / 32,
                  keySize: 128 / 32,
                  ivSize: 64 / 32,
                }));
                r.Blowfish = s._createHelper(y);
              })(),
              e.Blowfish
            );
          });
        })(Kt)),
      Kt.exports
    );
  }
  var ss = nt.exports,
    Ar;
  function os() {
    return (
      Ar ||
        ((Ar = 1),
        (function (i, t) {
          (function (e, r, n) {
            i.exports = r(
              z(),
              at(),
              en(),
              nn(),
              A0(),
              an(),
              C0(),
              We(),
              se(),
              un(),
              Ye(),
              vn(),
              gn(),
              En(),
              oe(),
              An(),
              g0(),
              Q(),
              bn(),
              Fn(),
              Tn(),
              Rn(),
              Pn(),
              Hn(),
              Ln(),
              Kn(),
              zn(),
              Mn(),
              jn(),
              Gn(),
              Xn(),
              Qn(),
              ts(),
              rs(),
              ns(),
            );
          })(ss, function (e) {
            return e;
          });
        })(nt)),
      nt.exports
    );
  }
  var N0 = os();
  const Cr = () => {
      const i = new Le({default_key_size: 2048}),
        t = i.getPublicKey(),
        e = i.getPrivateKey();
      return {publicKey: t, privateKey: e};
    },
    mr = (i, t) => {
      const e = new Le();
      return (e.setPrivateKey(t), e.decrypt(i));
    },
    wr = (i, t) => {
      const e = N0.enc.Base64.parse(i),
        r = N0.enc.Utf8.parse(i.slice(0, 16));
      return N0.AES.encrypt(t, e, {iv: r, mode: N0.mode.CBC, padding: N0.pad.Pkcs7}).toString();
    };
  class ae {
    constructor(t) {
      H(this, "baseURL");
      H(this, "communityBaseURL");
      H(this, "targetUserIriURL");
      H(this, "token", "");
      H(this, "tokenType", u0.AccessToken);
      ((this.baseURL = t.baseURL),
        (this.communityBaseURL = t.communityBaseURL),
        (this.targetUserIriURL = t.targetUserIriURL || t.communityBaseURL));
      const e = O0(t.token);
      ((this.token = e.token), (this.tokenType = e.tokenType));
    }
    async _getCommunityDisplayName(t) {
      return t.targetUserIriList.length > 0
        ? await wi({communityBaseURL: this.communityBaseURL, communityConfig: t})
            .then((e) => (console.log("post display name successfully"), e))
            .catch((e) => (console.error("Get display name error:", e), {data: []}))
        : {data: []};
    }
    async getLeaderboard(t, e, r) {
      const n = r ? O0(r) : {token: this.token, tokenType: this.tokenType},
        s = G0(n);
      if (!s) throw Error("This API is only available to logged-in users.");
      const a = m0(e);
      try {
        const o = await Ee({baseUrl: this.baseURL, ...s, appID: t, getLeaderboardParams: a});
        if (!o || !Array.isArray(o.ranking))
          return (console.error("Leaderboard ranking data is invalid or empty:", o), null);
        if (o.ranking.length === 0)
          return (console.log("Leaderboard ranking is empty, returning leaderboard meta data"), o);
        const c = o.ranking.map((h) => h.uid).map((h) => `${this.targetUserIriURL}users/${h}`),
          f = await this._getCommunityDisplayName({targetUserIriList: c}),
          g = new Map(f.data.map((h) => [h.userIri, h.name]));
        return (
          o.ranking.forEach((h) => {
            const l = `${this.targetUserIriURL}users/${h.uid}`;
            h.name = g.get(l) || "User";
          }),
          o
        );
      } catch (o) {
        return (console.error("Get leaderboard ranking error:", o), null);
      }
    }
    async getGuestLeaderboard(t, e) {
      const r = m0(e);
      try {
        const n = await Be({baseUrl: this.baseURL, appID: t, getGuestLeaderboardParams: r});
        if (!n || !Array.isArray(n.ranking))
          return (console.error("Guest leaderboard ranking data is invalid or empty:", n), null);
        if (n.ranking.length === 0)
          return (console.log("Guest leaderboard ranking is empty, returning leaderboard meta data"), n);
        const a = n.ranking.map((c) => c.uid).map((c) => `${this.targetUserIriURL}users/${c}`),
          o = await this._getCommunityDisplayName({targetUserIriList: a}),
          x = new Map(o.data.map((c) => [c.userIri, c.name]));
        return (
          n.ranking.forEach((c) => {
            const f = `${this.targetUserIriURL}users/${c.uid}`;
            c.name = x.get(f) || "User";
          }),
          n
        );
      } catch (n) {
        return (console.error("Get leaderboard ranking error:", n), null);
      }
    }
    async _getSessionToken(t, e, r) {
      return await De({baseUrl: this.baseURL, ...t, appID: e, publicKey: r}).catch((n) => {
        throw (console.error("Get session token error:", n), Error("Get session token error"));
      });
    }
    async uploadLeaderboardScore(t, e, r) {
      const n = r ? O0(r) : {token: this.token, tokenType: this.tokenType},
        s = G0(n);
      if (!s) throw Error("This API is only available to logged-in users.");
      const {publicKey: a, privateKey: o} = Cr(),
        f = a.replace("-----BEGIN PUBLIC KEY-----", "").replace("-----END PUBLIC KEY-----", "").replace(/\s+/g, "");
      try {
        const g = await this._getSessionToken(s, t, f),
          {token: h, key: l} = g,
          d = JSON.stringify({scores: e}),
          y = mr(l, o),
          A = {scores: wr(y, d)};
        return await Ae({baseUrl: this.baseURL, ...s, appID: t, sessionToken: h, scores: A}).then(
          (u) => (console.log("Upload leaderboard record successfully"), u),
        );
      } catch (g) {
        return (console.error("Upload leaderboard record failed:", g), null);
      }
    }
    async getUserAchievement(t, e) {
      const r = e ? O0(e) : {token: this.token, tokenType: this.tokenType},
        n = G0(r);
      if (!n) throw Error("This API is only available to logged-in users.");
      return await Ce({baseUrl: this.baseURL, ...n, appID: t}).catch(
        (s) => (console.error("Get user achievement error:", s), null),
      );
    }
    async uploadUserAchievement(t, e, r) {
      const n = r ? O0(r) : {token: this.token, tokenType: this.tokenType},
        s = G0(n);
      if (!s) throw Error("This API is only available to logged-in users.");
      const {publicKey: a, privateKey: o} = Cr(),
        f = a.replace("-----BEGIN PUBLIC KEY-----", "").replace("-----END PUBLIC KEY-----", "").replace(/\s+/g, "");
      try {
        const g = await this._getSessionToken(s, t, f),
          {token: h, key: l} = g,
          d = JSON.stringify({achievements: e}),
          y = mr(l, o),
          A = {data: wr(y, d)};
        return await me({baseUrl: this.baseURL, ...s, appID: t, sessionToken: h, data: A}).then(
          (u) => (console.log("Upload user achievement successfully"), u),
        );
      } catch (g) {
        return (console.error("Upload user achievement failed:", g), null);
      }
    }
  }
  class ce {
    constructor(t) {
      H(this, "playSDKUrl", "https://www.viverse.com/static-assets/play-sdk/1.0.1/play-sdk.umd.js");
      H(this, "playSDK");
      H(this, "scriptLoading", !1);
      (console.log("PlayClient constructor"), this._initializePlay(t == null ? void 0 : t.sdkURL));
    }
    async _initializePlay(t) {
      (globalThis.play ||
        (console.log("Loading Play SDK script"),
        (this.scriptLoading = !0),
        t ? await I0(t) : await I0(this.playSDKUrl),
        (this.scriptLoading = !1)),
        (this.playSDK = globalThis.play));
    }
    async newMatchmakingClient(t, e, r) {
      if (typeof (await P0(this, "scriptLoading", !1)) > "u") return (console.error("play SDK script loading error"), null);
      if ((this.playSDK || (await this._initializePlay()), !this.playSDK)) throw Error("Play SDK is not initialized");
      return new this.playSDK.MatchmakingClient(t, e, r);
    }
    async newMultiplayerClient(t, e, r) {
      if (typeof (await P0(this, "scriptLoading", !1)) > "u") return (console.error("play SDK script loading error"), null);
      if ((this.playSDK || (await this._initializePlay()), !this.playSDK)) throw Error("Play SDK is not initialized");
      return new this.playSDK.MultiplayerClient(t, e, r);
    }
  }
  class xe {
    constructor(t) {
      H(this, "storageSDKUrl", "https://www.viverse.com/static-assets/storage-sdk/1.0.0/storage-sdk.umd.js");
      H(this, "storageSDK");
      H(this, "scriptLoading", !1);
      (console.log("StorageClient constructor"), this._initializeStorage(t == null ? void 0 : t.sdkURL));
    }
    async _initializeStorage(t) {
      (globalThis.storage ||
        (console.log("Loading Storage SDK script"),
        (this.scriptLoading = !0),
        t ? await I0(t) : await I0(this.storageSDKUrl),
        (this.scriptLoading = !1)),
        (this.storageSDK = globalThis.storage));
    }
    async newCloudSaveClient(t) {
      if (typeof (await P0(this, "scriptLoading", !1)) > "u")
        return (console.error("storage SDK script loading error"), null);
      if ((this.storageSDK || (await this._initializePlay()), !this.storageSDK))
        throw Error("Storage SDK is not initialized");
      return new this.storageSDK.CloudSaveClient(t);
    }
  }
  const as = {Client: Xt, Avatar: Yt, GameDashboard: ae, Play: ce, Storage: xe};
  ((V.Avatar = Yt),
    (V.Client = Xt),
    (V.DEFAULT_SCOPE = B0),
    (V.GameDashboard = ae),
    (V.Play = ce),
    (V.Storage = xe),
    (V.TokenType = u0),
    (V.User = e0),
    (V.avatar = Yt),
    (V.client = Xt),
    (V.default = as),
    (V.gameDashboard = ae),
    (V.getGuestLeaderboardRanking = Be),
    (V.getLeaderboardRanking = Ee),
    (V.getSessionToken = De),
    (V.getUserAchievement = Ce),
    (V.play = ce),
    (V.postLeaderboardRecord = Ae),
    (V.postUserAchievement = me),
    (V.storage = xe),
    Object.defineProperties(V, {__esModule: {value: !0}, [Symbol.toStringTag]: {value: "Module"}}));
});
