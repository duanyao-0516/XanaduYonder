package
{
   import net.louissi.Alpha1.Screens.Sponsor;
   import net.louissi.Moon.Global.GlobalVars;
   
   public class Alpha1
   {
      
      public function Alpha1()
      {
         super();
         GlobalVars.nextScreen = Sponsor;
      }
   }
}

