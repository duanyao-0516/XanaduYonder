package net.louissi.Alpha1.Global
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/75_net.louissi.Alpha1.Global.Ressources_DIFFICULTY_SWF_dataClass.bin", mimeType="application/octet-stream")]
   public class Ressources_DIFFICULTY_SWF_dataClass extends ByteArrayAsset
   {
      
      public function Ressources_DIFFICULTY_SWF_dataClass()
      {
         super();
      }
   }
}

