package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/49_net.louissi.Alpha1.Global.Ressources_Sound_hurt3_net.louissi.Alpha1.Global.Ressources_Sound_hurt3.mp3")]
   public class Ressources_Sound_hurt3 extends SoundAsset
   {
      
      public function Ressources_Sound_hurt3()
      {
         super();
      }
   }
}

