package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/28_net.louissi.Alpha1.Global.Ressources_Sound_gun4_net.louissi.Alpha1.Global.Ressources_Sound_gun4.mp3")]
   public class Ressources_Sound_gun4 extends SoundAsset
   {
      
      public function Ressources_Sound_gun4()
      {
         super();
      }
   }
}

