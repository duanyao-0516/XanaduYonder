package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/54_net.louissi.Alpha1.Global.Ressources_Sound_fireball_net.louissi.Alpha1.Global.Ressources_Sound_fireball.mp3")]
   public class Ressources_Sound_fireball extends SoundAsset
   {
      
      public function Ressources_Sound_fireball()
      {
         super();
      }
   }
}

