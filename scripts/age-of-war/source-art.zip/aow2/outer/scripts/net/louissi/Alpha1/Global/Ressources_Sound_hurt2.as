package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/48_net.louissi.Alpha1.Global.Ressources_Sound_hurt2_net.louissi.Alpha1.Global.Ressources_Sound_hurt2.mp3")]
   public class Ressources_Sound_hurt2 extends SoundAsset
   {
      
      public function Ressources_Sound_hurt2()
      {
         super();
      }
   }
}

