package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/43_net.louissi.Alpha1.Global.Ressources_Sound_hurt5_net.louissi.Alpha1.Global.Ressources_Sound_hurt5.mp3")]
   public class Ressources_Sound_hurt5 extends SoundAsset
   {
      
      public function Ressources_Sound_hurt5()
      {
         super();
      }
   }
}

