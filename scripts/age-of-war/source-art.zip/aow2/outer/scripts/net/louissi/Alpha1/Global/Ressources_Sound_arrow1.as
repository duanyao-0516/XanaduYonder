package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/27_net.louissi.Alpha1.Global.Ressources_Sound_arrow1_net.louissi.Alpha1.Global.Ressources_Sound_arrow1.mp3")]
   public class Ressources_Sound_arrow1 extends SoundAsset
   {
      
      public function Ressources_Sound_arrow1()
      {
         super();
      }
   }
}

