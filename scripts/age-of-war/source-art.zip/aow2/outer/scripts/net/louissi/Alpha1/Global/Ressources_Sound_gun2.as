package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/31_net.louissi.Alpha1.Global.Ressources_Sound_gun2_net.louissi.Alpha1.Global.Ressources_Sound_gun2.mp3")]
   public class Ressources_Sound_gun2 extends SoundAsset
   {
      
      public function Ressources_Sound_gun2()
      {
         super();
      }
   }
}

