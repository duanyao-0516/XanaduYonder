package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/50_net.louissi.Alpha1.Global.Ressources_Sound_hurt4_net.louissi.Alpha1.Global.Ressources_Sound_hurt4.mp3")]
   public class Ressources_Sound_hurt4 extends SoundAsset
   {
      
      public function Ressources_Sound_hurt4()
      {
         super();
      }
   }
}

