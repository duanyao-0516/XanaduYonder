package net.louissi.Alpha1
{
   import net.louissi.Alpha1.Screens.Preloader;
   import net.louissi.Moon.Engines.Engine;
   
   [SWF(width="720", height="480", backgroundColor="#ffffff", frameRate="30")]
   public class EngineStart extends Engine
   {
      
      private const MAIN_CLASS:String = "Alpha1";
      
      private const STAGE_WIDTH:int = 720;
      
      private const STAGE_HEIGHT:int = 480;
      
      private const FPS:int = 30;
      
      private const IS_LOADING_EMBEDDED:Boolean = true;
      
      private const ALLOWED_DOMAINS:String = "";
      
      private const MOCHIBOT:String = "9917654c";
      
      private const CONTEXTMENU:Array = [["Game by Louissi","http://www.interactive-pixels.net"],["Sponsored by MaxGames","http://www.maxgames.com"]];
      
      public function EngineStart()
      {
         trace("start engine");
         super(this.MAIN_CLASS,Preloader,this.STAGE_WIDTH,this.STAGE_HEIGHT,this.IS_LOADING_EMBEDDED,this.ALLOWED_DOMAINS,this.MOCHIBOT,true,true,false,true,this.CONTEXTMENU);
         stop();
      }
   }
}

