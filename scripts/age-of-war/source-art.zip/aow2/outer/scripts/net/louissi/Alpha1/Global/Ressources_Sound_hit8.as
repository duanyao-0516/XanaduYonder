package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/20_net.louissi.Alpha1.Global.Ressources_Sound_hit8_net.louissi.Alpha1.Global.Ressources_Sound_hit8.mp3")]
   public class Ressources_Sound_hit8 extends SoundAsset
   {
      
      public function Ressources_Sound_hit8()
      {
         super();
      }
   }
}

