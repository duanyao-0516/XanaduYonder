package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/22_net.louissi.Alpha1.Global.Ressources_Sound_explosion6_net.louissi.Alpha1.Global.Ressources_Sound_explosion6.mp3")]
   public class Ressources_Sound_explosion6 extends SoundAsset
   {
      
      public function Ressources_Sound_explosion6()
      {
         super();
      }
   }
}

