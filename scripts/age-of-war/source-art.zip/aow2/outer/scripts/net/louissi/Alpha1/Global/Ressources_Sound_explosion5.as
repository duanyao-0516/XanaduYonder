package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/24_net.louissi.Alpha1.Global.Ressources_Sound_explosion5_net.louissi.Alpha1.Global.Ressources_Sound_explosion5.mp3")]
   public class Ressources_Sound_explosion5 extends SoundAsset
   {
      
      public function Ressources_Sound_explosion5()
      {
         super();
      }
   }
}

