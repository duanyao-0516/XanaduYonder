package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/19_net.louissi.Alpha1.Global.Ressources_Sound_explosion4_net.louissi.Alpha1.Global.Ressources_Sound_explosion4.mp3")]
   public class Ressources_Sound_explosion4 extends SoundAsset
   {
      
      public function Ressources_Sound_explosion4()
      {
         super();
      }
   }
}

