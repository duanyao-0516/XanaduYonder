package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/10_net.louissi.Alpha1.Global.Ressources_Sound_gun12_net.louissi.Alpha1.Global.Ressources_Sound_gun12.mp3")]
   public class Ressources_Sound_gun12 extends SoundAsset
   {
      
      public function Ressources_Sound_gun12()
      {
         super();
      }
   }
}

