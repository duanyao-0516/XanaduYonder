package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/33_net.louissi.Alpha1.Global.Ressources_Sound_gun8_net.louissi.Alpha1.Global.Ressources_Sound_gun8.mp3")]
   public class Ressources_Sound_gun8 extends SoundAsset
   {
      
      public function Ressources_Sound_gun8()
      {
         super();
      }
   }
}

