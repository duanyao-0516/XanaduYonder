package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/53_net.louissi.Alpha1.Global.Ressources_Sound_lightning2_net.louissi.Alpha1.Global.Ressources_Sound_lightning2.mp3")]
   public class Ressources_Sound_lightning2 extends SoundAsset
   {
      
      public function Ressources_Sound_lightning2()
      {
         super();
      }
   }
}

