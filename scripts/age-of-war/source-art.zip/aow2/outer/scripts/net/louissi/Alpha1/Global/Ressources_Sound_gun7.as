package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/34_net.louissi.Alpha1.Global.Ressources_Sound_gun7_net.louissi.Alpha1.Global.Ressources_Sound_gun7.mp3")]
   public class Ressources_Sound_gun7 extends SoundAsset
   {
      
      public function Ressources_Sound_gun7()
      {
         super();
      }
   }
}

