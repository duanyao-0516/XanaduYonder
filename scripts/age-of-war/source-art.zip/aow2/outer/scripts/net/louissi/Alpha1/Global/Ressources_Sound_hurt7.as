package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/45_net.louissi.Alpha1.Global.Ressources_Sound_hurt7_net.louissi.Alpha1.Global.Ressources_Sound_hurt7.mp3")]
   public class Ressources_Sound_hurt7 extends SoundAsset
   {
      
      public function Ressources_Sound_hurt7()
      {
         super();
      }
   }
}

