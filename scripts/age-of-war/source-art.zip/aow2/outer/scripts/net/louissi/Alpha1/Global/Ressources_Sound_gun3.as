package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/30_net.louissi.Alpha1.Global.Ressources_Sound_gun3_net.louissi.Alpha1.Global.Ressources_Sound_gun3.mp3")]
   public class Ressources_Sound_gun3 extends SoundAsset
   {
      
      public function Ressources_Sound_gun3()
      {
         super();
      }
   }
}

