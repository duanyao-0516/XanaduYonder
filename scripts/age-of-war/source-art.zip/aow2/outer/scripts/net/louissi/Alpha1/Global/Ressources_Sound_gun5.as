package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/26_net.louissi.Alpha1.Global.Ressources_Sound_gun5_net.louissi.Alpha1.Global.Ressources_Sound_gun5.mp3")]
   public class Ressources_Sound_gun5 extends SoundAsset
   {
      
      public function Ressources_Sound_gun5()
      {
         super();
      }
   }
}

