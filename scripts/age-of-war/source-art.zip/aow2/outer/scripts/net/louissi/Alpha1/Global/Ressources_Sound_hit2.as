package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/6_net.louissi.Alpha1.Global.Ressources_Sound_hit2_net.louissi.Alpha1.Global.Ressources_Sound_hit2.mp3")]
   public class Ressources_Sound_hit2 extends SoundAsset
   {
      
      public function Ressources_Sound_hit2()
      {
         super();
      }
   }
}

