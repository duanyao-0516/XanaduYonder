package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/38_net.louissi.Alpha1.Global.Ressources_Sound_swish2_net.louissi.Alpha1.Global.Ressources_Sound_swish2.mp3")]
   public class Ressources_Sound_swish2 extends SoundAsset
   {
      
      public function Ressources_Sound_swish2()
      {
         super();
      }
   }
}

