package net.louissi.Alpha1.Computer
{
   import net.louissi.Alpha1.Global.GlobalVariables;
   import net.louissi.Alpha1.Hud.Hud;
   import net.louissi.Alpha1.Screens.GameScreen;
   
   public class AI
   {
      
      private var xmlData:XML;
      
      private var xmlAge:XML;
      
      private var events:Array;
      
      private var eventTimer:Number;
      
      private var unitTimerMax:Number;
      
      private var unitTimerMin:Number;
      
      private var unitTimer:Number;
      
      private var unitsAvail:Array;
      
      private var units:Array;
      
      private var hud:Hud;
      
      private var game:GameScreen;
      
      private var ageLoaded:Boolean;
      
      public function AI()
      {
         super();
         this.xmlData = GlobalVariables.xmlAI;
         this.hud = GlobalVariables.gameScreen.hud;
         this.game = GlobalVariables.gameScreen;
         this.ageLoaded = false;
      }
      
      public function loadAgeAI(param1:int) : void
      {
         var _loc2_:XML = null;
         trace("Loading new Age");
         this.events = new Array();
         this.xmlAge = this.xmlData.ai.age[param1 - 1];
         if(this.xmlAge)
         {
            for each(_loc2_ in this.xmlAge.event)
            {
               this.events.push(_loc2_);
            }
            this.nextEvent();
            this.ageLoaded = true;
         }
         else
         {
            trace("can find age xml");
         }
      }
      
      public function nextEvent() : void
      {
         var _loc1_:XMLList = null;
         var _loc2_:XML = null;
         var _loc3_:XMLList = null;
         var _loc4_:XML = null;
         var _loc5_:XML = null;
         var _loc6_:XMLList = null;
         var _loc7_:XML = null;
         if(this.events[0])
         {
            trace("next event");
            trace(this.events[0].build);
            this.units = new Array();
            _loc1_ = this.events[0].sell;
            for each(_loc2_ in _loc1_.turret)
            {
               this.game.turretsManager.aiSellTurret(int(_loc2_.@spot));
            }
            _loc3_ = this.events[0].build;
            for each(_loc4_ in _loc3_.tower)
            {
               this.hud.addTower(2);
            }
            for each(_loc2_ in _loc3_.turret)
            {
               this.game.turretsManager.createTurret(int(_loc2_.@id),2,int(_loc2_.@spot));
            }
            for each(_loc5_ in _loc3_.special)
            {
               this.game.createSpecial(2,GlobalVariables.ageCPU);
            }
            this.eventTimer = Number(this.events[0].@duration);
            this.unitTimerMax = Number(this.events[0].units.@max);
            this.unitTimerMin = Number(this.events[0].units.@min);
            this.unitTimer = this.getUnitTime();
            trace("event Timer:" + this.eventTimer);
            trace("unit Timer:" + this.unitTimer);
            _loc6_ = this.events[0].units;
            for each(_loc7_ in _loc6_.unit)
            {
               this.units.push(new Array(int(_loc7_.@id),Number(_loc7_.@ratio)));
               trace("unit id:" + _loc7_.@id + " ratio:" + _loc7_.@ratio);
            }
            this.events.shift();
         }
         else if(GlobalVariables.ageCPU < 7)
         {
            GlobalVariables.gameScreen.evolve(2);
            this.ageLoaded = false;
            this.loadAgeAI(GlobalVariables.ageCPU);
            trace("AI DONE");
         }
         else
         {
            trace("AI is soooo done");
         }
      }
      
      public function render(param1:Number) : void
      {
         if(this.ageLoaded)
         {
            this.eventTimer -= param1;
            this.unitTimer -= param1;
            if(this.eventTimer <= 0)
            {
               this.nextEvent();
            }
            if(this.unitTimer <= 0)
            {
               this.createUnit();
               this.unitTimer = this.getUnitTime();
            }
         }
      }
      
      public function createUnit() : void
      {
         var _loc3_:Array = null;
         var _loc4_:Boolean = false;
         var _loc5_:XML = null;
         var _loc1_:Number = Math.random();
         var _loc2_:Number = 0;
         for each(_loc3_ in this.units)
         {
            if(_loc1_ < _loc3_[1] + _loc2_)
            {
               _loc4_ = true;
               _loc5_ = GlobalVariables.xmlCPU.units.unit[_loc3_[0] - 1];
               if(Number(_loc5_.@pop) + GlobalVariables.popCPU > GlobalVariables.popMax)
               {
                  _loc4_ = false;
               }
               if(_loc4_)
               {
                  GlobalVariables.popCPU += Number(_loc5_.@pop);
                  trace("AI: create unit " + _loc3_[0]);
                  this.game.unitsManager.createUnit(_loc3_[0],2);
               }
               else
               {
                  trace("AI not enough pop");
               }
               break;
            }
            _loc2_ += _loc3_[1];
         }
      }
      
      public function getUnitTime() : Number
      {
         var _loc1_:Number = NaN;
         return Math.random() * (this.unitTimerMax - this.unitTimerMin) + this.unitTimerMin;
      }
      
      public function destroy() : void
      {
         this.xmlData = null;
         this.xmlAge = null;
         this.events = null;
         this.unitsAvail = null;
         this.units = null;
         this.hud = null;
         this.game = null;
      }
   }
}

