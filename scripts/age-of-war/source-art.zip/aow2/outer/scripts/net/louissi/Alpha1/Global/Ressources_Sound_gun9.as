package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/32_net.louissi.Alpha1.Global.Ressources_Sound_gun9_net.louissi.Alpha1.Global.Ressources_Sound_gun9.mp3")]
   public class Ressources_Sound_gun9 extends SoundAsset
   {
      
      public function Ressources_Sound_gun9()
      {
         super();
      }
   }
}

