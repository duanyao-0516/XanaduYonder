package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/17_net.louissi.Alpha1.Global.Ressources_Sound_explosion1_net.louissi.Alpha1.Global.Ressources_Sound_explosion1.mp3")]
   public class Ressources_Sound_explosion1 extends SoundAsset
   {
      
      public function Ressources_Sound_explosion1()
      {
         super();
      }
   }
}

