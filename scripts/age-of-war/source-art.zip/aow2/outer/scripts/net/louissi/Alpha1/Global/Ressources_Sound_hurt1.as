package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/47_net.louissi.Alpha1.Global.Ressources_Sound_hurt1_net.louissi.Alpha1.Global.Ressources_Sound_hurt1.mp3")]
   public class Ressources_Sound_hurt1 extends SoundAsset
   {
      
      public function Ressources_Sound_hurt1()
      {
         super();
      }
   }
}

