package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/29_net.louissi.Alpha1.Global.Ressources_Sound_arrow2_net.louissi.Alpha1.Global.Ressources_Sound_arrow2.mp3")]
   public class Ressources_Sound_arrow2 extends SoundAsset
   {
      
      public function Ressources_Sound_arrow2()
      {
         super();
      }
   }
}

