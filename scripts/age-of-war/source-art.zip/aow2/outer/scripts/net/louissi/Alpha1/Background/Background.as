package net.louissi.Alpha1.Background
{
   import flash.display.MovieClip;
   import flash.display.Sprite;
   import net.louissi.Alpha1.Global.GlobalVariables;
   import net.louissi.Moon.Animations.MovieClipAnimation;
   import net.louissi.Moon.Managers.AnimationManager;
   
   public class Background extends Sprite
   {
      
      public var displayBG:MovieClip;
      
      public var displayBases:MovieClip;
      
      private var buildButton1Anim:MovieClipAnimation;
      
      private var buildButton2Anim:MovieClipAnimation;
      
      private var buildButton3Anim:MovieClipAnimation;
      
      private var buildButton4Anim:MovieClipAnimation;
      
      public function Background()
      {
         super();
         var _loc1_:Class = GlobalVariables.backgrounds.loaderInfo.applicationDomain.getDefinition("backgrounds") as Class;
         this.displayBG = new _loc1_();
         addChild(this.displayBG);
         var _loc2_:Class = GlobalVariables.bases.loaderInfo.applicationDomain.getDefinition("bases") as Class;
         this.displayBases = new _loc2_();
         addChild(this.displayBases);
         this.buildButton1Anim = AnimationManager.getInstance().addAnimation(this.displayBases.btnBuildTurret1.cross,60);
         this.buildButton2Anim = AnimationManager.getInstance().addAnimation(this.displayBases.btnBuildTurret2.cross,60);
         this.buildButton3Anim = AnimationManager.getInstance().addAnimation(this.displayBases.btnBuildTurret3.cross,60);
         this.buildButton4Anim = AnimationManager.getInstance().addAnimation(this.displayBases.btnBuildTurret4.cross,60);
         this.buildButton1Anim.playLabel("move",true);
         this.buildButton2Anim.playLabel("move",true);
         this.buildButton3Anim.playLabel("move",true);
         this.buildButton4Anim.playLabel("move",true);
         var _loc3_:int = 1;
         while(_loc3_ <= 4)
         {
            this.displayBases.base1["t" + _loc3_].visible = false;
            this.displayBases.base2["t" + _loc3_].visible = false;
            _loc3_++;
         }
         this.updateTowers();
      }
      
      public function hideBuildTurretButtons() : void
      {
         this.displayBases.btnBuildTurret1.visible = false;
         this.displayBases.btnBuildTurret2.visible = false;
         this.displayBases.btnBuildTurret3.visible = false;
         this.displayBases.btnBuildTurret4.visible = false;
      }
      
      public function showBuildTurretButtons() : void
      {
         var _loc1_:int = 1;
         while(_loc1_ <= GlobalVariables.base1Spots)
         {
            this.displayBases["btnBuildTurret" + _loc1_].visible = !GlobalVariables["base1Spot" + _loc1_ + "Taken"];
            _loc1_++;
         }
      }
      
      public function setBG(param1:int, param2:int) : void
      {
         if(param1 > param2)
         {
            this.displayBG.gotoAndStop(param1);
         }
         else
         {
            this.displayBG.gotoAndStop(param2);
         }
      }
      
      public function setBases(param1:int, param2:int) : void
      {
         this.displayBases.base1.gotoAndStop(param1);
         this.displayBases.base1.t1.gotoAndStop(param1);
         this.displayBases.base1.t2.gotoAndStop(param1);
         this.displayBases.base1.t3.gotoAndStop(param1);
         this.displayBases.base1.t4.gotoAndStop(param1);
         this.displayBases.base2.gotoAndStop(param2);
         this.displayBases.base2.t1.gotoAndStop(param2);
         this.displayBases.base2.t2.gotoAndStop(param2);
         this.displayBases.base2.t3.gotoAndStop(param2);
         this.displayBases.base2.t4.gotoAndStop(param2);
      }
      
      public function updateTowers() : void
      {
         var _loc1_:int = 0;
         _loc1_ = 1;
         while(_loc1_ <= GlobalVariables.base1Spots)
         {
            this.displayBases.base1["t" + _loc1_].visible = true;
            _loc1_++;
         }
         _loc1_ = 1;
         while(_loc1_ <= GlobalVariables.base2Spots)
         {
            this.displayBases.base2["t" + _loc1_].visible = true;
            _loc1_++;
         }
      }
      
      public function destroy() : void
      {
         AnimationManager.getInstance().removeAnimation(this.buildButton1Anim);
         AnimationManager.getInstance().removeAnimation(this.buildButton2Anim);
         AnimationManager.getInstance().removeAnimation(this.buildButton3Anim);
         AnimationManager.getInstance().removeAnimation(this.buildButton4Anim);
         removeChild(this.displayBG);
         removeChild(this.displayBases);
         this.displayBG = null;
         this.displayBases = null;
      }
   }
}

