package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/21_net.louissi.Alpha1.Global.Ressources_Sound_hit7_net.louissi.Alpha1.Global.Ressources_Sound_hit7.mp3")]
   public class Ressources_Sound_hit7 extends SoundAsset
   {
      
      public function Ressources_Sound_hit7()
      {
         super();
      }
   }
}

