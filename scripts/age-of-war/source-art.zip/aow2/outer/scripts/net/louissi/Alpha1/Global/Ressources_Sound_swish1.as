package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/42_net.louissi.Alpha1.Global.Ressources_Sound_swish1_net.louissi.Alpha1.Global.Ressources_Sound_swish1.mp3")]
   public class Ressources_Sound_swish1 extends SoundAsset
   {
      
      public function Ressources_Sound_swish1()
      {
         super();
      }
   }
}

