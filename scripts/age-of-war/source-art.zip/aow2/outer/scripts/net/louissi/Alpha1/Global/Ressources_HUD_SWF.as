package net.louissi.Alpha1.Global
{
   import flash.utils.ByteArray;
   import mx.core.MovieClipLoaderAsset;
   
   [Embed(source="/_assets/assets.swf", symbol="symbol1")]
   public class Ressources_HUD_SWF extends MovieClipLoaderAsset
   {
      
      private static var bytes:ByteArray = null;
      
      public var dataClass:Class = Ressources_HUD_SWF_dataClass;
      
      public function Ressources_HUD_SWF()
      {
         super();
         initialWidth = 10000 / 20;
         initialHeight = 6000 / 20;
      }
      
      override public function get movieClipData() : ByteArray
      {
         if(bytes == null)
         {
            bytes = ByteArray(new this.dataClass());
         }
         return bytes;
      }
   }
}

