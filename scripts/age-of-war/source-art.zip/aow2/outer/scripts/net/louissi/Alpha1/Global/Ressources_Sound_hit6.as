package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/23_net.louissi.Alpha1.Global.Ressources_Sound_hit6_net.louissi.Alpha1.Global.Ressources_Sound_hit6.mp3")]
   public class Ressources_Sound_hit6 extends SoundAsset
   {
      
      public function Ressources_Sound_hit6()
      {
         super();
      }
   }
}

