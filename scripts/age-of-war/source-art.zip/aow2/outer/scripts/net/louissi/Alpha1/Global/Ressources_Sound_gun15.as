package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/13_net.louissi.Alpha1.Global.Ressources_Sound_gun15_net.louissi.Alpha1.Global.Ressources_Sound_gun15.mp3")]
   public class Ressources_Sound_gun15 extends SoundAsset
   {
      
      public function Ressources_Sound_gun15()
      {
         super();
      }
   }
}

