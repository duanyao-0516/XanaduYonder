package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/25_net.louissi.Alpha1.Global.Ressources_Sound_hit5_net.louissi.Alpha1.Global.Ressources_Sound_hit5.mp3")]
   public class Ressources_Sound_hit5 extends SoundAsset
   {
      
      public function Ressources_Sound_hit5()
      {
         super();
      }
   }
}

