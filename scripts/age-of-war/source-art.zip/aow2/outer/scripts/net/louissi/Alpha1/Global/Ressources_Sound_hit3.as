package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/3_net.louissi.Alpha1.Global.Ressources_Sound_hit3_net.louissi.Alpha1.Global.Ressources_Sound_hit3.mp3")]
   public class Ressources_Sound_hit3 extends SoundAsset
   {
      
      public function Ressources_Sound_hit3()
      {
         super();
      }
   }
}

