package net.louissi.Alpha1.Global
{
   public class Ressources_AI_CLASS
   {
      
      public static var data:XML = <ageOfWar>
	<ai>
		<age>
			<event duration="20">
				<units min="2" max="5">
					<unit id="1" ratio="0.5"/>
					<unit id="2" ratio="0.5"/>
				</units>
				<build>
					<tower/>
					<turret spot="1" id="1"/>
				</build>
				<sell>
				</sell>
			</event>
			
			<event duration="30">
				<units min="2" max="5">
					<unit id="1" ratio="0.4"/>
					<unit id="2" ratio="0.4"/>
					<unit id="3" ratio="0.2"/>
				</units>
				<build>
					<special/>
				</build>
				<sell>
				</sell>
			</event>
			
			<event duration="40">
				<units min="3" max="6">
					<unit id="1" ratio="0.333"/>
					<unit id="2" ratio="0.333"/>
					<unit id="3" ratio="0.333"/>
				</units>
				<build>
				</build>
				<sell>
				</sell>
			</event>
			
			<event duration="75">
				<units min="4" max="6">
					<unit id="1" ratio="0.2"/>
					<unit id="2" ratio="0.3"/>
					<unit id="3" ratio="0.3"/>
					<unit id="4" ratio="0.2"/>
				</units>
				<build>
				</build>
				<sell>
				</sell>
			</event>
		</age>
		<age>
			<event duration="25">
				<units min="3" max="6">
					<unit id="5" ratio="0.7"/>
					<unit id="6" ratio="0.3"/>
				</units>
				<build>
					<tower/>
				</build>
				<sell>
				</sell>
			</event>
			<event duration="30">
				<units min="4" max="8">
					<unit id="5" ratio="0.4"/>
					<unit id="6" ratio="0.4"/>
					<unit id="7" ratio="0.2"/>
				</units>
				<build>
					<turret spot="2" id="4"/>
				</build>
				<sell>
				</sell>
			</event>
			<event duration="50">
				<units min="3" max="6">
					<unit id="5" ratio="0.333"/>
					<unit id="6" ratio="0.333"/>
					<unit id="7" ratio="0.333"/>
				</units>
				<build>
					<special/>
				</build>
				<sell>
				</sell>
			</event>
			<event duration="50">
				<units min="5" max="8">
					<unit id="6" ratio="0.3"/>
					<unit id="7" ratio="0.7"/>
				</units>
				<build>
				</build>
				<sell>
					<turret spot="1"/>
				</sell>
			</event>
			<event duration="50">
				<units min="3" max="6">
					<unit id="5" ratio="0.2"/>
					<unit id="6" ratio="0.2"/>
					<unit id="7" ratio="0.2"/>
					<unit id="8" ratio="0.4"/>
				</units>
				<build>
				</build>
				<sell>
				</sell>
			</event>
		</age>
		<age>
			<event duration="45">
				<units min="3" max="6">
					<unit id="10" ratio="1"/>
				</units>
				<build>
					<turret spot="1" id="5"/>
				</build>
				<sell>
				</sell>
			</event>
			<event duration="80">
				<units min="4" max="8">
					<unit id="9" ratio="0.4"/>
					<unit id="10" ratio="0.4"/>
					<unit id="11" ratio="0.2"/>
				</units>
				<build>
				</build>
				<sell>
				</sell>
			</event>
			<event duration="50">
				<units min="3" max="6">
					<unit id="9" ratio="0.333"/>
					<unit id="10" ratio="0.333"/>
					<unit id="12" ratio="0.333"/>
				</units>
				<build>
					<turret spot="2" id="5"/>
					<special/>
				</build>
				<sell>
					<turret spot="2"/>
				</sell>
			</event>
			<event duration="50">
				<units min="5" max="8">
					<unit id="12" ratio="0.3"/>
					<unit id="9" ratio="0.7"/>
				</units>
				<build>
				</build>
				<sell>
				</sell>
			</event>
			<event duration="50">
				<units min="3" max="6">
					<unit id="9" ratio="0.2"/>
					<unit id="10" ratio="0.2"/>
					<unit id="11" ratio="0.2"/>
					<unit id="12" ratio="0.4"/>
				</units>
				<build>
				</build>
				<sell>
				</sell>
			</event>
		</age>
		<age>
			<event duration="45">
				<units min="3" max="6">
					<unit id="13" ratio="1"/>
				</units>
				<build>
				</build>
				<sell>
				</sell>
			</event>
			<event duration="80">
				<units min="4" max="8">
					<unit id="13" ratio="0.4"/>
					<unit id="14" ratio="0.4"/>
					<unit id="15" ratio="0.2"/>
				</units>
				<build>
					<turret spot="1" id="7"/>
				</build>
				<sell>
					<turret spot="1"/>
				</sell>
			</event>
			<event duration="100">
				<units min="3" max="6">
					<unit id="13" ratio="0.333"/>
					<unit id="16" ratio="0.333"/>
					<unit id="15" ratio="0.333"/>
				</units>
				<build>
					<turret spot="2" id="8"/>
					<special/>
				</build>
				<sell>
					<turret spot="2"/>
				</sell>
			</event>
			<event duration="50">
				<units min="5" max="8">
					<unit id="14" ratio="0.3"/>
					<unit id="13" ratio="0.7"/>
				</units>
				<build>
				</build>
				<sell>
				</sell>
			</event>
			<event duration="50">
				<units min="3" max="6">
					<unit id="13" ratio="0.2"/>
					<unit id="14" ratio="0.2"/>
					<unit id="15" ratio="0.2"/>
					<unit id="16" ratio="0.4"/>
				</units>
				<build>
					<tower/>
				</build>
				<sell>
				</sell>
			</event>
		</age>
		<age>
			<event duration="45">
				<units min="3" max="6">
					<unit id="17" ratio="1"/>
				</units>
				<build>
				</build>
				<sell>
				</sell>
			</event>
			<event duration="40">
				<units min="4" max="8">
					<unit id="17" ratio="0.4"/>
					<unit id="18" ratio="0.4"/>
					<unit id="19" ratio="0.2"/>
				</units>
				<build>
					<turret spot="1" id="10"/>
				</build>
				<sell>
					<turret spot="1"/>
				</sell>
			</event>
			<event duration="80">
				<units min="3" max="6">
					<unit id="17" ratio="0.333"/>
					<unit id="18" ratio="0.333"/>
					<unit id="19" ratio="0.333"/>
				</units>
				<build>
					<turret spot="2" id="11"/>
					<special/>
				</build>
				<sell>
					<turret spot="2"/>
				</sell>
			</event>
			<event duration="70">
				<units min="3" max="6">
					<unit id="17" ratio="0.2"/>
					<unit id="18" ratio="0.2"/>
					<unit id="19" ratio="0.2"/>
					<unit id="20" ratio="0.4"/>
				</units>
				<build>
				<turret spot="3" id="10"/>
				</build>
				<sell>
				</sell>
			</event>
		</age>
		<age>
			<event duration="45">
				<units min="3" max="6">
					<unit id="21" ratio="1"/>
				</units>
				<build>
				</build>
				<sell>
				</sell>
			</event>
			<event duration="40">
				<units min="4" max="8">
					<unit id="21" ratio="0.4"/>
					<unit id="22" ratio="0.4"/>
					<unit id="23" ratio="0.2"/>
				</units>
				<build>
					<turret spot="1" id="12"/>
				</build>
				<sell>
					<turret spot="1"/>
				</sell>
			</event>
			<event duration="80">
				<units min="3" max="6">
					<unit id="21" ratio="0.333"/>
					<unit id="22" ratio="0.333"/>
					<unit id="24" ratio="0.333"/>
				</units>
				<build>
					<turret spot="2" id="13"/>
					<special/>
				</build>
				<sell>
					<turret spot="2"/>
				</sell>
			</event>
			<event duration="70">
				<units min="3" max="6">
					<unit id="21" ratio="0.2"/>
					<unit id="22" ratio="0.4"/>
					<unit id="23" ratio="0.2"/>
					<unit id="24" ratio="0.2"/>
				</units>
				<build>
					<turret spot="3" id="14"/>
				</build>
				<sell>
					<turret spot="3"/>
				</sell>
			</event>
		</age>
		<age>
			<event duration="45">
				<units min="3" max="6">
					<unit id="26" ratio="1"/>
				</units>
				<build>
				</build>
				<sell>
				</sell>
			</event>
			<event duration="40">
				<units min="4" max="8">
					<unit id="25" ratio="0.4"/>
					<unit id="26" ratio="0.4"/>
					<unit id="27" ratio="0.2"/>
				</units>
				<build>
					<turret spot="1" id="15"/>
				</build>
				<sell>
					<turret spot="1"/>
				</sell>
			</event>
			<event duration="80">
				<units min="3" max="6">
					<unit id="25" ratio="0.333"/>
					<unit id="27" ratio="0.333"/>
					<unit id="28" ratio="0.333"/>
				</units>
				<build>
					<turret spot="2" id="16"/>
					<special/>
				</build>
				<sell>
					<turret spot="2"/>
				</sell>
			</event>
			<event duration="70">
				<units min="3" max="6">
					<unit id="25" ratio="0.2"/>
					<unit id="26" ratio="0.4"/>
					<unit id="27" ratio="0.2"/>
					<unit id="28" ratio="0.2"/>
				</units>
				<build>
					<tower/>
					<turret spot="3" id="17"/>
				</build>
				<sell>
					<turret spot="3"/>
				</sell>
			</event>
			<event duration="70">
				<units min="3" max="6">
					<unit id="25" ratio="0.25"/>
					<unit id="26" ratio="0.25"/>
					<unit id="27" ratio="0.2"/>
					<unit id="28" ratio="0.3"/>
				</units>
				<build>
					<turret spot="4" id="17"/>
				</build>
				<sell>
				</sell>
			</event>
			<event duration="70">
				<units min="3" max="6">
					<unit id="25" ratio="0.25"/>
					<unit id="26" ratio="0.25"/>
					<unit id="27" ratio="0.2"/>
					<unit id="28" ratio="0.3"/>
				</units>
				<build>
					<turret spot="1" id="17"/>
				</build>
				<sell>
					<turret spot="1"/>
				</sell>
			</event>
		</age>
	</ai>
</ageOfWar>;
      
      public function Ressources_AI_CLASS()
      {
         super();
      }
   }
}

