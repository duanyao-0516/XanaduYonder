package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/40_net.louissi.Alpha1.Global.Ressources_Music1_net.louissi.Alpha1.Global.Ressources_Music1.mp3")]
   public class Ressources_Music1 extends SoundAsset
   {
      
      public function Ressources_Music1()
      {
         super();
      }
   }
}

