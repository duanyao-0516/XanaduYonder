package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/15_net.louissi.Alpha1.Global.Ressources_Sound_rocketLaunch_net.louissi.Alpha1.Global.Ressources_Sound_rocketLaunch.mp3")]
   public class Ressources_Sound_rocketLaunch extends SoundAsset
   {
      
      public function Ressources_Sound_rocketLaunch()
      {
         super();
      }
   }
}

