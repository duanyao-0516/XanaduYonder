package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/35_net.louissi.Alpha1.Global.Ressources_Sound_gun6_net.louissi.Alpha1.Global.Ressources_Sound_gun6.mp3")]
   public class Ressources_Sound_gun6 extends SoundAsset
   {
      
      public function Ressources_Sound_gun6()
      {
         super();
      }
   }
}

