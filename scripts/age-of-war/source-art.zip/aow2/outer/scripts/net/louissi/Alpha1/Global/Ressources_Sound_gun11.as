package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/9_net.louissi.Alpha1.Global.Ressources_Sound_gun11_net.louissi.Alpha1.Global.Ressources_Sound_gun11.mp3")]
   public class Ressources_Sound_gun11 extends SoundAsset
   {
      
      public function Ressources_Sound_gun11()
      {
         super();
      }
   }
}

