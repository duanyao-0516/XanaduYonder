package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/5_net.louissi.Alpha1.Global.Ressources_Sound_hit1_net.louissi.Alpha1.Global.Ressources_Sound_hit1.mp3")]
   public class Ressources_Sound_hit1 extends SoundAsset
   {
      
      public function Ressources_Sound_hit1()
      {
         super();
      }
   }
}

