package net.louissi.Alpha1.Global
{
   import flash.display.MovieClip;
   import net.louissi.Alpha1.Screens.GameScreen;
   
   public class GlobalVariables
   {
      
      public static var xmlPlayer:XML;
      
      public static var xmlCPU:XML;
      
      public static var xmlAI:XML;
      
      public static var age:int;
      
      public static var ageCPU:int;
      
      public static var age1Units:MovieClip;
      
      public static var age2Units:MovieClip;
      
      public static var age3Units:MovieClip;
      
      public static var age4Units:MovieClip;
      
      public static var age5Units:MovieClip;
      
      public static var age6Units:MovieClip;
      
      public static var age7Units:MovieClip;
      
      public static var age1Turrets:MovieClip;
      
      public static var age2Turrets:MovieClip;
      
      public static var age3Turrets:MovieClip;
      
      public static var age4Turrets:MovieClip;
      
      public static var age5Turrets:MovieClip;
      
      public static var age6Turrets:MovieClip;
      
      public static var age7Turrets:MovieClip;
      
      public static var backgrounds:MovieClip;
      
      public static var bases:MovieClip;
      
      public static var projectiles:MovieClip;
      
      public static var particules:MovieClip;
      
      public static var gameScreen:GameScreen;
      
      public static var isPaused:Boolean;
      
      public static var gameSpeed:Number;
      
      public static var gameFPS:Number;
      
      public static var gameSoundVolume:Number;
      
      public static var gameMusicVolume:Number;
      
      public static var gameQuality:String;
      
      public static var onMaxGames:Boolean;
      
      public static var money:int = 30000;
      
      public static var pop:int = 0;
      
      public static var popCPU:int = 0;
      
      public static var popMax:int = 10;
      
      public static var xp:int = 300000;
      
      public static var unitMaxQueue:int = 4;
      
      public static var base1x:int = -580;
      
      public static var base1y:int = 0;
      
      public static var base2x:int = 580;
      
      public static var base2y:int = 0;
      
      public static var base1Spots:int = 0;
      
      public static var base2Spots:int = 0;
      
      public static var base1NbTurrets:int = 0;
      
      public static var base1Spot1Taken:Boolean = false;
      
      public static var base1Spot2Taken:Boolean = false;
      
      public static var base1Spot3Taken:Boolean = false;
      
      public static var base1Spot4Taken:Boolean = false;
      
      public static var base2NbTurrets:int = 0;
      
      public static var base2Spot1Taken:Boolean = false;
      
      public static var base2Spot2Taken:Boolean = false;
      
      public static var base2Spot3Taken:Boolean = false;
      
      public static var base2Spot4Taken:Boolean = false;
      
      public static var baseTurret1Y:int = -146;
      
      public static var baseTurret2Y:int = -193;
      
      public static var baseTurret3Y:int = -240;
      
      public static var baseTurret4Y:int = -287;
      
      public static var base1TurretX:int = -624;
      
      public static var base2TurretX:int = 620;
      
      public static var base1Hp:int = 200;
      
      public static var base1HpMax:int = base1Hp;
      
      public static var base2Hp:int = 200;
      
      public static var base2HpMax:int = base1Hp;
      
      public static var camY:int = 390;
      
      public static var showDamage:Boolean = false;
      
      public static var difficulty:Number = 1;
      
      public static const FPS_MAX:int = 300;
      
      public static const FPS_MIN:int = 25;
      
      public function GlobalVariables()
      {
         super();
      }
   }
}

