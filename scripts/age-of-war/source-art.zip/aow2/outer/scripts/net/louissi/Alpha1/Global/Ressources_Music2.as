package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/37_net.louissi.Alpha1.Global.Ressources_Music2_net.louissi.Alpha1.Global.Ressources_Music2.mp3")]
   public class Ressources_Music2 extends SoundAsset
   {
      
      public function Ressources_Music2()
      {
         super();
      }
   }
}

