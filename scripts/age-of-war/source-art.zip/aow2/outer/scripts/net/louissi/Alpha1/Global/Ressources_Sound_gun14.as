package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/12_net.louissi.Alpha1.Global.Ressources_Sound_gun14_net.louissi.Alpha1.Global.Ressources_Sound_gun14.mp3")]
   public class Ressources_Sound_gun14 extends SoundAsset
   {
      
      public function Ressources_Sound_gun14()
      {
         super();
      }
   }
}

