package net.louissi.Alpha1.Global
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/69_net.louissi.Alpha1.Global.Ressources_GAMESCREEN_SWF_dataClass.bin", mimeType="application/octet-stream")]
   public class Ressources_GAMESCREEN_SWF_dataClass extends ByteArrayAsset
   {
      
      public function Ressources_GAMESCREEN_SWF_dataClass()
      {
         super();
      }
   }
}

