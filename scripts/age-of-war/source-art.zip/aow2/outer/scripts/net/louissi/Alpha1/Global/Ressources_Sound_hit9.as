package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/18_net.louissi.Alpha1.Global.Ressources_Sound_hit9_net.louissi.Alpha1.Global.Ressources_Sound_hit9.mp3")]
   public class Ressources_Sound_hit9 extends SoundAsset
   {
      
      public function Ressources_Sound_hit9()
      {
         super();
      }
   }
}

