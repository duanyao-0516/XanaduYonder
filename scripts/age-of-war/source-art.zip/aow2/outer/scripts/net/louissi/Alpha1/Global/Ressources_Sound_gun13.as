package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/11_net.louissi.Alpha1.Global.Ressources_Sound_gun13_net.louissi.Alpha1.Global.Ressources_Sound_gun13.mp3")]
   public class Ressources_Sound_gun13 extends SoundAsset
   {
      
      public function Ressources_Sound_gun13()
      {
         super();
      }
   }
}

