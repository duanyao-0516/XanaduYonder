package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/52_net.louissi.Alpha1.Global.Ressources_Sound_lightning3_net.louissi.Alpha1.Global.Ressources_Sound_lightning3.mp3")]
   public class Ressources_Sound_lightning3 extends SoundAsset
   {
      
      public function Ressources_Sound_lightning3()
      {
         super();
      }
   }
}

