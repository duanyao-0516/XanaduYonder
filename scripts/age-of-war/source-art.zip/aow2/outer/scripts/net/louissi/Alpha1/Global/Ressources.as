package net.louissi.Alpha1.Global
{
   public final class Ressources
   {
      
      public static var MAINMENU_SWF:Class = Ressources_MAINMENU_SWF;
      
      public static const MAINMENU_PATH:String = "assets/swf/screens/mainMenu.swf";
      
      public static var SPONSOR_SWF:Class = Ressources_SPONSOR_SWF;
      
      public static const SPONSOR_PATH:String = "assets/swf/screens/sponsor.swf";
      
      public static var DIFFICULTY_SWF:Class = Ressources_DIFFICULTY_SWF;
      
      public static const DIFFICULTY_PATH:String = "assets/swf/screens/difficulty.swf";
      
      public static var AUTHOR_SWF:Class = Ressources_AUTHOR_SWF;
      
      public static const AUTHOR_PATH:String = "assets/swf/screens/author.swf";
      
      public static var VICTORY_SWF:Class = Ressources_VICTORY_SWF;
      
      public static const VICTORY_PATH:String = "assets/swf/screens/victory.swf";
      
      public static var DEFEAT_SWF:Class = Ressources_DEFEAT_SWF;
      
      public static const DEFEAT_PATH:String = "assets/swf/screens/defeat.swf";
      
      public static var OPTIONS_SWF:Class = Ressources_OPTIONS_SWF;
      
      public static const OPTIONS_PATH:String = "assets/swf/screens/options.swf";
      
      public static var CREDITS_SWF:Class = Ressources_CREDITS_SWF;
      
      public static const CREDITS_PATH:String = "assets/swf/screens/credits.swf";
      
      public static var GAMESCREEN_SWF:Class = Ressources_GAMESCREEN_SWF;
      
      public static const GAMESCREEN_PATH:String = "assets/swf/screens/GameScreen.swf";
      
      public static var HUD_SWF:Class = Ressources_HUD_SWF;
      
      public static const HUD_PATH:String = "assets/swf/hud/hud.swf";
      
      public static var WINDOWS_SWF:Class = Ressources_WINDOWS_SWF;
      
      public static const WINDOWS_PATH:String = "assets/swf/hud/windows.swf";
      
      public static var DATA_CLASS:Class = Ressources_DATA_CLASS;
      
      public static const DATA_PATH:String = "assets/data/data.xml";
      
      public static var AI_CLASS:Class = Ressources_AI_CLASS;
      
      public static const AI_PATH:String = "assets/data/AI.xml";
      
      public static var BACKGROUNDS_SWF:Class = Ressources_BACKGROUNDS_SWF;
      
      public static const BACKGROUNDS_PATH:String = "assets/swf/backgrounds/backgrounds.swf";
      
      public static var PROJECTILES_SWF:Class = Ressources_PROJECTILES_SWF;
      
      public static const PROJECTILES_PATH:String = "assets/swf/particules/projectiles.swf";
      
      public static var PARTICULES_SWF:Class = Ressources_PARTICULES_SWF;
      
      public static const PARTICULES_PATH:String = "assets/swf/particules/particules.swf";
      
      public static var BASES_SWF:Class = Ressources_BASES_SWF;
      
      public static const BASES_PATH:String = "assets/swf/backgrounds/bases.swf";
      
      public static var AGE1_UNITS_SWF:Class = Ressources_AGE1_UNITS_SWF;
      
      public static const AGE1_UNITS_PATH:String = "assets/swf/units/u1.swf";
      
      public static var AGE1_TURRETS_SWF:Class = Ressources_AGE1_TURRETS_SWF;
      
      public static const AGE1_TURRETS_PATH:String = "assets/swf/turrets/t1.swf";
      
      public static var AGE2_UNITS_SWF:Class = Ressources_AGE2_UNITS_SWF;
      
      public static const AGE2_UNITS_PATH:String = "assets/swf/units/u2.swf";
      
      public static var AGE2_TURRETS_SWF:Class = Ressources_AGE2_TURRETS_SWF;
      
      public static const AGE2_TURRETS_PATH:String = "assets/swf/turrets/t2.swf";
      
      public static var AGE3_UNITS_SWF:Class = Ressources_AGE3_UNITS_SWF;
      
      public static const AGE3_UNITS_PATH:String = "assets/swf/units/u3.swf";
      
      public static var AGE3_TURRETS_SWF:Class = Ressources_AGE3_TURRETS_SWF;
      
      public static const AGE3_TURRETS_PATH:String = "assets/swf/turrets/t3.swf";
      
      public static var AGE4_UNITS_SWF:Class = Ressources_AGE4_UNITS_SWF;
      
      public static const AGE4_UNITS_PATH:String = "assets/swf/units/u4.swf";
      
      public static var AGE4_TURRETS_SWF:Class = Ressources_AGE4_TURRETS_SWF;
      
      public static const AGE4_TURRETS_PATH:String = "assets/swf/turrets/t4.swf";
      
      public static var AGE5_UNITS_SWF:Class = Ressources_AGE5_UNITS_SWF;
      
      public static const AGE5_UNITS_PATH:String = "assets/swf/units/u5.swf";
      
      public static var AGE5_TURRETS_SWF:Class = Ressources_AGE5_TURRETS_SWF;
      
      public static const AGE5_TURRETS_PATH:String = "assets/swf/turrets/t5.swf";
      
      public static var AGE6_UNITS_SWF:Class = Ressources_AGE6_UNITS_SWF;
      
      public static const AGE6_UNITS_PATH:String = "assets/swf/units/u6.swf";
      
      public static var AGE6_TURRETS_SWF:Class = Ressources_AGE6_TURRETS_SWF;
      
      public static const AGE6_TURRETS_PATH:String = "assets/swf/turrets/t6.swf";
      
      public static var AGE7_UNITS_SWF:Class = Ressources_AGE7_UNITS_SWF;
      
      public static const AGE7_UNITS_PATH:String = "assets/swf/units/u7.swf";
      
      public static var AGE7_TURRETS_SWF:Class = Ressources_AGE7_TURRETS_SWF;
      
      public static const AGE7_TURRETS_PATH:String = "assets/swf/turrets/t7.swf";
      
      public static const AGE1:int = 0;
      
      public static const AGE2:int = 1;
      
      public static const AGE3:int = 2;
      
      public static const AGE4:int = 3;
      
      public static const AGE5:int = 4;
      
      public static const AGE6:int = 5;
      
      public static const AGE7:int = 6;
      
      public static const AGES:int = 7;
      
      public static var UNITS:Array = new Array(AGES);
      
      public static var TURRETS:Array = new Array(AGES);
      
      public static var Sound_explosion1:Class = Ressources_Sound_explosion1;
      
      public static var Sound_explosion2:Class = Ressources_Sound_explosion2;
      
      public static var Sound_explosion4:Class = Ressources_Sound_explosion4;
      
      public static var Sound_explosion5:Class = Ressources_Sound_explosion5;
      
      public static var Sound_explosion6:Class = Ressources_Sound_explosion6;
      
      public static var Sound_hit1:Class = Ressources_Sound_hit1;
      
      public static var Sound_hit2:Class = Ressources_Sound_hit2;
      
      public static var Sound_hit3:Class = Ressources_Sound_hit3;
      
      public static var Sound_hit4:Class = Ressources_Sound_hit4;
      
      public static var Sound_hit5:Class = Ressources_Sound_hit5;
      
      public static var Sound_hit6:Class = Ressources_Sound_hit6;
      
      public static var Sound_hit7:Class = Ressources_Sound_hit7;
      
      public static var Sound_hit8:Class = Ressources_Sound_hit8;
      
      public static var Sound_hit9:Class = Ressources_Sound_hit9;
      
      public static var Sound_hurt1:Class = Ressources_Sound_hurt1;
      
      public static var Sound_hurt2:Class = Ressources_Sound_hurt2;
      
      public static var Sound_hurt3:Class = Ressources_Sound_hurt3;
      
      public static var Sound_hurt4:Class = Ressources_Sound_hurt4;
      
      public static var Sound_hurt5:Class = Ressources_Sound_hurt5;
      
      public static var Sound_hurt6:Class = Ressources_Sound_hurt6;
      
      public static var Sound_hurt7:Class = Ressources_Sound_hurt7;
      
      public static var Sound_hurt8:Class = Ressources_Sound_hurt8;
      
      public static var Sound_hurt9:Class = Ressources_Sound_hurt9;
      
      public static var Sound_hurt10:Class = Ressources_Sound_hurt10;
      
      public static var Sound_gun1:Class = Ressources_Sound_gun1;
      
      public static var Sound_gun2:Class = Ressources_Sound_gun2;
      
      public static var Sound_gun3:Class = Ressources_Sound_gun3;
      
      public static var Sound_gun4:Class = Ressources_Sound_gun4;
      
      public static var Sound_gun5:Class = Ressources_Sound_gun5;
      
      public static var Sound_gun6:Class = Ressources_Sound_gun6;
      
      public static var Sound_gun7:Class = Ressources_Sound_gun7;
      
      public static var Sound_gun8:Class = Ressources_Sound_gun8;
      
      public static var Sound_gun9:Class = Ressources_Sound_gun9;
      
      public static var Sound_gun10:Class = Ressources_Sound_gun10;
      
      public static var Sound_gun11:Class = Ressources_Sound_gun11;
      
      public static var Sound_gun12:Class = Ressources_Sound_gun12;
      
      public static var Sound_gun13:Class = Ressources_Sound_gun13;
      
      public static var Sound_gun14:Class = Ressources_Sound_gun14;
      
      public static var Sound_gun15:Class = Ressources_Sound_gun15;
      
      public static var Sound_sword1:Class = Ressources_Sound_sword1;
      
      public static var Sound_sword2:Class = Ressources_Sound_sword2;
      
      public static var Sound_swish1:Class = Ressources_Sound_swish1;
      
      public static var Sound_swish2:Class = Ressources_Sound_swish2;
      
      public static var Sound_swish3:Class = Ressources_Sound_swish3;
      
      public static var Sound_swish4:Class = Ressources_Sound_swish4;
      
      public static var Sound_fireball:Class = Ressources_Sound_fireball;
      
      public static var Sound_lightning:Class = Ressources_Sound_lightning;
      
      public static var Sound_lightning2:Class = Ressources_Sound_lightning2;
      
      public static var Sound_lightning3:Class = Ressources_Sound_lightning3;
      
      public static var Sound_rocketLaunch:Class = Ressources_Sound_rocketLaunch;
      
      public static var Sound_arrow1:Class = Ressources_Sound_arrow1;
      
      public static var Sound_arrow2:Class = Ressources_Sound_arrow2;
      
      public static var Music1:Class = Ressources_Music1;
      
      public static var Music2:Class = Ressources_Music2;
      
      UNITS[AGE1] = new Array(AGE1_UNITS_SWF,AGE1_UNITS_PATH);
      UNITS[AGE2] = new Array(AGE2_UNITS_SWF,AGE2_UNITS_PATH);
      UNITS[AGE3] = new Array(AGE3_UNITS_SWF,AGE3_UNITS_PATH);
      UNITS[AGE4] = new Array(AGE4_UNITS_SWF,AGE4_UNITS_PATH);
      UNITS[AGE5] = new Array(AGE5_UNITS_SWF,AGE5_UNITS_PATH);
      UNITS[AGE6] = new Array(AGE6_UNITS_SWF,AGE6_UNITS_PATH);
      UNITS[AGE7] = new Array(AGE7_UNITS_SWF,AGE7_UNITS_PATH);
      TURRETS[AGE1] = new Array(AGE1_TURRETS_SWF,AGE1_TURRETS_PATH);
      TURRETS[AGE2] = new Array(AGE2_TURRETS_SWF,AGE2_TURRETS_PATH);
      TURRETS[AGE3] = new Array(AGE3_TURRETS_SWF,AGE3_TURRETS_PATH);
      TURRETS[AGE4] = new Array(AGE4_TURRETS_SWF,AGE4_TURRETS_PATH);
      TURRETS[AGE5] = new Array(AGE5_TURRETS_SWF,AGE5_TURRETS_PATH);
      TURRETS[AGE6] = new Array(AGE6_TURRETS_SWF,AGE6_TURRETS_PATH);
      TURRETS[AGE7] = new Array(AGE7_TURRETS_SWF,AGE7_TURRETS_PATH);
      
      public function Ressources()
      {
         super();
      }
   }
}

