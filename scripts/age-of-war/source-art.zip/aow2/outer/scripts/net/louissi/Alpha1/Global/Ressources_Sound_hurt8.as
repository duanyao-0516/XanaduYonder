package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/46_net.louissi.Alpha1.Global.Ressources_Sound_hurt8_net.louissi.Alpha1.Global.Ressources_Sound_hurt8.mp3")]
   public class Ressources_Sound_hurt8 extends SoundAsset
   {
      
      public function Ressources_Sound_hurt8()
      {
         super();
      }
   }
}

