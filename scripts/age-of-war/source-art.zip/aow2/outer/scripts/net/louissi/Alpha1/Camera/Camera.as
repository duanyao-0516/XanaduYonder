package net.louissi.Alpha1.Camera
{
   import flash.display.Sprite;
   import net.louissi.Moon.Global.GlobalVars;
   
   public class Camera
   {
      
      private const XMIN:Number = -180;
      
      private const XMAX:Number = 900;
      
      private var camx:Number = 0;
      
      private var camy:Number = 0;
      
      private const BUFFER:Number = 100;
      
      private var display:Sprite;
      
      public function Camera(param1:Sprite)
      {
         super();
         this.display = param1;
      }
      
      public function render(param1:Number) : void
      {
         var _loc2_:Number = 0;
         var _loc3_:Number = GlobalVars.stage.mouseX;
         var _loc4_:Number = GlobalVars.stage.mouseY;
         if(_loc4_ > 75 && _loc4_ < 460)
         {
            if(_loc3_ > GlobalVars.stageWidth - this.BUFFER)
            {
               _loc2_ = _loc3_ - (GlobalVars.stageWidth - this.BUFFER);
               if(this.display.x - _loc2_ * param1 * 15 > this.XMIN)
               {
                  this.display.x -= _loc2_ * param1 * 15;
               }
               else
               {
                  this.display.x = this.XMIN;
               }
            }
            else if(_loc3_ < this.BUFFER)
            {
               _loc2_ = this.BUFFER - _loc3_;
               if(this.display.x + _loc2_ * param1 * 15 < this.XMAX)
               {
                  this.display.x += _loc2_ * param1 * 15;
               }
               else
               {
                  this.display.x = this.XMAX;
               }
            }
         }
         this.display.x = Math.round(this.display.x);
      }
      
      public function setX(param1:Number) : void
      {
         this.display.x = param1;
      }
   }
}

