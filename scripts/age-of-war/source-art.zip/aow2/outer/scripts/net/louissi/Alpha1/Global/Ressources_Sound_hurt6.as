package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/44_net.louissi.Alpha1.Global.Ressources_Sound_hurt6_net.louissi.Alpha1.Global.Ressources_Sound_hurt6.mp3")]
   public class Ressources_Sound_hurt6 extends SoundAsset
   {
      
      public function Ressources_Sound_hurt6()
      {
         super();
      }
   }
}

