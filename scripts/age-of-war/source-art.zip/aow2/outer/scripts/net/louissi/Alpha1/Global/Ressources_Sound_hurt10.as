package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/36_net.louissi.Alpha1.Global.Ressources_Sound_hurt10_net.louissi.Alpha1.Global.Ressources_Sound_hurt10.mp3")]
   public class Ressources_Sound_hurt10 extends SoundAsset
   {
      
      public function Ressources_Sound_hurt10()
      {
         super();
      }
   }
}

