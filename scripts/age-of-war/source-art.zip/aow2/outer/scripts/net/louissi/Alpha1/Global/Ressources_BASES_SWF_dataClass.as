package net.louissi.Alpha1.Global
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/57_net.louissi.Alpha1.Global.Ressources_BASES_SWF_dataClass.bin", mimeType="application/octet-stream")]
   public class Ressources_BASES_SWF_dataClass extends ByteArrayAsset
   {
      
      public function Ressources_BASES_SWF_dataClass()
      {
         super();
      }
   }
}

