package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/16_net.louissi.Alpha1.Global.Ressources_Sound_explosion2_net.louissi.Alpha1.Global.Ressources_Sound_explosion2.mp3")]
   public class Ressources_Sound_explosion2 extends SoundAsset
   {
      
      public function Ressources_Sound_explosion2()
      {
         super();
      }
   }
}

