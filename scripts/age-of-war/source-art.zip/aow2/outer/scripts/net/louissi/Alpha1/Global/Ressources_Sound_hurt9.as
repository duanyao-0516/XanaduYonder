package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/39_net.louissi.Alpha1.Global.Ressources_Sound_hurt9_net.louissi.Alpha1.Global.Ressources_Sound_hurt9.mp3")]
   public class Ressources_Sound_hurt9 extends SoundAsset
   {
      
      public function Ressources_Sound_hurt9()
      {
         super();
      }
   }
}

