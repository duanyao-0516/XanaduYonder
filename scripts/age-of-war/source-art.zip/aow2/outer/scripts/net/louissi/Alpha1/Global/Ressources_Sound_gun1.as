package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/7_net.louissi.Alpha1.Global.Ressources_Sound_gun1_net.louissi.Alpha1.Global.Ressources_Sound_gun1.mp3")]
   public class Ressources_Sound_gun1 extends SoundAsset
   {
      
      public function Ressources_Sound_gun1()
      {
         super();
      }
   }
}

