package net.louissi.Alpha1.Global
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/80_net.louissi.Alpha1.Global.Ressources_AGE1_UNITS_SWF_dataClass.bin", mimeType="application/octet-stream")]
   public class Ressources_AGE1_UNITS_SWF_dataClass extends ByteArrayAsset
   {
      
      public function Ressources_AGE1_UNITS_SWF_dataClass()
      {
         super();
      }
   }
}

