package net.louissi.Alpha1.Global
{
   import mx.core.ByteArrayAsset;
   
   [Embed(source="/_assets/84_net.louissi.Alpha1.Global.Ressources_PROJECTILES_SWF_dataClass.bin", mimeType="application/octet-stream")]
   public class Ressources_PROJECTILES_SWF_dataClass extends ByteArrayAsset
   {
      
      public function Ressources_PROJECTILES_SWF_dataClass()
      {
         super();
      }
   }
}

