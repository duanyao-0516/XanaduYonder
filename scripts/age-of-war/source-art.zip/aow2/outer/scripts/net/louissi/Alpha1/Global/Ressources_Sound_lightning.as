package net.louissi.Alpha1.Global
{
   import mx.core.SoundAsset;
   
   [Embed(source="/_assets/14_net.louissi.Alpha1.Global.Ressources_Sound_lightning_net.louissi.Alpha1.Global.Ressources_Sound_lightning.mp3")]
   public class Ressources_Sound_lightning extends SoundAsset
   {
      
      public function Ressources_Sound_lightning()
      {
         super();
      }
   }
}

