on(press){
   _parent.add_to_tray(4);
}
