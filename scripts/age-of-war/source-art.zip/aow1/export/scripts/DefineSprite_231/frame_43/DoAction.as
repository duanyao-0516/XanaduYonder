gotoAndPlay(1);
