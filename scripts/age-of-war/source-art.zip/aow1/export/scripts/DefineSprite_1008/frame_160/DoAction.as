stop();
_root.play();
