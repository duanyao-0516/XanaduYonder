this.removeMovieClip();
