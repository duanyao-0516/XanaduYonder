timer = 300;
cc = 0;
_root.specialh = true;
this.onEnterFrame = function()
{
   timer--;
   if(timer == 0)
   {
      _root.specialh = false;
      this.removeMovieClip();
   }
};
